# aMule Changelog

The history of every aMule release. Versions are listed newest first.

---

## Version 3.0.0 — "alive again"
2026-06-08

First major release in 5+ years (since 2.3.3, 2021-02-07). Headline changes are dramatic throughput improvements, full build-system overhaul, modernized dependency stack, native binaries for Linux / macOS / Windows, and a broad legacy-API cleanup.

### Highlights

- **Throughput rewrite.** Disk I/O moved off the main thread, ASIO/EPOLLET races fixed, throttlers replaced with proper token-bucket limiters. Peer-to-peer download on the same hardware sees **~100–380× speedups** across macOS / Linux / Windows over 2.3.3, plus aMule 3.0.0 sustains **~4.8×** the upload throughput of eMule 0.70b on Windows. See [Performance](#performance) for the full matrix and per-PR breakdown.
- Both throttlers (`MaxUpload`, `MaxDownload`) were also broken pre-fix — `MaxUpload=0` capped at "current rate + 5 KB/s", `MaxDownload` was a ratio controller rather than a literal cap. Both rewritten (#461, #491). Important user-facing bug fixes, but secondary to the headline numbers.
- **Big-library / big-shareset scaling.** Follow-up wave targeting nodes with 100 k+ shared files: per-file EC payload caches (#725, #736), skip-unchanged EC updates (#727), local-peer ZLIB bypass (#728), and a string of O(N²) → O(N log N) / O(1) algorithmic fixes across `SharedFileList`, `SharedFilesCtrl`, `KnownFileList`, `wxListCtrl`, `ExternalConn`, and amuleweb — the WebUI / amulegui stay responsive even on libraries where the previous GUI took minutes to redraw.
- **CMake replaces autotools.** Single build system, modern toolchain — minimum CMake 3.10, minimum wxWidgets 3.2.0.
- **Native binaries for every major desktop.** AppImage (x86_64 + aarch64), Flatpak (x86_64 + aarch64), macOS Universal2 .dmg (now bundling `aMuleGUI.app` alongside `aMule.app`, #529), Windows portable .zip **and NSIS installer** (x64 + ARM64, #740). First-run desktop integration prompt for AppImage; cross-platform autostart-on-login toggle (#744).
- **Auto-rescan of shared folders.** `wxFileSystemWatcher`-driven (#591), with recursive vs explicit-share intent split (#606) and coverage of Incoming + per-category Incoming dirs (#743).
- **HTTPS works again.** `CHTTPDownloadThread` rewritten on top of `wxWebRequest`; the hand-rolled stack had silently stopped working against modern TLS.
- **Kad parallel searches** with alpha-frontier widening.
- **MaxMindDB replaces deprecated GeoIP** for IP→country.

### Performance

Throughput work landed across April 2026. The bottom-line cross-platform
numbers first, then the per-PR contributions that produced them.

#### Cross-platform end-to-end (2.3.3 vs 3.0.0)

| Leecher platform | 2.3.3 (sustained) | 3.0.0 (sustained) | Speedup |
|---|---:|---:|---:|
| macOS (Apple Silicon, Mac Studio) | 0.35 MB/s | **135 MB/s** | **381×** |
| Linux ARM (UTM VM, Ubuntu 25.10) | 0.34 MB/s | **117 MB/s** | **345×** |
| Windows ARM (UTM VM, Windows 11) | 0.36 MB/s | **39 MB/s** | **107×** |

Sustained over a 90 s window, single LAN peer downloading a 30 GB file
from an x86_64 Linux seeder running the same aMule version under test.

Per-platform breakdown of the seeder-side vs leecher-side contributions:

| Platform | 2.3.3 | + seeder fix | + leecher fix (3.0.0) |
|---|---:|---:|---:|
| macOS | 0.35 MB/s | 30 MB/s | **135 MB/s** |
| Linux | 0.34 MB/s | 20 MB/s | **117 MB/s** |
| Windows | 0.36 MB/s | 6.8 MB/s | **39 MB/s** |

The seeder-side contribution (PR #451 `CUploadDiskIOThread` + ASIO fixes)
dominates everywhere; the leecher-side contribution (#454 partfile-write
offload + #484 throttler-wake fix + #491 token-bucket cap) stacks another
~4–6× on top.

#### vs eMule 0.70b (Windows · same UTM hardware)

| Direction | eMule 0.70b | aMule 3.0.0 | Speedup |
|---|---:|---:|---:|
| **Upload** (Windows seeds → Mac leecher) | 22 MB/s | **106 MB/s** | **~4.8×** |
| **Download** (Linux seeds → Windows leeches) | 20 MB/s | **39 MB/s** | **~1.9×** |

#### Upload

- **#451 — eMule `CUploadDiskIOThread` port.** Disk reads + ed2k packet construction off the main thread, RC4 stream-desync race fixed in the ASIO layer, EPOLLET spurious-wakeup fix in `HandleRead`, adaptive per-slot packet sizing (10 KiB → EMBLOCKSIZE). Dominant contributor to the upload gain.
- **#461 — `MaxUpload=0` is now literal unlimited.** The legacy code set `allowedDataRate = current_rate + 5 KB/s` per iteration — a tracking cap that pinned the uplink at a fraction of capacity on any link above a few hundred KB/s.
- **#436 — Speed-limit fields widened from `uint16` to `uint32`.** Legacy 65,534 KB/s (~524 Mbps) configuration ceiling gone; gigabit-class links can now be configured.
- **#463 — Bandwidth-cap UI.** Spin button ceiling 19,375 → 1,000,000 KB/s; field width 100 → 140 px so the `+` button no longer clips off on modern themes. Slot Allocation cap 100 → 100,000 KB/s.
- **#898 — Default `SlotAllocation` raised from 2 kB/s to 10 kB/s.** The previous default (set in 2005) fragmented uploads into so many sub-slot slices that fast peers were rate-shaped down to a trickle.

#### Download

- **#454 — `CPartFileWriteThread`.** Disk writes for downloads moved off the main thread.
- **#484 — Throttler-wake fix.** `UploadBandwidthThrottler::Entry()` adaptive backoff dozed for 5–25 ms between control-queue pumps, stalling the request→response loop. Empty→non-empty wake gate added on the control-queue path, plus IOCP-native `async_read_some` on Windows, `wxMutex` → `std::mutex`, and decoupling `m_MaxBlockRequests` from per-packet block count. The biggest win on Windows specifically.
- **#491 — `MaxDownload` is now a literal byte/sec cap.** The legacy code was a closed-loop ratio controller that nudged each peer's rate ±5%/tick relative to its own current speed, so `MaxDownload=20000` (20 MB/s) shaped traffic toward whatever the aggregate converged on — generally well below configured. Replaced with a global token bucket (`CDownloadBandwidthThrottler`) enforcing the cap to within 2.5% across platforms.
- **#498 — Per-part hash verification deferred to a dedicated worker thread** (only runs when the file isn't actively transferring). Follow-ups #499, #500.

#### Other

- **#467 — ASIO handler binding modernised.** `boost::bind` → C++11 lambda, `strand.wrap()` → `bind_executor()`, `deadline_timer` → `steady_timer`, `null_buffers` → `async_wait(wait_read)`. Fixes the long-standing `boost::bind` placeholder warning. Minimum Boost bumped 1.47 → 1.70.
- **#504 — Fast-path bare-filename comparison** skips `wxGetCwd()`.

#### Big-library / big-shareset scaling

A follow-up wave targeting nodes with 100 k+ shared files, where the daemon ↔ GUI / WebUI / amuleweb traffic and several internal data structures were quadratic in the shareset size:

- **EC payload caches.** Per-file `ed2k://` link and partmet basename cached on `CKnownFile` / `CPartFile` so EC enumeration stops rebuilding them on every tick (#725). Per-file byte cache covers the FULL `GET_SHARED_FILES` / `GET_DLOAD_QUEUE` paths so wire-marshalling cost drops by orders of magnitude on huge sharesets (#736).
- **EC skip-unchanged.** Per-file change tracking infrastructure threaded through every field-change site so `INC_UPDATE` only re-sends what actually moved, with a backward-compatible partial-update protocol opt-in for amuleweb (#727 — landed as a 6-commit series). `MarkECChanged` gaps closed for paused / user-action setters.
- **Local-peer EC bypass.** ZLIB compression skipped on local peers (#728), receiver limit raised to 256 MB, and the locality decision later moved to the client side with a user override checkbox / `--force-zlib` flag (#840 — handles the WireGuard-as-LAN case).
- **O(N²) → O(N log N) / O(1) algorithmic fixes.**
  - `SharedFilesCtrl` bulk-update API skips per-row repaints during `ClearED2KPublishInfo` (#561, #2bf9b8f34).
  - `SharedFileList` keyword indexing in `Reload` (#566).
  - `known2.met` AICH `SaveHashSet` dedup made O(1) (#581).
  - `known.met` hash-collision dedup on Init dropped to O(N log N) (#584).
  - `wxListCtrl::FindItem(data)` O(N) → O(1) via user-data hash map (#614).
  - `ExternalConn` file-list enumeration snapshotted to avoid O(N²) `GetFileByIndex` loops (#687).
  - amuleweb `array_push_back` made O(N) via cached scan hint (#689).
  - `KnownFileList` indexes its size-map by `(size, mtime)` instead of size alone to cut false-positive collision-dedup walks (#593).
- **Disk I/O.** `CFile` gains a 64 KB userspace write buffer to coalesce metadata-save syscalls (#573); the buffer was subsequently moved off the stack onto the heap so it survives musl's 128 KiB pthread stack, and an internal recursive_mutex was added to serialise buffer + fd access against the concurrent-corruption race surfaced on Alpine (#576). `SavePartFile` switched to atomic-rename (#670) and gated on an in-memory dirty flag so periodic ticks only touch disk when something actually changed (#671). Upload-stats persistence on 10-min heartbeat when only stats moved (#e8363bf42).
- **Memory bounds.** `amuleIPV4Address::operator=` no longer leaks the endpoint copy on every assign (#716) — was 7 MB / 514 k objects per ~10 h of runtime on a busy node. `CKeyEntry::m_filenames` capped so the list can't grow unbounded (#652). `known.met` growth bounded by per-hash cap + 30-day TTL (#598, #f33c56b44). `KnownFileList::Append` only stamps `lastSeen=now` on actual sightings (#fafbb8a66). Wake-from-sleep SIGSEGV in asio socket impls fixed via `shared_from_this` (#596).
- **Backpressure & yielding.** `ECSocket::OnOutput` yields when asio backpressures `Write` to zero bytes (#672). `CECServerSocket` notification-dispatch recursion capped so EC bursts no longer stall the event loop (#667). `HTTPDownload` bounds libcurl connect-phase via `GetNativeHandle()` (#565). Startup HTTP downloads deferred until after partfile + shared-file scan (#719) so cold-start UI is responsive while ipfilter.dat and friends are fetched.
- **Recursive share walks** deferred + cancellable, with confirmation prompts for sensitive home-parent paths (#594, #599).
- **macOS daemon shutdown** driven from `OnCoreTimer` to fix the long-standing hang (#563).

### Networking & Discovery

- **Kad parallel searches** with alpha-frontier widening; new "More" button to ask additional peers for results (#505).
- **MaxMindDB replaces deprecated GeoIP** for IP→country (.dat → .mmdb; free MaxMind account required for the database) (#502, #507, #509).
- HTTPS downloads work again — `CHTTPDownloadThread` rewritten on top of `wxWebRequest` (#462), with a hard-fail when `wxUSE_WEBREQUEST` is off (#481).
- Wire-parser hardening: `OP_SERVERMESSAGE` size validation (#447), buffer overflow fix in `ECSocket` (#421), uninitialized memory fix in `UInt128` (#424). EC tags whose declared length underflows the children size now rejected (#879). `Proxy::SendTo` SOCKS5 UDP relay bounded against oversized payloads (#882). Webserver/PHP `IDENT` strcpy into `YYSTYPE.str_val` bounded (#890). Memory leaks on malformed-packet exception paths plugged (#886, fixes #884 / #885).
- ed2k-link float tags endian-swapped correctly on big-endian hosts (#368).
- Friend's shared list and search-result rating exposed via EC (#430, #452).
- **Shared-folder watcher.** `wxFileSystemWatcher`-driven auto-rescan (#591), with recursive vs explicit-share intent split + cold-discover of subdirs created while offline (#606). Watcher also covers the Incoming dir + per-category Incoming dirs so completed downloads register without a manual reload (#743). Incremental rescan replaces full `Reload` per filesystem event (#751); `SharedFileList` AICH-hash scan dropped from O(N·M) to O(N+M) (#746); optional "Follow symbolic links in shared folders" preference (#809). macOS amuled now pumps `CFRunLoop` so FSEvents deliver (#975f60fb0). File rename / move-out / delete during in-flight hash handled cleanly (#858).
- **Kad index hygiene.** `CEntry::SetFileName` rejects empty filenames in the merge path (#675); `CKeyEntry::m_filenames` bounded (#652); `known2_64.met` orphan-pruned at sync startup (#605). `m_filenames` rotation now uses O(N) compare-and-skip insertion instead of sort+resize (#795); a popularity-decay experiment (#799) was introduced and then reverted (#805), keeping the `GetCommonFileName` all-zero robustness fix. Kad late UDP firewall responses dropped; Recheck assert downgraded (#afb9da010). SearchID collisions between Kad and ed2k searches no longer mix tab results (#530, #3008ada0f).
- **Server protocol.** Future ping timestamps discarded from server.met (#3f70856a0); several server-ping fixes (#715). Control-traffic bypasses the download throttler (#615); inbound server probes also bypass it (#787). Server-name updates parsed as Unicode without the obsolete `SRV_TCPFLG_UNICODE` gate (#835); explicit disconnect when the server assigns no client ID (#788). `OP_IDCHANGE` sanity checks demoted to debug log (#613). `ServerUDPSocket` "additional packet" notice demoted to non-critical debug (#548). HTTP/HTTPS auto-update for `addresses.dat` accepts https URLs (#721); default eMule-security + shortypower URLs upgraded to HTTPS (#718).
- **EC / WebUI / amuleweb.** 65535-children-per-tag wire-format ceiling lifted (#570). `FRIEND_REMOVE` made idempotent (#632); friend-slot flag persisted on `CFriend` so it survives disconnects (#633). amuleweb honours `amule_set_options()` nickname (#634); fixes POST body parsing when URL has a query string (#729); fixes `split()` byte/wide-char confusion on UTF-8 input (#619); fixes SIGSEGV rendering y-axis labels above 9999 (#618); fixes crash with >65535 shared files (#700). WebUI adds Kad + ed2k connect/disconnect controls (#660), Kad nodes-URL control, "Disconnect from current ed2k server" (#a82cd2e1a, #b5d83829a), and persistent ED2K / Kad enable checkboxes (#661, #8ce30f910); sends max upload/download rate as uint32 (#645). amulegui surfaces `EC_OP_FAILED` from `ADD_LINK` (#557), implements category-tab Stop/Pause/Resume/Cancel + Prio (#701), renders statistics graphs via `EC_OP_GET_STATSGRAPHS` (#639), and overrides `OnFatalException` with libbfd backtrace (#695). Aggregated single-popup AddLink error reporting (#577).
- **amuleweb security hardening** (ngosang triage, all in #875). XSS-safe whitelist on the `sort` query param + `htmlspecialchars` defence-in-depth (#869); `rand()`-derived session IDs replaced with a 64-bit CSPRNG token from `CryptoPP::AutoSeededRandomPool` (#870); `HttpOnly; SameSite=Strict` on the session cookie (#871); login handler refuses to consume `pass` when reachable via the pre-POST-body-merge URL (#872); read-buffer NUL-terminator allocation fix (#873); dead `SESSION_TIMEOUT_SECS` macro wired up (#874).
- **UPnP.** Filter non-WAN device announcements before fetching description (#623). Cache failed XML fetches + demote routine discovery logs from critical to debug (#653, #627).
- **ClientTCPSocket** strict "no trailing bytes" asserts demoted to debug log (#710).
- **SharedFileList** emits the honest file count in `OP_OFFERFILES` (#556) and skips empty `OP_OFFERFILES` when nothing made the LF cut (#169910998).

### Build System & Dependencies

aMule 3.0 requires **CMake ≥ 3.10** and **wxWidgets ≥ 3.2.0**. Autotools is removed entirely.

- Full CMake build replaces autotools (#449).
- Autotools, `debian/` packaging dir, and dead platform/subtool trees retired (#466).
- wxWidgets 3.x build fixes (#438, #443, #453); macOS framework / app-bundle compat (#453).
- Boost 1.87 / 1.89 build fixes (#387, #429) — modern Boost ASIO no longer breaks the build.
- CMake hard-fails when `ENABLE_X=YES` cannot be honored: UPnP (#511), NLS (#512), Boost (#513), IP2Country (#509). No more silent disable.
- CMake mins / detection: minimum 3.10 and `version.rc` path fix (#490), `MIN_WX_VERSION` 3.2 with legacy `wx.cmake` retired (#459), default build type Release (#469), broken `UPNP.cmake` workaround (#439), BFD link fixes for modern binutils (#487, #489), `find_package(Intl)` outside `YYENABLE_NLS` gate (#495).
- SVNDATE banner: stops freezing at first configure (#483); refreshes on `git reset` / commit (#493). **`SVN` macros / files renamed to `GIT` throughout the source tree (#726)** — `SVNDATE` → `GITDATE`, `__SVN__` → `__GIT__`, `config.h.cm` and Windows `version.rc.in` follow suit. No user-facing impact; reflects 5+ years of Git as the canonical SCM.
- `compile_commands.json` generated (#441); `compile.sh` and `find_uncompiled.py` build/analysis scripts (#494, #501).
- Loongarch64 architecture support (#286).
- OpenSUSE platform fixes (#440); libupnp 1.18 compatibility (#448).
- **boost::asio mandatory.** wxWidgets-sockets fallback path removed; `ENABLE_BOOST` and `DOWNLOAD_AND_BUILD_DEPS` escape hatches retired (#603).
- **CMake polish (post-#518).** `wx_NEED_NET` kept on for BUILD_WEBSERVER-only (#620) and BUILD_AMULECMD-only (#630) configurations. `libatomic` linked directly on 32-bit targets where `std::atomic<int64_t>` needs it (#648, #662) — the heuristic atomic-probe is gone. `glib-2.0` hard-fail when missing for `amule` / `amuled` / `amulegui` (#571), but the dependency itself is dropped on macOS even under wxGTK (#647). `PACKAGE` / `PACKAGE_VERSION` pre-defined for the bfd.h probe (#545).
- **license.txt** moved to project root (#730).
- **CodeQL** alerts cleared (#732, #733); CI runs CodeQL on push to master only, not on PRs (#c02d5ec04). `actions/checkout` bumped (#446 in initial pass).
- **README + docs polish.** Distro version and GitHub activity badges (#7a1b310b5); markdown / ortography sweep (#6e9a9fe5a); INSTALL.md MD012/MD060 markup warnings fixed (#31aff1499).

### Packaging

aMule 3.0 ships native binaries covering most modern desktops:

- **Linux AppImage** (x86_64, aarch64) — works across all major distros.
- **Linux Flatpak** (x86_64, aarch64) — runs in the GNOME Platform sandbox.
- **macOS Universal2 `.dmg`** — single installer containing Apple Silicon and Intel binaries (the per-arch `.app` trees are CI intermediates for the `lipo` merge job and are not published as separate downloads).
- **Windows portable `.zip`** (x64, ARM64).
- **Windows NSIS installer `.exe`** (x64, ARM64) — guided installation, alternative to the portable zip.

Recipes, manifests, and the GitHub Actions packaging matrix landed in #510. AppImage's first-run prompt installs a desktop launcher to the user's application menu (reversible, opt-in).

Other platform integration work:

- Wayland-friendly desktop integration: matching `app_id`, SNI tray icon (replaces deprecated `GtkStatusIcon`), macOS dock-restore on quit, tray opt-in (#508; fallback workaround in #474).
- macOS Carbon `FSRef` API retired in favor of `$HOME`-based paths (#468).
- macOS Dock right-click Quit triggers proper shutdown cleanup (#456).
- Windows / MinGW build support: cmake fixes, LLP64 pointer safety, ASIO on Windows (#457).
- Icons across all platforms: Linux hicolor PNG, Windows `.rc` icon, macOS `amulegui.app` (#464).
- Initial AppStream metainfo (#367).
- Localization on macOS and Windows fixed — wxLocale lookup paths repaired (#492).
- macOS spurious `wxGetCwd()` errors silenced (#480).
- Flatpak `libupnp` install-libdir pinned for pkg-config (#515).
- **macOS .dmg now bundles `aMuleGUI.app`** alongside `aMule.app` so installing the .dmg gives both the daemon-style and GUI binaries in `/Applications` (#529). Locale catalogs are bundled inside the `aMuleGUI.app` `Contents/Resources` tree so translated strings render correctly when run from the .dmg (#543).
- **Windows NSIS installer** shipped alongside the existing portable .zip (#740), with un.SecRemoveUserData no longer appearing on the install Components page (#65178406a). Installer UI now driven from `po/<lang>.po` via a `po-to-nsh.py` bridge so every supported NSIS language gets translated strings with English fallback (#899).
- **Cross-platform autostart-on-login** toggle in Preferences (#744): Linux .desktop, macOS LaunchAgent, Windows registry under one checkbox.
- All platforms ship `alc` / `alcc` / `cas` / `wxcas`; Windows additionally ships `amuleweb` (#785); macOS `.dmg` now contains `amuleweb` after build-path correction (#794).
- Release-asset filenames standardised on `<OS>-<arch>` so every package is reachable by predictable URL (#789).
- Windows non-DPI executables (`alc`, `wxcas`) get a comctl32 v6 + PerMonitorV2 manifest so they aren't bitmap-scaled on hi-DPI displays (#796); the main GUI got the same `PerMonitorV2` declaration in #780.
- Windows resource lookup paths corrected so skins and webserver templates resolve to `share/amule` (#784).

### Internals & Refactoring

- Legacy wx 2.x-era deprecated APIs removed (#470).
- 2.x-compat globals and event-table macros retired (#475).
- Dialog code migrated to `wxSizerFlags`; wxDesigner-generated code retired; GCC 15 enum-enum conversion warnings eliminated (#473).
- macOS 10.10-era deprecation cleanup (#470).
- `OnAssertFailure` ternary fixed for strict GCC / Alpine builds (#476).
- Documentation transitioned to Markdown; staleness audit; broken README icon URL fixed (#514).
- **Late-cycle docs polish.** Petar Maymounkov's email + paper URL refreshed to current (#851); IRC channel pointed to `irc.libera.chat` (#855); leftover references to the removed XAS module dropped (#862); README project-migration notice (#888); English man-page masters resynced to source (#900); `--enable-webserver` build hint refreshed in amuleweb-launch failure (#866, fixes #864); copyright headers refreshed across the source tree (#867); EC host default corrected in i18n docs (#895).
- **Code-quality follow-ups.** `FileLock` platform `#ifdef` moved out of class body (#909); redundant null guard after early return removed from `SharedFileList` (#910); unused UPnP symbols dropped from `WebSocket` and `SafeFile.h` typo fixed (#912).
- po4a config restored + optional CMake `po4a-update` target (#485).
- Wiki content migrated into the repository (#496).
- **Crash diagnostics.** `MuleDebug` PIE-translates runtime PCs back to link-time addresses for bfd (#677, #678), uses `popen()` instead of `wxExecute()` for the addr2line fallback (#682), and the `Do_not_auto_remove` marker is replaced with the modern `IWYU pragma: keep` (#679). amulegui's `OnFatalException` overridden with libbfd backtrace (#695). `wxcas` / `alc` disable wxSizerFlags consistency checks at startup (#694) — eliminates spurious assertion noise that broke the apps under wx 3.3.
- **Tray-icon overhaul.** Unified Linux/macOS/Windows tray path (#574); dock icon dropped while hidden via tray on macOS (#a5a9a5866); `HideOnClose` decoupled from confirm-exit (#f1d0e85f0); iconize-aware menu + single-left toggle + robust ShowGUI (#0640373c8); `ServerWnd` sash anchored to top, persist-on-drag only (#47c811191); 'Enable Tray Icon' master placed before its dependents (#64b83e48e). Linux-specific tray-icon limitations gated separately (#2a0b874d7). 'Hide on close' exposed cross-platform behind the tray-icon gate (#e82b4bac5).
- **Wayland.** amule-remote-gui binds `wl_app_id` via `g_set_prgname()` (#572).
- **GUI dispatch polish.** `MuleNotebook` dispatches the right-click forward synchronously so PopupMenu's grab is fresh (#683). `ClientDetailDialog` binds Escape to Close (#681). Destructive YES_NO prompts no longer treat ESC as confirm (#612).
- **amulecmd.** Search filters (type/extension/availability/size) now exposed via flags (#542) and documented (#544, #547). amulecmd.1 stops translating command names in section headers (#4296bbccf).
- **amule** `--disable-fatal` also skips the assertion dialog (#549).
- **First-run prompt** for nodes.dat alongside server.met (#558), with translations regenerated (#71542203f).
- **Logger.** Sticky stdio EOF cleared on `CLoggerAccess` so EC log polls see new lines (#567). Control characters escaped in 'Invalid Kad tag type' log lines (#550). `ExternalConnector` console binaries respect `VerboseDebug` from amule.conf (#654) and `setlocale` at init so non-interactive output keeps accented chars (#629).
- **Y2038.** Internal time-handling unified on `uint64 GetTickCount64()` to properly manage milliseconds past 2038 (#702). `CLOCK_REALTIME` → `CLOCK_MONOTONIC` for steady-state intervals (#56a369e95).
- **EC ADD_LINK** aggregates per-link result into a single response (#551).
- **Misc.** `asio` sets `FD_CLOEXEC` on listen + UDP sockets (#552). `FileFunctions` bails out when `wxZipInputStream` stalls on a bad entry (#553). `GuiEvents` NULL-guards `ECNotifier` before dereferencing on download notifies (#554). `StatTree` stops double-counting session bytes (#555) and guards total ratio div-by-zero on fresh installs (#585). `KnownFileList` takes list_mut before opening `known.met.new` (#546) and closes a TOCTOU UAF window in `Save()` / `PruneDuplicates` (#690). `SharedFileList` takes `list_mut` around `m_keywords` ops in `Reload` and `Publish` so concurrent Kad publishes don't iterate a mid-mutation map (#686). `PrefsUnifiedDlg` flags user-home parents as sensitive (#599). amuleweb URL migration to `amule-org` and dead `amule.org` refs removed (#526).
- **Tooling / type cleanup.** `fileview` CLogger stub extended with `IsEnabled()` for Debug builds (#657). `muleunit` adds missing override keywords (#664). Sockets `override` keyword sweep on `CEMSocket`-derived classes (#625). `WebServer` uses `vector::data()` in `CProgressImage::CreateSpan` (#684). Constant rename: `PR_VERYLOW` → `PR_VERY_LOW` (#97fcd3ae8); `PS_WAITINGFORHASH` → `PS_WAITING_FOR_HASH` (#2ae100b56). Webserver internal renames: `gaptag` / `parttag` / `reqtag` → `gap_tag` / `part_tag` / `req_tag` (#412f5aa27); `autoprio` → `auto_priority` (#f0bca611b). Backtrace internal rename: `s_abfd` → `s_a_bfd` (#5a576c3c1). Webserver enum typo fixes (#5a0d13718). Spelling sweeps across webserver (#fd823eff8, #0cda3b03c) and backtrace (#bb76d0ad8).
- **PartFile.** `m_lastDateChanged` stamped on data arrival, not flush (#638). `FlushBuffer` size-correction guarded against closed fd (#609). `m_hpartfile` locked in `ReadData` + `AICHRecoveryDataAvailable` (#709). `HashSinglePart` bound-checked against partfile length (#130b0f495). Async hash enqueue gated on `IsComplete` (#c660e1281). Per-part hashing hardened against gap/disk-state drift (#560).
- **Preferences.** No longer drops inaccessible shared dirs on load (#707); preserves unknown WebServer Template across GUI Save (#621); prefs/directories surfaces that the Incoming folder is shared (#631). `ExternalConnector` deletes `m_ECClient` in dtor to stop one-shot leak (#706).
- **Listctrl polish.** `RefreshLines` skipped when range is outside visible (#624). Unfocused selection visible on themes where `BTNSHADOW == LISTBOX` (#646). LTR cell paint forced to fix RTL-locale glyph mirroring (#540).
- **Search dialog.** Clipped Min/Max Size + Availability spin controls on Linux (#607, #82626f2f3). 10px-tall extension input field (#569 / #971310402).
- **Misc UI.** `amuleDlg` re-Realizes toolbar after Show() to fix wxMSW long-locale clipping (#532). Hardcoded 20px height on the FastEd2kLinks bar dropped (#534, #c710c08fe). Icons migrated from `XPM #include` to `wxArtProvider` + embedded PNG (#537, #59d718818). Gtk-CRITICAL warnings on Preferences + Networks tabs silenced (#739).
- **PartFileConvertDlg** collects ids before removing rows so `GetNextItem` stays valid (#649).
- **SafeFile** oversized-string assertion demoted to debug log (#617).
- **KnownFile.** Skip notify when `SetPublishedED2K` value didn't change (#dde5294fc). `m_duplicateFileList` growth bounded with a per-hash cap (#f33c56b44).
- **Code-quality baseline.** Baseline `.clang-tidy` configuration introduced (#770); first sweeps produced 6 safety fixes (#773) and 4 cosmetic fixes (#774); `wxASSERT` → `wxCHECK_MSG` on array-access guards in `Logger` / `UserEvents` (#772).
- **Dead-code removal.** 2011-era `/Statistics` legacy config migration dropped (#825); long-broken "Automatic server connect without proxy" checkbox removed from preferences (#806).

### Translations

- Italian: AppImage integration prompt translated (#518).
- Spanish updated and completed (#497).
- Dutch updated (#343).
- Catalan updated (#425).
- Simplified Chinese updated (#348).
- Translation pipeline: `scripts/update-po.sh` introduced.
- **AI-assisted gap-fill** for it / fr / de / es app strings (#582) and man pages (#580).
- **Spanish** further updates (cpp + docs, manpages rebuilt) (#655).
- **French + Turkish** updated (#691) and added to the AppStream info file (#698, #86a08ffc7).
- **Brazilian Portuguese (pt-BR)** added to metainfo (#86bafee35); metainfo screenshot URLs fixed (`amule/amule` → `amule-org/amule`, #cf84ec2c6); TODO comment syntax fix (`shell` → `XML`, #fc205619f).
- **po regeneration** from updated sources + msgmerge across all locales (#c2bbea0ed).
- **Late-cycle wave**: French + Turkish manual pages (#753, #754, #776); Galician update (#763); Slovenian recovered from forum.amule.org (#771); Brazilian Portuguese man page added (#768) and the `.po` completed (#775); pt-BR translations on 4 `.desktop` files (#812); French manual-page update (#811).
- **Man-page tooling**: `.TH` headers templatized for date + version so they no longer drift per release (#802).
- **Pre-release final wave** (3.0.0 cut): French + Turkish updates (#847, #856, #891, #908); Brazilian Portuguese (#860, #904); Spanish app + man pages (#859, #863); Italian completed (it / it_CH fuzzy + untranslated) (#861); German (#880, #911); Vietnamese README added (#901); regenerated po/pot for app + man pages with Italian translations applied (#902); obsolete (#~) entries swept from app + man po (#889); stale Copyright year bumped + obsolete entries pruned (#868); Petar Maymounkov's email + paper URL updated in all catalogs (#853).

### Bug Fixes & Stability

- `CFile::doSeek` no longer asserts when `IsOpened()` is false (#294).
- `RLE_Data` memory delete issue fixed (Valgrind report) (#379).
- Selected lines in Download/Shared lists no longer become illegible when losing focus (#385).
- amulegui: clean startup on Cancel + watchdog on wrong connection data (#465).
- amuleweb: missing `prefs apply` options restored (#419).
- `PartFileWriteThread` catches `CIOFailureException` so disk-full doesn't kill the process (#499).
- StatTree fix (#319); totalizers added to download/upload stats (#338, #339).
- Doc / source-comment typos cleanup (#297); missing include (#360).
- **amuleweb crash with >65535 shared files** fixed (#700) with regression test (#61276d70d).
- **CFile musl SIGSEGV + concurrent corruption** caught and fixed (#576) — musl's 128 KiB pthread stack interacted badly with the 64 KB userspace write buffer added in #573; a separate concurrent-corruption race on a shared write buffer was also fixed in the same PR.
- **macOS link error** caused by implicit AppKit framework dependency now resolved by naming it explicitly (#578).
- **Wake-from-sleep SIGSEGV** in asio socket impls — root cause `shared_from_this` lifetime gap (#596). NULL `m_socket` also guarded in UDP DispatchClose (#82b5400dc).
- **WebUI** rate-limit fields no longer truncate at 16 bits (#645).
- **PartFileConvertDlg** iteration invalidation crash (#649).
- **amulegui** EC connect-timeout shutdown crash (#717).
- **ExternalConnector** one-shot `m_ECClient` leak on dtor (#706).
- **EC notification path** raw-pointer `CECPacket` leak plugged (#797).
- **Detect dead amuled** cleanly across all clients (#758); EC `--upnp-port` fixed from switch to numeric option in `amuleweb` (#820); `amuleweb` `remote.conf` round-trip + Windows webserver template path fixed (#822).
- **amulegui improvements and fixes**: ghost-entry sources — stale EC alive-marker for unknown ID no longer creates phantom rows (#810), `INC_UPDATE` tag for unknown file ID with suppressed identifying metadata now skipped cleanly (#819); connection dialog reappears on failure instead of quitting (#841); ED2K Info pane readability + clipboard copy fixed (#824); `DirectoryTreeCtrl` `wxNullFont` crash on the Windows revert-recursive-share path (#830); modal popups deferred out of `OnPacketReceived` call stack (#760). ECIDs the client hasn't received yet now sent with full detail instead of an empty alive marker (#857).
- **PartFile**: first-share early hash so a downloading file appears in "Shared files" before it completes (#762); drop LowID-0 sources in `CanAddSource` (#790).
- **Crypto stream**: don't UB if `EncryptedStreamSocket::Negotiate()` is entered with no expected bytes (#779).
- **UAF prevention**: `Notify_KnownFileBeingDestroyed` broadcast on every `CKnownFile` destruction (#756).
- **GUI / GTK warnings**: silenced on the Advanced Preferences tab via sizer simplification (#833); slider min-height pin attempted (#826) then reverted (#836) after wxGTK 3.2.9 surfaced an invisibility regression.
- **SearchListCtrl** dropped bogus "File" title from right-click popup (#769).
- **Three GUI fixes from #800**: toolbar races and web-template placeholder loop closed (#803).
- **amuled** constructs `CPartFileWriteThread` + hash worker AFTER the InitGui fork so the daemon no longer crashes on first flush (#850, fixes #849).
- **Locale.** `LC_CTYPE=C` scoped around `wxFileConfig` ops and the country-flag lookup so non-C locales no longer break preference number parsing or flag matching (#854, fixes #852).
- **ServerUDPSocket** `Delete()` leaked the detached `CAsyncDNS` on thread Create/Run failure (#878).
- **eD2k socket** `CLibSocket::OnLost(int)` now forwards to `CEMSocket::OnClose` so server/peer disconnects actually fire (#906).

### CI

- macOS and Windows MinGW64 build jobs added (#458); ccpp.yml adjustments (#460).
- Ubuntu CI installs `binutils-dev` so the BFD path is exercised (#488).
- Assert tests gated on `wxDEBUG_LEVEL`; `ctest` runs in Release in CI (#506).
- CodeQL adjustments and code-scanning fixes (#477, #478, #482).
- `actions/checkout` bumped from v4 to v6 (#446).
- **ccache wired across all compile jobs** in both `ccpp.yml` (#892) and the packaging matrix (#903) — `actions/cache`-backed, gated off for tag builds. CodeQL workflow also gets `binutils-dev` so its BFD detection mirrors the main Ubuntu job (#907).

### Known Limitations

Known caveats users should be aware of for this release:

- macOS `.dmg` is **not yet code-signed or notarized** — users will see Gatekeeper warnings on first launch.
- **Flathub submission pending** — for now, install the `.flatpak` directly with `flatpak install <file>`.
- AppImage doesn't yet ship through AppImageLauncher's catalogue.
- Tray-icon library (`libayatana-appindicator`) is deprecated upstream; migration to `libayatana-appindicator-glib` deferred until LTS distros pick it up.

### Contributors

This release reflects 5+ years of work across 234 merged PRs (98 initial + 136 follow-ups through to the tag). Particular thanks to:

- **got3nks** — 182 PRs.
- **Marcelo Jimenez** (mrjimenez) — 17 PRs.
- **Werner Mahr** (Vollstrecker) — 38 commits.
- **Pablo Barciela** (sc0w) — 3 PRs, 17 commits.
- **Dévai Tamás** (GonoszTopi) — 16 commits.
- **danim7** — 5 PRs across the follow-up cycle (translations, server pings, y2038, cmake polish).
- **cardpuncher** — French + Turkish translations and AppStream entries (#691, #698).
- **ngosang** — UX feedback driving the late-3.0 cycle (issues #817, #818, #821, #828, #844) and ongoing work on the user-facing manual at <https://amule-org.github.io>.

Plus contributions from RealGreenDragon, frnjjq, Sergi Amoros, Stefano Picerno, Alexander Tsoy, sergiomb2, puleglot, mercu01, lggcs, comio, MPolleke, mike2718, joebonrichie, matoro, dependabot, tbo47, SevC10, topotech, minterior, luzpaz, loongson-zn, mifritscher, nguyenhoangminhhieu2004-gif.

### Merged PRs in this release

Complete list of PRs that landed for 3.0.0, in numerical order. The narrative sections above call out the most impactful changes; this index gives the full traceback.

#286, #294, #297, #319, #338, #339, #343, #348, #360, #367, #368, #379, #385, #387, #419, #421, #424, #425, #429, #430, #436, #438, #439, #440, #441, #443, #446, #447, #448, #449, #451, #452, #453, #454, #456, #457, #458, #459, #460, #461, #462, #463, #464, #465, #466, #467, #468, #469, #470, #473, #474, #475, #476, #477, #478, #480, #481, #482, #483, #484, #485, #487, #488, #489, #490, #491, #492, #493, #494, #495, #496, #497, #498, #499, #500, #501, #502, #504, #505, #506, #507, #508, #509, #510, #511, #512, #513, #514, #515, #518, #526, #529, #530, #532, #534, #537, #540, #542, #543, #544, #545, #546, #547, #548, #549, #550, #551, #552, #553, #554, #555, #556, #557, #558, #560, #561, #563, #565, #566, #567, #569, #570, #571, #572, #573, #574, #576, #577, #578, #580, #581, #582, #584, #585, #591, #593, #594, #596, #598, #599, #603, #605, #606, #607, #609, #612, #613, #614, #615, #617, #618, #619, #620, #621, #623, #624, #625, #627, #629, #630, #631, #632, #633, #634, #638, #639, #645, #646, #647, #648, #649, #652, #653, #654, #655, #657, #660, #661, #662, #664, #667, #670, #671, #672, #675, #677, #678, #679, #681, #682, #683, #684, #686, #687, #689, #690, #691, #694, #695, #698, #700, #701, #702, #706, #707, #709, #710, #715, #716, #717, #718, #719, #721, #725, #726, #727, #728, #729, #730, #732, #733, #736, #739, #740, #743, #744, #746, #747, #750, #751, #753, #754, #756, #758, #760, #762, #763, #768, #769, #770, #771, #772, #773, #774, #775, #776, #779, #780, #784, #785, #787, #788, #789, #790, #794, #795, #796, #797, #799, #801, #802, #803, #805, #806, #809, #810, #811, #812, #819, #820, #822, #824, #825, #826, #830, #833, #834, #835, #836, #839, #840, #841, #845, #847, #850, #851, #853, #854, #855, #856, #857, #858, #859, #860, #861, #862, #863, #866, #867, #868, #875, #878, #879, #880, #882, #886, #888, #889, #890, #891, #892, #895, #898, #899, #900, #901, #902, #903, #904, #906, #907, #908, #909, #910, #911, #912.


---

## Version 2.3.3 — "delayed too many times, but still not too late"
2021-02-07

	alesnav:
		* Permit amuleweb in an iframe

	Dmitry Smirnov:
		* Added mimetype-hanlder to amule.desktop
		  originally in debian

	gaffatape:
		* Workaround for bug in wxWidgets causing aMule to crash on
		  closing the last search tab

	GonoszTopi:
		* Fix restoring toolbar orientation on 'Cancel'
		* Features ported from eMule:
			- Find best keyword for Kad search (0.49c)
		* Various fixes to gdlib detection
		* Support for compiling aMule with wxGTK under Cygwin
		* Various small fixes to the MacOSX packager script
		* Workaround for wxWidgets bug #17740 (Wrong path used to
		  search for translations), fixes GitHub issue #74 (.mo files
		  for translation are not loaded if amule is built to install
		  to a prefix other than /usr (e.g. /usr/local).)
		* Portability fixes
		* Handle the deprecation of std::auto_ptr in C++11 by using
		  std::unique_ptr instead.
		* Fix linking with readline if configure uses caching
		* Remove 'web search' search type as there are no search
		  engines to support
		* Readline related fixes and improvements in amulecmd:
			- Set the proper application name (amulecmd) for
			  readline. This allows conditional parsing of the
			  readline configuration files (like ~/.inputrc). See
			  the GNU Readline Library documentation (section 1.3.2)
			  for more details.
			- Set up command completion on pressing the TAB key.
			  Since command names are case insensitive, completion
			  uses the default capitalization (shown by the 'Help'
			  command). Completion also works for the
			  'Help <command name>' construct.
			- Pressing <Enter> on an empty line won't give 'Syntax
			  error!' anymore, the empty line is silently ignored.
		* Flex and bison generated files will no longer be regenerated
		  occasionally on the user's system.
		* Proxy authorization fixes
		* Explicitly disable support for autoconf >= 2.70
		* Fix compilation using C++17

	jEsuSdA:
		* Added papirus theme

	KeyofBlueS:
		* Fix compilation with newer bfd

	kinote:
		* Fix integer conversions in amulecmd

	persmule:
		* Fix sharing directories with non-ASCII names with aMule daemon
		* Fix potential invalid detection for empty wxCharBuffer

	Phoenix:
		* Fixed libupnp API breakage.

	poplite:
		* Fixed issue #99 by properly initializing wxSockets in the
		  remote gui

	Sandro Tosi:
		* remove garbage from gdlib
		  originally in debian

	sc0w:
		* Fixed compilation with upnp-1.8
		* C++11 fixes
		* Only handle mouse-up events if the mouse-down event happened
		  on the same tab
		* Fix issue #114: Switching search result tabs doesn't work
		* Fix a number of build warnings
		* Fix a few memory leaks
		* Various small code improvements
		* Add option to show notifications when finished downloading
		* Fixed issue #54: the minimize button doesn't work propertly
		  when "minimize to tray icon" is activated on preferences
		* Fixed issue #59: start minimized doesn't work
		* Fixed issue #225: amule shows wrong 100% when files aren't
		  downloaded
		* Show speeds in MB/s instead of kB/s when appropriate

	Sebastiano Pistore:
		* Unified translation file headers to make it easier to identify
		  contributors

	Thibaut Lassalle:
		* Add README.md

	Tom Li:
		* OScopeCtrl.cpp: use Refresh() instead of ProcessEvent() to
		  refresh the UI, fix issue #146.

	Tommy Jerry Mairo:
		* Fixed issue #119: API mismatch with Crypto++ 6.0.0

	Vollstrecker:
		* Initial support for detecting pkg-config based gdlib versions
		* Compilation fixes for VS2015
		* Fixed compilation with wx-3.1
		* Added cmake-support (Linux and Windows tested)
		* Dropped support for cryptopp versions before 5.5

	xinhuang:
		* Fix crash when shared files changed on Shared files tab

---

## Version 2.3.2 — "don't close tabs"
2016-09-16

	circulosmeos:
		* amuleweb cookies read behind a "lowercase" proxy (http/2 compliant)

	Dan64:
		* Read AICH root hashes from binary eMuleCollection files

	gnazio:
		* Fixed configure of libpng when sh != bash

	GonoszTopi:
		* Allow any kind of file links in collections
		* Make UPnP log go to the appropriate category (#1681)
		* Use the C++ compiler to check for features we're about to use
		  in C++ source files (#1572)
		* Adapt configure to handle subversion repository clones in
		  mercurial and git
		* Fix bfd detection for systems missing -liberty
		* Add support for 'canceled.met' to the fileview tool
		* Implemented the missing 'show shared' command in amulecmd
		* Fix check for a valid locale config entry being done *after*
		  the locale has been set
		* Fix Crypto++ detection routine happily using build library
		  for host when cross-compiling
		* Fix bug #1711: Kad Info tab should display my own user ID
		* Fix wrong sized images in the priscilla skin
		* Fix bug #1423: Add the possibility to not create sparse files
		* Fix bug #1743: crash when importing part files
		* Review assertions in the eD2k and Kademlia code and remove
		  those that could be triggered by a malformed incoming packet
		* Fix a possible uninitialized variable access and a definite
		  memory leak in the UPnP code

	iz0bbz:
		* Fix WinSock library version detection with MinGW-w64
		* Fix compilation with MinGW-w64

	kam:
		* WebServer serves .json, .manifest and .appacache files

	Mr Hyde:
		* Fix "Disable computer's timed standby mode" for MacOS 10.9 Mavericks
		* Compilation fix on Linux Slackware 64bit and MacOS 10.9.4
		* Fix configure on Mac

	sc0w:
		* Add ability to use middle-click to close search tabs

	Stu Redman:
		* Display hashing progress in progress bars
		* Assertion from background thread now prints a message and not just closes the app
		* Backtrace (crash or assertion) is written to logfile
		* Fix: disabling protocol obfuscation broke Kad and triggered assertions
		* Fixed "Prompt on exit" preference
		* Fixed country flags for Turkish localization
		* Fixed loading of zipped IP filter (#1674)
		* Fixed showing of shared files to other clients
		* Fixed assertions in CFormat("%p") on 64 bit OS with wx 2.9
		* Boost Asio can now be used as networking layer instead of wxWidgets
		* Fixed memory leak when AICH hashing already known files
		* New download links for server list and nodes.dat (with gav616 and xosevp)
		* Projects for Visual Studio 2013 (which is now the preferred Win32 compiler)
		* Fixed build with wx 3.0 (including STL build)

	tgragnato:
		* Fixed ASIO compilation with libcxx

	Tianming Xie:
		* Fix for debian bug #795061: There is no rule to generate Scanner.h

---

## Version 2.3.1 — "unobvious evil date"
2011-11-11

	btkaos:
		* Show if a client shares its file list in client view

	freddy77:
		* Various optimizations of memory usage
		* Access files for reading/writing via mapped memory
		  (with custom exception handling)
		* Fix download of files > 1GB on ucLibc
		* Fix autogen.sh under Ubuntu
		* Fixed TCP obfuscation negotiation

	Gnucco:
		* Add option to ed2k link parser to display links in
		  emulecollection
		* Added test case for the CTag class

	GonoszTopi:
		* Various fixes to new colour code
		* Allow user to select display of transfer rates
		* Extendable list-control settings save/load code
		* Drop assumption that last search keyword is a filename
		  extension if length == 3
		* Instead of counting unicode characters in a Kad search now we
		  use the UTF-8 byte count to determine whether the keyword is
		  allowed or not
		* Use actual page size in mmap calls instead of a randomly
		  selected number
		* Fix custom Crypto++ path not shown by configure
		* Make <IMG> tags in aMuleWeb HTML 4.01 conforming
		* Fix HTTP proxy authentication
		* Use -static for the tests too, when a static binary is
		  requested to prevent configure succeed where compilation
		  would fail
		* Configure now checks only for the tools and libraries needed
		  for the selected components
		* Fix aMuleGUI looking for undefined switches
		* Fix the "blinking" in aMuleGUI's status line
		* Better reporting of Kad tag reading/parsing errors
		* Fix the unittests
		* Some code reorganization
		* Features/fixes ported from eMule:
			- Implement an alternate method to estimate the real
			  user count in the Kad network, which is not based on
			  our local routing table (0.49b)
			- Add double quote to word-boundary characters (0.50a)
			- Drop support for Kad 1.0 (0.50a)
			- Try to find the closest node alive (0.50a)
			- Fix a bug in Kad which would not enforce the search
			  tolerance in certain cases (0.50a)
			- Change Kad to work better in small LANs (0.50a)
		* Remove the unimplemented "Create backup for preview" option
		* Add variables to preview command like in user event commands
		* Disable 'Show all comments' in the file's context menu if
		  there are no comments/ratings available
		* Enable renaming (completed) shared files
		* Proper handling of %-escaped UTF-8 sequences in ed2k:// URIs
		* Drop support for nodes.dat version 0
		* Fix issue #1621: 'ed2k links containing unicode characters will
		  cause the filename to be truncated'
		* Fix issue #1634: Change charset to UTF-8 in amuleweb template
		* Fix installation with denoiser enabled
		* Add support for automake's --enable-silent-rules feature
		  (original idea by Gerd78)
		* Improved CFormat and enabled reordering of arguments for
		  translators
		* Several fixes and improvements for the sanity checker script
		* Fix bfd detection
		* Add year bumper script
		* Move statistics from config to statistics.dat
		* New preference setting to show application version on the title
		* Fix man page installation for several languages

	Greek:
		* Part number is now an extra column in the download list
		* Improvements to preferences dialogs
		* Redesign skin selection

	Grunt:
		* Sort downloads by time remaining now has shortest time on top and unknown on bottom

	jolz:
		* Fixed file locking between ed2k and aMule on Windows

	Kry:
		* Reworked user interface, separating download and upload views
		* Fix list double-buffering causing artifacts on refresh and when
		  showing a context menu.
		* Fix indexes after removing GUI items
		* Fixes to Windows build
		* Allow compilation with wxCocoa
		* Replace Color.h by new class implementation MuleColour
		* Lower class overhead and use two-level cache for pens/brushes
		* Added aMuleCMD project for MSVC.
		* Fixed UnitTests and aMuleCMD in MSVC to use _CONSOLE subsystem.
		* Preferences changes
		* Fixed problem with uploading to lowid clients (szsuj)
		* Sorting lists (automatically or by user interaction) doesn't clear selection anymore
		* Fix client version display for MLdonkeys
		* Added Xcode project for MacOSX build
		* Fixed the centering of icons and text
		* Enable vertical toolbar orientation on WIN32 too
		* Option to resume next file alphabetically, keeping in mind categories and priority
		* Fixed crash when column gets removed
		* Show remote filename in source list
		* Fixed crash in upload thread on shutdown
		* Dynamic adjustment of threshold for rarity of download files
		* Option to prevent the computer from sleeping while downloading in MSW and MacOSX >= 10.5
		* Mac fixes
		* Fixed "out of memory" crashes caused by wxWidgets - so wxWidgets 2.8.12 is required now!
		* Show warning dialog if "Change language" is selected and no languages are installed
		* Added backtrace support for MacOSX
		* Add locale support in the mac bundle with updated scripts
		  (translations are now supported on MacOSX builds)

	lfroen:
		* php prefix for lex/yacc

	LittleAbacus:
		* Search results can now be sorted by "knownness" state.

	marcell:
		* Fixed issue #892: Show data sizes >= 1.0 GB with three digits.
		* Fixed search 'Stop' button not stopping Kad searches.
		* Check Kademlia search results against original criteria.
		* Allow Kademlia searches with repetitive keywords.
		* Allow adding current chat partner to friend list from tab's context menu.
		* Allow not downloading files via HTTP if the requested file is not newer.
		* Removed white boxes around file rating icons
		* Implemented public shared directory names only containing actually shared subfolders.

	morph:
		* Patch to uniform and fix minor errors on man pages

	myth:
		* Feedback from shared files - add number of clients on queue.
		* New stats server

	Phoenix:
		* Fixed assertion when trying to preview files smaller than
		256 K.

	Skolnick:
		* Fixed autogen.sh for Bourne Shell

	Stu Redman:
		* Sort source list on opening and add file name to A4AF files
		* MSVC: optional GeoIP support
		* Faster progress bars with less overhead (without pens/brushes)
		* Show log messages in remote gui
		* More info in the Kad tab
		* Improved gaplist performance
		* Ported chat captchas (receive and send)
		  and "Advanced Chat Spam Filter" from eMule
		* Allow download of multiple search results if search list
		  is sorted by status (thanks to DarkNRG)
		* Fixed CFile::SetLength for large files
		* Reduce file handle usage by closing part files after idle time
		* Speed up selection of shared directories with many subdirectories,
		  fixed red marking of folders with shared subdirectories
		* Ban clients that uploaded bad data (based on CorruptionBlackBox from eMule)
		* Support wxWidgets 2.9
		* amuled for Windows (with wx 2.9)
		* Friends get recognized in the friend list control even if their IP has changed
		* Don't kick friend upload, don't kick release prio uploads (unless they take more
		  than half of the slots), and don't kick anybody else unless necessary (with GonoszTopi)
		* Fixed crash in remote gui when aMule exits
		* Added more media file types from eMule
		* Allow the user to cancel the app if Temp/Incoming is not found
		* Show downloads as shares in remote gui
		* MANY fixes/implementations for amulegui
		* amuleweb for Windows (with wx 2.9)
		* Show connected friends in blue in the friend list
		* Show total upload/download ratio in statistic tree
		* Fixed category administration in remote gui
		* Implement directory preferences in remote gui
		* MSVC build for alcc, wxCas
		* Fixed errors and crashes on parsing ED2K links with '/' in them
		* Configure option --enable-fileview
		* Bypass amulegui connection dialog with switch -s / --skip
		* Fixed Core Timer
		* Allow passing of ED2K links by command line to aMule, aMuled and aMulegui, making ed2k program obsolete
		* Don't ignore current category in amulegui when pasting a link
		* EC tools (amulegui, amulecmd, amuleweb) can use a local config dir now
		* Fixed crash in file system detection in Solaris
		* Fix: window size/position didn't get saved on some systems
		* More command line options for aMulegui
		* Allow webserver autostart on Windows
		* Fixed crash in "Out of space" user event handler
		* ALCC prints links to stdout now instead of stderr
		* Fixed memory exhaustion on high speed uploads
		  Thanks to RRM for endless patience!
		* Fix: Language English was not recognized and so reverted to "System default" at any change
		* Fixed printf output (unicode2char()) on consoles incapable of UTF8
		* Keep a list of all canceled files (canceled.met) and show them in magenta in the search list
		* Update status/color of search results on events from outside the search window
		  (like download started from EC) and in amulegui
		* Enable update of IP filter list through aMulegui and aMulecmd
		* Enable setting of "Check for new version on startup" through aMulegui
		* Fixed crash in CClientList::ProcessDirectCallbackList that had been around for ages (hopefully)
		* Fixed size of large files in aMuleweb's search results
		* Show completed downloads in aMulegui
		* Fixed international file names on Windows
		* Fixed hangup of EC connection in aMulegui
		* Fixed category deletion in aMuled
		* Fixed several crash bugs in Webserver
		* Improved memory usage, load time and speed of IP filter
		* Load IP filter in the background on startup
		* Show when a Kad search is finished in aMulegui (remove '!')
		* Fixed "pause/cancel/resume all" in aMulecmd
		* EC ZLIB compression can now be turned off in remote.conf with EC/ZLIB=0
		* Terminate HTTP downloads on exit
		* Projects for Visual Studio 2010
		* Fixed crash in http download
		* Speed boost for reload of shared files with large list of known files
		* Resolve MSVC compilation problem with separate strings in GUI
		* Fixed splitter bars in download and share view
		* Allowed creation of ED2K source links in KAD-only mode
		* Make friendlist in chat window resizable
		* Removed lag (caused by language pref) when opening preferences dialog
		* "Swap all A4AF to this (auto)" doesn't block sources with no needed parts any more
		* Don't lock up in an infinite loop if all servers are not resolvable or blocked by IP filter
		* Clients now always get uploaded a full chunk (removed setting)
		* Tell the user that changes of EC settings require a restart
		* Deleted and readded download now get shared
		* Speed improvement for upload queue, and clients never have same rank anymore
		* Fixed ed2k links where '|' has been replaced with '%7C'
		* Fixed multi line stdin redirected as batch into amulecmd
		* Allow enable/disable of IP2Country through GUI
		* "Clear completed" button now only clears downloads in current category
		* Completed downloads can be seen and cleared in amulegui
		* Bold lines in log window now for Windows too
		* Allow setting of friend slot from client list control
		* Fixed saving of splitter bar positions
		* Get rid of "clearlooks_style_draw_box_gap" messages in console
		* Fixed several crash bugs caused by deleted client objects
		* Fix a small memory leak in Kademlia code
		* Fix occasionally sending junk at end of packets
		* Fix child items in search result getting inserted in wrong positions
		* Shared files don't lose all information when they get renamed
		* Fixed crash bug with sources which are incompatible with our encryption setting
		* Allow passing of links > 256 chars to amulecmd
		* Prevent flicker when sorting already sorted lists
		* Prevent creation of more than 99 categories, since that's the limit
		* Fixed saving of sort orders
		* Allow switching through files in file detail dialog
		* Improve performance when many small files are hashed
		* Fix: if a file had more than two copies shared it was hashed on every startup
		* Show directory in search list for "view shared files" searches
		* Safe writing of known.met and nodes.dat (don't overwrite existing until write is finished)
		* Show directory in search list for "view shared files" searches

	Vollstrecker:
		* Unify copyright lines
		* Fixed clean and distclean targets for make
		* Various Updates in debian/ see debian/changelog
		* Added crash handling in command-line tools
		* Fix for autoconf-2.64.
		* Make amulecmd help command work without connection
		* New translation concept for manpages
		* KDE Plasma applet to show stats
		* Fix warnings with latest autoconf (2.67)

	woutermense:
		* Fix 'break/continue [n]' PHP implementation
		* Allow multiple download links in webserver

	Wuischke:
		* Simplify browser selection
		* Use DoIconize() for dclick on tray icon, too
		* Fix minimizing from tray icon
		* Add option to show chat messages in log
		* Add option to specify amuleweb binary location
		* Make EC authentication procedure more secure
		* Add support for categories to ed2k
		* Backup config file on shutdown

	Special Thanks To:
		* Greek for his contributions to aMule's user interface.
		* btkaos for his important work finding the source of bugs.
		* myth for seeing when everyone else was blind and uncovering
		  the grandfather of all fuck-ups
		* mirko.g for being so committed to compile aMule on Snow Leopard.

---

## Version 2.2.6 — "we don't have holidays"
2009-09-16

	GonoszTopi:
		* Fixed obfuscated server UDP communication.
		* Fixed cross-endian Kad node verification.
		* Fixed name conflict in builtin PHP parser.
		* Fixed configure finding unwanted Crypto++ installations.

	Marcell:
		* Properly update transfers tab's bottom pane's title.

	mr_hyde:
		* Fixed a bug in detecting and using the fallocate() function.

	Sam Hocevar:
		* Now really fixed that security issue.

	Stu Redman:
		* Fixed HTTP download if server transmits no content-length
		* Fixed several cases of amulecmd printing zero on big endian machines
		* Fixed amuleweb crashing on tiny downloads
		* Added version resources to MSVC binaries
		* Fixed wrong search text in search dialog after deleting a tab
		* Fixed download limit in amuled (which was 50% of what was set)

	Wuischke:
		* Fix amuleweb progress bar display for files > 4GB

	Special Thanks To:
		* stefanero and his bleeding-edge system

---

## Version 2.2.5 — "never say never"
2009-05-16

	GonoszTopi:
		* Fixed possible security hole when previewing filenames containing single quotes
		* Fixed default webserver port

	Stu Redman:
		* Fixed upload of the last part of a file which he broke in 2.2.4
		* Fixed setting speed limits from remote gui's tray icon

	Special Thanks To:
		* CroMag for pointing out the upload problem

---

## Version 2.2.4 — "we didn't have a .4 version since... well... long ago"
2009-04-03

	freddy77:
		* Plugged various memory leaks.

	FreeToGo:
		* Add comment to desktop file to allow autostart in Gnome

	gabrielix:
		* Compilation fix for gcc-4.3.2.

	Gaznevada:
		* Compilation fix for IRIX.
		* Fixed file handles on IRIX.

	GonoszTopi:
		* Fixed compilation of Format.cpp for some platforms.
		* Fixed wxWidgets socket library initialization.
		* Fixed partfile importer destroying imported data.
		* Separated GUI and core code in partfile importer, thus fixing
		  occasional crashes/hangs.
		* Fixed GeoIP-enabled builds crashing on 64b boxes.
		* Added another common URN ID to the Magnet link handler.
		* Switch to the 'busy' cursor while bringing up the preferences
		  window.
		* Ported several Kademlia fixes and improvements from eMule0.49c:
			- Fixes on handling incoming packets with port zero.
			- The Kad UDP firewalltest now asks several clients for
			  its external port, avoiding to get a wrong "Open"
			  state on NATs which change the source port on each
			  request but behave like a Full-Cone otherwise.
			- Made sure a received Kad routing answer doesn't
			  contain more contacts than requested. [Xin Sun]
			- Kad no longer allows more than 2 IPs from the same
			  subnet within one routing query reply (except on LANs).
			- Kad routing query contacts are checked against the
			  routing table.
		* Implemented non-interactive mode for amulecmd/amuleweb.
		* Fixed detection of crypto++ library for versions >= 5.6.0.
		* Fixed saving wrong window position when exiting while minimized.
		* Fixed rare case when we tried to connect to a LowID client.
		* MSW: detect WinSock API version needed by GeoIP.
		* Fixed libbfd sometimes depends on libintl, with help from PacoBell.

	iz0bbz:
		* Fixed static linking with GeoIP on MinGW/MSYS.
		* Fixed detecting GeoIP library when building for MinGW.
		* Compilation fix for GeoIP-1.4.6.

	Stu Redman:
		* Fix crash on global search on Windows
		* Fix splitter bar position in transfer window not restored properly
		* Caught some insane upload requests
		* Fixed finished files sometimes getting rehashed (thanks to Skolnick)
		* Added restart warning if the ED2K network was re-enabled.
		* Fixed Windows lag when opening preferences dialog
		* Fixed creation of ED2K links with AICH (thanks to Archmage)
		* Remote Gui shows a dialog box with a reason on connection failure
		* Changed fix for wrong ordering/placing of clients in the download window
		  so that sort order is again like in 2.2.2.

	Wuischke:
		* Add Asturian language
		* Updated INSTALL file
		* When EC authentication fails, close connection before we send
		  the response.
		* Tell the user why the EC connection failed.

	Special Thanks To:
		* wires for the strenuous testing on 64-bit

---

## Version 2.2.3 — "Late Christmas present"
2008-12-28

	Alfred:
		* Fixes to compile with Sun Studio 12.

	Gerd78:
		* Fix for linking with a static bfd library.

	GonoszTopi:
		* Fixed improper handling of EC connection failures.
		* Fix for shells not properly handling empty lists.
		* POSIX fixes in shell code.
		* Made not finding GeoIP non-fatal.
		* Check if --enable-geoip-static can be fulfilled.
		* Fixed loading of zipped ipfilter files. Thanks to CtrlAltDel
		  for the investigation of the problem.
		* Fixed alc progress bar for files >4GB.
		* Fixed #1056: amulegui: incorrect results when searching with
		  min size >= 4GB
		* Disable automatic sorting of dowload list while there is a
		  pop-up menu or file detail dialog displayed.
		* MinGW compilation fix.
		* Fixed GTK crash on closing search tabs. Thanks to btkaos.

	LittleAbacus:
		* Support multiple selections on CSearchListCtrl::OnMarkAsKnown().

	Skolnick:
		* Fix alc and alcc to work with files bigger than 4GB

	Stu Redman:
		* Fix crash when last category was removed with a completed file in it
		* Fix wrong ordering/placing of clients in the download window
		* Fix available fileparts display for large files
		* Don't open server UDP socked if ED2K is disabled
		* Reordered preferences, disabled ED2K/UPnP prefs if ED2K/UPnP is disabled
		* MSVC: solution for MSVC 2008 Express edition,
		  project for ed2k and fileview
		* Fix wrong file download rates in transfer window
		* Windows: fix broken core timer, use precise tickcount
		  and so fix download limit

	Wuischke:
		* Add checks to cas to prevent segfaults
		* Fix wxCas save file dialog for file types
		* Fix a buffer overflow error in cas

	Special Thanks to:
		* btkaos and CtrlAltDel for their invaluable help in tracking off bugs.

---

## Version 2.2.2 — "Similarity."
2008-08-08

	bomj:
		* Patch for alcc to improve usability

	Gaznevada:
		* implement getopt_long in cas for systems which lack it

	GonoszTopi:
		* Fixing denoiser
		* include <sys/types.h> before <regex.h> as by POSIX
		* Fix noinline in crypto for some systems
		* Fix display of ccache option
		* Add sources from search results for new downloads
		* Use output of gdlib-config for gd.h detection
		* Solaris mntent fix
		* wxMSW fix
		* Fix NULL pointer dereference
		* Fix for configure not using --with-geoip value in library check
		* Added pkg.m4 from pkg-config-0.23
		* Ported Kademlia Protocol Version 8 from eMule0.49b.
			- Kad now ignores multiple IDs pointing to one IP in
			  routing request answers
			- When calculating the total user count, Kad now uses
			  (if available) the real number of firewalled clients
			  for the calculation instead a fixed value. This will
			  take more effect when 0.49+ nodes become common
			- Kad no longer tries to add UDP firewalled (and therefore
			  mostly unreachable) nodes into its routing table,
			  reducing overhead and increasing reliability [Idea: Netfinity]
			- Optimized the Kad packettracking code to only track
			  packets which we check later, to save resources
			- Fixed a bug which let Kad sometimes assume a Kad2
			  contact to be Kad1 after probing for both versions
			- Did first small step in dropping Kad1 support by not
			  probing unknown Kad contacts for Kad1 anymore to save
			  overhead. Kad1 clients will nevertheless still be work
			  for now.
			- Several changes were made to Kad in order to defy
			  routing attacks researched by University of Minnesota
			  guys [Peng Wang, James Tyra, Eric Chan-Tin,
			  Tyson Malchow, Denis Foo Kune, Nicholas Hopper,
			  Yongdae Kim], in particular:
				- Kad contacts will only be able to update
				  themself in others routing tables if they
				  provide the proper key (supported by 0.49a+
				  nodes) in order to make it impossible to
				  hijack them
				- Kad uses now a three-way-handshake (or for
				  older version a similar check) for new contacts,
				  making sure they do not use a spoofed IP
				- Unverified contacts are not used for routing
				  tasks
			- When reading a nodes.dat without any verified contacts
			  (possible an old file version), aMule will assume all
			  contacts to be verified to avoid slowing down the
			  connecting process
			- Implemented a special nodes.dat file version suitable
			  for mass distribution.
		* Fixed not sending sources for clients that did not announce
		  their part availability.
		* Fixed all list columns being disabled in case of invalid data
		  in config file.
		* Fixed directory tree not available.

	Kry:
		* Fixed: Incorrect SX packets sent, plus no reply to
		  out-of-multipacket SX as a bonus

	MalaPraxis:
		* Remap colours on Windows
		* Add resources
		* Fix wrong usage of CPath::IsOk which caused an infinite loop on Import
		* Fix wxTempFile usage for compressed IPFilter files

	Phoenix:
		* Removed the dlopen() code from UPnP.cpp.
		* Added the m4 macro to test for libupnp.
		* Updated amule_build_install.sh to work with
		  --with-libupnp-prefix.
		* Changed the UPnP code to allow the use of a service without
		  having successfully subscribed to it. That should be enough
		  to deal with some lazy router implementations.
		* Do not unregister if no service is found
		* Save the found service even if subscription has failed
		* Fix for initialization of "resultstr" in cryptopp.m4.
		* Fix for message "Duplicate partfile with hash..." in
		  DonwloadQueue.cpp. It was using deleted corrupted data.
		* amule_build_install.sh now uses -a flag in unzip so that
		  cryptopp files are properly converted from DOS text format.

	Stu Redman:
		* Scanner fix for MSVC compilation
		* Fixed crash when progress bar was resized to zero width
		* Fixed sharing of large files on Windows
		* Fixed free disc space check
		* Sanity check before writing nodes.dat - don't write it
		  if there are less than 25 contacts
		* Download List sorted on startup
		* Splitter bar position in transfer window is restored again
		* Fixed a GDI resource leak for Windows

	Vollstrecker:
		* Made possible to deactivate xas
		* Various Updates in debian/ see debian/changelog

	Wuischke:
		* Show connection status in toolbar when changing skin, thanks to greek

	xor:
		* Fix window resize problem on Mac OS X
		* Fix for packets being lost in EC communication.
		  Fixes aMuleGUI not updating after a while.

---

## Version 2.2.1 — "Excuse me, have you seen my 2.2.0 release anywhere?"
2008-06-11

	Bas Zoetekouw:
		* Patch for debian bug #350396: "amule depletes entropy pool".

	brainnolo:
		* Patch for loading the correct path for the UPnP libraries
		  in Mac.
		* Added the binaries for libUPnP for Mac to the directory
		  aMule.app/Contents/Frameworks.
		* Universal Binary ed2kHelperScript update.
		* avoid removing libupnp libs during initial cleanup
		  (this would defeat bundling them) . It will now remove only
		  libwx in the Frameworks directory (which are supposed to be
		  from an old build).

	centaur:
		* OpenBSD patch.

	Coronas:
		* Patch to show kad status in amuleweb (Bug 1103)
		* typo in src/webserver/default/shared.php

	drkirkby:
		* Test for gcc before including gcc specific flags on the
		  compiler line.

	DLH:
		* amulegui.xpm icon.

	EastWind:
		* Patch to prevent overwriting of GDLIB_LIBS

	Gaznevada:
		* IRIX compatibility patches
		* amuleweb php IRIX patches
		* Make 64-bit architecture check independant of _ABI64

	Gerd78:
		* Added autostart-xas to rpm .spec files.
		* Patch for autoconf >= 2.60.
		* Patch for redefinition of $(docdir) in docs/Makefile.am.
		* Patch for aMule .desktop files.
		* Added amulegui desktop icon (with Vollstrecker).
		* Patch for fixing aMule spec file in Fedora and Mandriva.
		* Test for perl File::Copy in configure.
		* Fix for building with _FORTIFY_SOURCE.

	Gnucco:
		* Workaround for string serialization bug.
		* Workaround for aMule does not publish new files on kad.

	GonoszTopi:
		* Added ability to compile amulecmd without thread support in wx.
		* Fixed source seeds handling on startup.
		* Proper restoration of startup locale after checking available
		  locales.
		* Fixed linkage with wxMSW.
		* Got rid of a few more warnings.
		* Fixed #929: configure: BUILD_CC uses CC's CFLAGS
		* Implemented #962: don't display (0) when not downloading from source
		* Fixed #954 - added ability turn IPFilter on/off for servers/clients
		  independently.
		* Added support for magnet ed2k links.
		* Improve cross compilation
		* Fixed segmentation fault in amuled
		* Don't allow sources coming from .seeds to be cleaned up for a while
		  after startup
		* Improve accuracy for ticks
		* Improve debug output
		* Don't add clients when shutting down
		* Added a simple (ascii) text file reader class
		* Sed denoiser - removes excessive messages from compilation -
		  Thanks to Vollstrecker for the idea and discussions.
		* Drop path component from logged file names.
		* Fix for perl v5.8.8
		* wxCas compilation fixes for wxCVS
		* Doxyfile doesn't need to be installed, it's unusable without the
		  sources.
		* Fixed #979: No win32 version information
		* Updated listctrl code to 2.8.7
		* Fixed a buffer overflow in TextFile.cpp
		* Cross-compilation fixes.
		* Some little optimizations on configure.
		* Re-categorized a number of strings whether they need translation or
		  not.
		* Added plurals support.
		* Removed a number of unused leftover files from the repositiory.
		* Various fixes for wxMSW builds.
		* Made 'make dist' work.
		* Fixed 'make check' for subdirectory builds.
		* Fixed manpages install/uninstall script to handle correctly
		  subdirectory builds and respect the --program-transform-* switches.
		* Fixed a minor bug in the denoiser script.
		* Fixed several portability issues in scripts.
		* Fixed keeping the preferences in sync with tray icon existance.
		* Removed a check that wasn't ever valid.
		* Fixed #651: Wrong expansion in statistics.
		* Fixed #1082: Events in preferences have layout problems.
		* Fixed debug categories being added multiple times to the checklistbox.
		* Fixed translations on MSW.
		* Languages are not sorted anymore, but displayed in their own name.
		* Fixed a number of gcc4 warnings.
		* Fixed amuleweb compilation on MSW.
		* Added checks for a POSIX compliant regex library.
		* Fixed #1289: amule fails to build on non glibc systems (e.g. uclibc)
		* Hungarian translation.
		* Allow generating feedback from shared files.
		* Ported Kademlia2.0 Protocol Version 7.
		* Fixed 'bad file descriptor' error on Mac.
		* Unittest for the Kademlia::CUInt128 class.
		* Added kademlia and obfuscation status to the client details.
		* Fix for bars positioned 1 pixel too low.
		* Added a small debug utility to display contents of mule files (kad
		  only yet).
		* Fix for #1184; fixed both ed2k and kad searches for >4GB files.
		* Proper detection and usage (if possible) of strerror_r()
		* Added English names to the language selector - for the curious ones.
		* Fixed some memory leaks.
		* Got rid of the deprecated HAVE_GETTEXT macros.
		* Added gettext support to amuleweb.
		* Added preferences option 'Allocate full size'.
		* Added crypt overhead to statistics, UDP only for now.
		* Added checks to prevent downloading large files to file systems not
		  supporting them.
		* Added check for NetBSD systems.
		* Heavy rewrite of autoconf/automake stuff.

	gtoso:
		* Fix for GeoIP crashing if the default GeoIP.dat file cannot be found.
		* Patch to find GeoIP.dat in the application bundle.

	Hermit:
		* Patch for amulecmd history which ensures that when the same command
		  is repeated several times in a row it only gets recorded in the
		  history once.

	jcoy:
		* Set download priority in amulecmd.

	ken:
		* Fixed control-clicking (right-clicking) on tabs in notebooks on the
		  Mac.
		* Compilation fix for MacOSX 10.3
		* Fixed a crashing bug with static initialization order
		* Ship the license as required by the GPL.
		* Fixes linking of embedded CryptoPP (on the Mac, if nowhere else).
		* Quick-n-dirty hack for stats graphs on the Mac.

	Kry:
		* Protocol Obfuscation (enabled by default)
		* Large file support (>4GB)
		* Disabled auto-update of servers from clients and other servers by
		  default.
		* Fixed a bug while getting sources for large files (>4GB)
		* Fixed mldonkey_importer to work with mldonkey >= 2.7.6
		* Improve exception handling
		* Added a column on client view that shows if the user has reported
		  having disabled shared files.
		* Disable the "Show files" option in context menu if the user has
		  reported having disabled shared files.
		* Add generic CTag classes support for Kad data types
		* Remove kad IO classes
		* Safety on memfiles created from packets
		* Fixed publishing and sending shared files requests
		* Fixed Unittest
		* Update audio and video types
		* Update EC to use the equivalent of VBT tags
		* Fix ID sending on hello packet to use the hybrid ID instead of plain
		  ed2k id
		* Fix a bug on sending info to other clients on file list request
		* Upgrade lex generated code
		* Add the --reset-config flag
		* Modified getclosetsto() fix, originally by tatikiran
		* Changes to flex parsing of search expressions.
		* Fix several missing variable initializations
		* Swap bytes for int types in EC code
		* Lower reask times
		* Fix Memleak in ECSocket
		* Extend amulecmd with 'show log' and 'reset' command, originally by
		  quinox, bug #856
		* Usage of HOSTCC for compile-time executions
		* Created translation status scripts
		* Move server packets to the back of the UDP queue if the server is
		  still resolving a dynamic host
		* Script to wikify changelog
		* Separate ECTag from ECPacket
		* Fix crash on startup
		* Fix several rare memleaks
		* Fixes on Kademlia keyword store
		* Initial Kademlia 2 integration
		* Remove duplicated SendPacket functions in Kad
		* CPacket uses const CMemfile reference instead of pointer
		* Fix for (rare) bogus packets being send on kad
		* Fix for empty packets in Kad Search
		* Fixed server IP for EC
		* Don't destroy shareddir.dat on remote GUI, bug #945
		* Incorrect percentage displayed by amulecmd for files > 4Gb, bug #949
		* Ask user to download server list when list is empty and ed2k active
		* Support automake 1.10
		* Reorganization of EC code
		* Added script to generate EC files for different programming languages
		  (C#, Java and C++) from an abstract language
		* Dropped support for < wx2.8.x (in case you want to blame someone)
		* Added remote gui datastructure for new classes.
		* Fixed compilation with wx2.9, also with disabled 2.6 comatibility.
		* Heavily modified IP2Country code.
		  Proper names, guards, creation on the heap... etc.
		* Added script to create Kad nodes files
		* Fixes for emule-collection support
		* Added some sanity checks
		* Source links with crypt data support.
		* Fix Mac build
		* Remember kad and ed2k urls and restore them on restart.
		* Force conversion to be ISO8859 for tag names, obvious from the network
		  standards. This also fixes Kad.
		* Changed the inheritance for the UDP sockets to include the encrypted
		  layer
		* Fix for MuleGifDecoder issue
		* Windows fixes
		* Added OnO patch for Toolbar display.
		* Fixed validation of preferences items for wxWidgets 2.8.4
		* Fixed cryptopp version recognition on Mac.
		* Finish Protocol Obfuscation including GUI
		* Fix base for emsocket
		* Disable bison generation on Mac
		* Endian fixes
		* Fix compilation on wxCocoa
		* Make obfuscated state persistant
		* Change preferences order, add debug info
		* Fix getsources with large files
		* Add message on triggering new version
		* Fix spelling
		* Fix Windows compilation
		* Remove backups before moving logfile
		* Fix compilation
		* Fix for connecting to servers if encryption is required
		* Fix memleaks
		* Use proper base class
		* Remove unmaintained translations
		* Honour data root settings to remove warning
		* Make code compatible to MSVC
		* Fix to avoid losing packets
		* Avoid multi line strings in GUI to allow MSVC compilation
		* Fix wxIPV4address usage where amuleIPV4 is unnecessary
		* Change CVS string to SVN
		* Adjust MuleDebug
		* Fix file types due to overloads of EC
		* Moved browser preferences to "Browser/" section on config file.

	lfroen:
		* Fix partcount not being set in remote gui
		* Use only one EC library with amuleweb
		* Fix LastSeenComplete
		* Fix for NonCurrentSources
		* Fix incorrect cookie parsing for amuleweb
		* Fix passing strings in EC
		* Lock webserver when serving images
		* EC implementation in C# (work in progress)
		* Fix preferences in amuleweb
		* Fix EC crashing webserver when new item added
		* GUI implementation in C# (work in progress)
		* Implementing split() call
		* Compilation fix for MuleGifDecoder

	LittleAbacus:
		* Patch to show part file numbers.
		* set the search string to the search text of currently
		  selected tab.

	magicamule:
		* filtered off comments still affect rating

	MalaPraxis:
		* Fixed some cases where the full IP of a new client would be shown
		  incorrectly.
		* Added a "System Default" option to browser selection that uses
		  wxWidget's capabilities.
		* Fix MSVC compilation errors
		* Don't use wxFile flush on Windows
		* Toolbar fixes to fix assert on Windows
		* Use better defaults for preferences
		* Simplified minimize/raise code, remember maxmimized status between
		  sessions.
		* Make sure starting points are inside screen and sanity fixes
		* Fixes to view/restore, original function doesn't skip
		* Final fixes to Iconize()
		* Fix for broken native counter.
		* Change data types to clear warnings at /W4 on MSVC
		* Cleared MD5_ functions to use standard memset/memcpy
		* Cleared types, added asserts for debug, remove unused functions
		* More warnings cleared and more asserts
		* /W2 fixes on main MSVC project
		* Fix compilation of aMuleGUI
		* Enable compilation with wx 2.9
		* Fix Kad1.0 and Kad2.0 search types
		* Enable dynamic GUI reordering when networks are disabled
		* Disable packing of non-POD structures
		* Change structures with constructors to classes
		* Small MSVC fixes, major speedup and adjustment for networks
		* Don't use ++ to modify a var value if you assign to same var
		* Speedup for some classes as copying is unnecessary
		* Further fixes for VS
		* Fix notebook logs/info tabs display
		* Better macro use
		* Add MSVC solution and readme
		* Fixed bug on socket event GetResult(), MSVC fixes on files
		* Fixed direct callback for type 6 sources for Kad2.0

	morricone:
		* Fix for wxwin.m4 not autodetecting wxBase.

	mr_hyde:
		* Patch to enable Kad search with amulecmd.
		* Fix for some man pages have wrong name with
		  --program-suffix.
		* Temporary fix for tarball configure.in using SVNDATE.

	Nodsu:
		* Patch to make amulecmd cancel/pause/resume work with many
		  files and file names.
		* Patch to enable preview in remote GUI.
		* Patch to create the magic string $file in previews. This
		  string is replaced with the file name in the command line,
		  in case it exists.
		* Patch to prevent amule compiled with --disable-nls from
		  crashing.

	nvinay:
		* Trivial issue with memset found using google codesearch which may
		  affect only the debugging.

	Phoenix:
		* Fix for crash in amulegui/DownloadListCtrl.cpp.
		* Upgraded extern/listctrl.{cpp,h} from wxWidgets cvs code.
		* Fixed some gtk2 warnings in extern/listctrl.cpp.
		* Fix for unhandled exception in new skinned toolbar code.
		* Coding style fixes.
		* Fix for server disconnection during global search.
		* No more wxARRAY's in amuleweb.
		* Fixed bug in mutex code in amuleweb (s_mutex_wcThreads).
		* No more wxARRAY's in aMule code.
		* Fixed bug in ECPacket.cpp: assignment inside assertion.
		* Changed CECSocket constructor to be exception safe.
		* Fix for invalid rectangle size on COScopeCtrl::PlotHistory().
		* Removed the default constructor for Kademlia contacts.
		* Fix for "get bwlimits" command in amulecmd always returning
		  zero for maximum download value.
		* Added UPnP support.
		* Fix for crash in ECSocket.cpp.
		* FileDetailDialog:: now has more intuitive Apply, Ok, Cancel
		  interface.
		* GUI to enter a specific bind IP in
		  "Preferences->Connection->BindAddress".
		* Resurrected support for the tag FT_DL_ACTIVE_TIME in the met
		  file. It's value, the download active time, can now be seen
		  in the file details dialog.
		* Added the DLACTIVETIME variable to the list of replaced
		  variables in the DowloadCompleted user event.
		* MuleTrayIcon.cpp was not compiling for __WXMAC_CARBON__.
		  Seems to be fixed, but must be the code now has a lot of
		  ifdefs and must be tested on other platforms.
		* Added two more events: "out of space in temporary partition"
		  and "error upon completion".
		* Fixed a crash in amulegui when adding a new category.
		* Fixed a bug in amulegui, removing a category remotely did
		  not update the category count in amule.conf, so the next
		  time amule was run, the category was there again.
		* Fixed a bug in toolbar skins, the skin file was opened even
		  when the checkbox "Use skins" was not checked.
		* Fixed a crash related to MuleGIFDecoder wx-2.8.0 when
		  downloading the file IPFIlter.dat.
		* Fix for ECSocket.cpp, amulegui was crashing upon entry.
		* Fix for ClientDetailDialog in amulegui. Was showing
		  incorrect IP / Server / Software version information.
		* Switch binding of UPnP libraries to use one digit version
		  names instead of unversioned names.
		* Fix for crash in amuleweb when the image file did not exist.
		* UPnP add/delete port mappings are now done in every device
		  found, instead of only the first one.
		* Creation of --enable-upnp/--disable-upnp configure flag.
		* Update of wxWidgets-2.6.3 deprecated code to version 2.8.2.
		* Fixed IPFilter.dat loading from a zipped file.
		* Added a termination process to wxExecute() calls, so that we
		  no longer leave zombies.
		* CDirIterator now uses wxDir.
		* CheckDirExists() now uses wxDir::Exists().
		* CheckFileExists() now uses wxFile::Exists().
		* GetLastModificationTime() now uses wxFileModificationTime().
		* GetFileSize() now uses wxFile::Length().
		* UTF8_CopyFile() now uses wxCopyFile(). Later reverted for locale
		  fixes.
		* UTF8_RemoveFile() now uses wxRemoveFile(). Later reverted for locale
		  fixes.
		* UTF8_MoveFile() now uses wxRenameFile(). Later reverted for locale
		  fixes.
		* theApp is now a global pointer, so that we can access the
		  global application object from within a core file.
		* Partial fix for the COLORREF compilation problem on Windows.
		* Fix for libpng version detection on acinclude.m4. It was
		  failing for strings like 1.2.15beta5 (e.g., debian 4.0 etch).
		* Fix for theApp variable usage in amulegui. It was not beeing
		  initialized and amulegui was segfaulting.
		* Fixed the forum address in the backtrace print.
		* Applied Bas Zoetekouw's patch for debian bug #350396:
		  "amule depletes entropy pool".
		* Implemented IP2Country using GeoIP.
		* When converting from multibyte to wide characters,
		  ConvAmuleBrokenFileNames now tries UTF-8 first. If this
		  fails, then it tries ISO-8859-1.
		* New directory based skin support, reworked Trevino's patch.
		* Fixed amuleweb crashes due to bug in ECSocket.cpp
		* Code to refresh port mappings in the event of a temporary router
		  failure
		* Code to deal with previously unhandled UPnP events.
		* Fixed remote-gui segfault in UpdateStatsTree()
		* syscall_check is no longer a macro
		* Fixed a serious bug introduced by ENABLE_UPNP Makefile.am switch
		* Fix for libpng version detection on acinclude.m4
		* Fix for server list and node list
		* Made some common dialog modals and giving them a default style
		* Handle different UPnP library versions
		* UPnP for amuleweb.
		* Fix for crash on exit and a little less redundancy.
		* Trying to make listctrls behave on Mac.
		* Fix for CheckFreeDiskSpace(). Was probably returning ok if
		  the directory where the file would be saved did not exist.
		* Fix for overflow in CPartFile::HashSinglePart() as reported
		  by visualage.
		* Fix for overflow in CSharedFilesCtrl::DrawAvailabilityBar()
		  as reported by a3linux, CtrlAltDel and stefanero. Special
		  thanks to a3linux for the backtrace.
		* Improoved the macro CHECK_CRYPTO() in acinclude.m4.
		* Fix for the check of cryptopp library version in
		  configure.in.
		* Rewrote the cryptopp m4 stuff.
		* Fixed some memory leaks related to the use of
		  CTerminationProcess.
		* Fixed the usage of CryptoPP::Base64Encoder when creating the
		  key pair for ClientCreditsList. cryptopp semantics is to
		  give the ownership, so do not create objects like this on
		  the heap.
		* Fix for amuled creating zombies. wxProcess does not work
		  with wxBase.
		* wxProcess now receives OnTerminate() events in amuled.
		* Created a specialized termination process object for
		  amuleweb, so that amule does not kill the web daemon if it
		  has already died. This fixes a segfault upon exit.
		* Changed the amule_build_install.sh script to work with
		  distro tarballs for release.

	pochu:
		* Fix for subdirectory builds.

	Radek:
		* Patch to fix windows compilation.

	Raziel:
		* Adapt Kad code to the standard coding guidelines.
		* Work on EC API

	spiralvoice:
		* Patch to enable MLDonkey os_info support.

	Skolnick:
		* Added the time to the aMule stats in the wxCas window and
		  in the generated image.
		* Added the time to the aMule stats in the cas output and
		  in the generated image
		* Added option to generate image in JPG format (along with PNG)
		* Added new icon for aMule

	Stu Redman:
		* Fix for Transferred / Completed not updated in remote GUI.
		* Fix for PARTSIZE not being 64 bits. Enums are always 32
		  bits, even if we use a 64 bit constant to initialize it.
		* ratings/comment marks are now shown in the main transfer
		  window of the remote-gui (the little colored !! on the left).
		* comments are now updated when comment packets arrive (not
		  only when the show comment dialog is open).
		* remote names are now updated once on startup. So there is no
		  more 3s lag until the names are shown when the dialog is
		  opened for the first time.
		* ED2K/Kad User/Filecount is now shown in the remote-gui status
		  bar and on the Kad Tab.
		* Fix for crash on receiving zero-sized UDP packet.
		* New BarShader code.
		* Sparse partfiles on Windows.
		* Fix for zlib detection with an optimizing compiler on configure.
		* Made all part-status bars look the same.
		* File names in file detail dialog can be scrolled without
		  messing up the list control
		* Fix for copy constructor

	Tiziano Müller:
		* Fixed compilation when --enable-geoip is used in conjunction
		  with the ld-flag "--as-needed".

	Trevino:
		* Fix for "Both the Unknown client icon and the Unknown status
		icon points to the same file" issue.
		* Skin support with relative paths.

	visualage:
		* Fix for aMuleWeb unicode search/download link error.
		* Fix for aMuleWeb segfault when refreshing too frequently.
		* Fix for regular expression in aMuleWeb-PHP/split function.

	Vollstrecker:
		* Added possibility to give the path for output right with
		  -p or -o in cas.
		* Changed cas to use getopt_long.
		* Added --config-dir and -c option to cas.
		* Added alias -H --html to cas.
		* Added alias -P --picture to cas.
		* Added --config-dir and -c option to ed2k.
		* Added --config-dir option to amuled.
		* Fixed typos in the man pages.
		* Added manpage for amulegui.
		* Added amulegui desktop icon (with Gerd78).
		* Manpages update.
		* Add debian folder.
		* Correct use of libcrypto >= 5.5 and update of debian-dir.
		* Added Option to use generic ipfilter.dat.
		* Made possible to select which translations get build and
		  installed.
		* Install only manpages in requested Langs.

	wuischke:
		* Add emulecollection support on aMule ED2K Links Handler
		* Fix online signature update rate
		* Fix display of filesize > 4GB in file detail dialog
		* Fix toolbar import/about icon order
		* Add option to load emulecollection in SharedFilesCtrl
		* Add oga and ogv extension for file type search
		* Allow skin/webserver template section via wxchoice + skin enhancement
		* Some error messages rephrased, to improve readability
		* Fix idle mode for UBT
		* Fix Ctrl+a in MuleListCtrl
		* Replace (f)lex by $(LEX) in Makefile.am files
		* Fix libUPnP unloading.
		* Fix building with external CryptoPP
		* Ship skins with tarball
		* Convert skins shipped with aMule to new format
		* Display file size in human readable format in FileDetailDialog
		* Make SVN compile again
		* Some skin code improvements
		* Added upload feedback
		* Added option to enable EC and set pass in amuled
		* bugfix for ec-config option
		* Removed GetLocaleDir()
		* Zipped skin format
		* Fix utf8 problem with file names
		* Fixed toolbar display with skins when blinking on incoming message
		* Fix #1114, missing break statement, thanks to mr_hyde
		* Add option to filter file comments
		* Allow compilation against wxBase
		* Remove Source Dropping
		* Allow usage of local config dir
		* Display log message in bold when using local config dir
		* Extend range for slot allocation, change default value
		* Change Kb to KB
		* Suppress skin directory error
		* Add Upload feedback
		* Fixed GetFeedback
		* Correct some spelling mistakes
		* Always use SecIdent
		* Re-Add option to disable SUI
		* Fix sharing files with extended characters
		* Fix utf8 problem with file names
		* Mark cancelled/removed files grey in search
		* fix search colors implementation
		* Add maintainercleanfiles for make distclean
		* Fix comment icon order and use unitary width for display
		* Fix rating display in SearchListCtrl
		* Fix permission check on Vista
		* Fix compilation with mingw
		* Check for and use SVNDATE in tarballs
		* Move include up to allow compilation on mingw
		* Fix compilation with mingw32
		* Fix compilation on Mac
		* Fix compilation in ClientListCtrl.cpp
		* Fix linking on Windows/mingw32
		* Fix linking of amulegui for Windows
		* Fix problems with collections using CRLF line endings on *nix
		* Fix compilation for gcc 4.3
		* Dirty compilation fix for gcc 4.3
		* Fix compilation on OpenBSD (and probably other Unix)


	Xaignar:
		* Renaming the SearchList typedef to CSearchResultList
		* Splitting CSearchFile out from SearchList.* to SearchFile.*.
		* fix initialization of member variables in CSearchFile when
		  creating on remote gui.
		* Call GetLength safely when sharing files
		* Added support for child results to CSearchListCtrl
		* Major cleanup of CSearchList
		* Add logger target for the thread-scheduler
		* Add smart pointers CScopedPtr and CScopedArray
		* Fix possible crash due to pending events
		* Fix accessing empty list in CMuleListCtrl
		* Add support for displaying large files with CBarShader
		* Improved sanity checking and simplified exception-handling
		  via CScopedPtr and CScopedArray.
		* Major reworking of threads, add a thread scheduler for
		  IO intensive tasks, improve thread-safety for AICH-sync thread
		* Fix FileIO unittests and add test of const CMemFile objects
		* Update AICH from eMule-0.47a Beta1
		* fix positioning of individual frames
		* Improved exception handling
		* Updating the FindMatchingClient function
		* Avoid dangling pointers in case of asserts failing
		* Updating CFormat to properly handle 64b ints on all platforms
		* Fixing CFile::GetAvailable if position is past EOF
		* Fixed possible use of uninitialized variables
		* Adding template function for freeing the contents of a list/map
		* Remove CList
		* Fixing a couple of infinite loops
		* Fixes file completion under amuled
		* Add locking to the ED2KLinks file
		* Removed multiple macros for array size
		* Removed the CMD4Hash from wxString constructor
		* Add swap function to CRangeMap
		* Reworking of the notify-code
		* Optimized and simplified adding of shared files to the listctrl
		* Remove partially copied files when a UTF8_CopyFile fails.
		* Drop the file/directory permission settings, use umask
		  instead.
		* Fixed loading of version information for servers. Previously
		  the information saved in the servers.met file was ignored.
		* Fixed problem with reading ST_AUXPORTSLIST tags for servers,
		  where empty tags would cause the existing server-port to be
		  overwritten, thereby preventing connections to that server.
		* Fixed linking of libmuleappcommon, which would previously
		  include GUI related symbols, thereby breaking amuled in some
		  cases.
		* Added fuzzy sorting method for strings, currently only used
		  for sorting server-version information.
		* Fixed sorting of the "Static" column on the server-list,
		  which didn't conform to 'strict-weak ordering'.
		* Added missing catch-statements in places where subclasses of
		  CSafeDataIO was used, thereby preventing crashes in case of
		  funky files/filesystems, such as network drives only
		  supporting up to 2GB files. (closes bug #878 and #1205).
		* Fixed opening of the Help-page when modifers were applied to
		  F1, which was causing conflict with various system-wide
		  shortcuts (this closes bug #1200).
		* Used -isystem to mark wxWidgets and Crypto++ include files
		  as system-files, thereby reducing the number of warnings
		  generated by these includes.
		* Fixed the shared-files-list ctrl assuming that all items
		  were part-files when creating feedback, which could cause
		  wrongful casts of CKnownFile objects.
		* Changed from using signed longs to store pointers in
		  wxListCtrl, to using wxUIntPtr, which is guranteeded to be
		  able to contain pointers on all platforms.
		* Fixed unicode-chars not being registered by key-events for
		  wxListCtrl (applied to our local copy).
		* Fixed various problems with using arrow-keys and other
		  control-keys on the listsctrls in aMule.
		* Fixed checks for changes in .part files between runs, which
		  previously was entirely broken (checked both wrong
		  timestamps and files).
		* Fixed saving AICH-hashsets to an empty file, where buggy
		  sanity-checks were causing the result to be discarded.
		* Improved the CreateHashFrom* functions, preventing the
		  hashing of empty files, and accessing an empty vector.
		* Added a workaround for a bug in wxNotebook, which would
		  cause the selection returned in page-changed events to
		  sometimes be invalid, thereby causing aMule to crash when
		  attempting to access an non-existing page. This should fix
		  some crashes assosiated with closing search-result tabs.
		* Dropped the internal Crypto++ libraries. Most distros have
		  it these days, and it's just another headache for us to
		  support (and was becomming pretty outdated).
		* Improved checks for NULL points in CClientListCtrl.
		* Fixed some poor english in various logging messages.
		* Improved thread-safety in various classes, in part because
		  wxString isn't threadsafe, and we use that class a lot.
		* Added support for writing 64-bit ints in CTags, which was
		  needed for some server-packets.
		* Improved debugging-information support in CTag.
		* Fixed saving/loading of 64-bit ints for Kademlia, which were
		  sometimes sent as binary blobs. Previously, we would read
		  from the net and save them to 'src_index.dat' just fine, but
		  would fail when it came to reading them from
		  'src_index.dat', resuling in that file being unreadable.
		* Fixed the corruption of some tags (mostly Kademlia), where
		  the tag-names were wrongly saved as UTF-8, though they
		  should have been saved unchanged. This closes bug #1188.
		* Applied various fixes to better conform to ANSI-C++.
		* Fixed repeating of CPPFLAGS when compiling with GeoIP
		  enabled, which caused problems when -pedantic was used.
		* Fixed a couple of small memory-leaks in UPnP (bug #1230).
		* Added the "printf" attribute to printf-like functions in the
		  webserver code, allowing for compile-time error-checking.
		* Fixed potential crashes that would result from server
		  connection attempts that timed out before the hostname
		  lookup returned.
		* Worked around crash in the taskbar icon, which would trigger
		  if the kicker crashed.
		* Fixed safehash-check for files greater than 4GB.
		* Added support for pretty-printing of classes to CFormat.
		* Added a class for the transparent handling of paths, needed
		  because we want to be able to handle both mangled (saved in
		  the wrong locale) and normal filenames. This should fix
		  problems with accessing files with extended chars in the
		  filename.
		* Added warning in case port could not be bound to the
		  hostname specified in the preferences.
		* Made outbound connections use the hostname specified in the
		  preferences. Is possibly not fully functional.
		* Fixed memory-leak when adding invalid ED2K links.
		* Fixed crash when the hashing-result from a now deleted
		  part-file was returned.
		* Allow the update of the server-list from the remote gui.
		* Optimized file-syncing, by only flushing the file contents,
		  rather than the meta-data (timestamps, etc).
		* Fixed possible redefinition of the VERSION define.
		* Fixed redundancy resulting from the use of two different
		  list of file-extensions, used when determining the filetype.
		* Dropped support for importing configuration files, and the
		  like, from older eDonkey and *Mule clients, as most of these
		  were extremly old.
		* Re-added double-buffering for listsctrls, in a manner that
		  should hopefully avoid the problems seen previously.
		* Fixed missing unicode-convertion on a number of packets when
		  sending to unicode-enabled clients.
		* Fixes passing of the error-code to OnReceiveError in
		  CMuleUDPSocket::OnReceive.
		* Improved handling of invalidated (closed) UDP sockets, caused
		  by the fact that wxWidgets errorously treats empty datagram
		  packets as EOF.
		* Fixed setting priorities for part-files on the remote gui
		  (this resolves bug #1251).
		* Improved debugging information when using CFormat.
		* Rewrote the CTextFile class, improving the reading speed,
		  and adding the functionality for writing files.
		* Improved sanity-checks in the CQueuedData class, thereby
		  preventing the possibility of memory-corruption resulting
		  from mangled packets.
		* Added autoconf check for broken exception-handling.
		* Added subclass of Cfg_Str for loading/saving paths.
		* Added functions for checking permissions of dirs/files, and
		  for retrieving the free space at a given location, to CPath.
		* Increased minimum free size needed before writing ".met"
		  files from around 5KB to 100KB, as ".met" can easily be
		  much larger than 5 KB in size.
		* Improved checks for permissions of directories, and insured
		  that the fallback directories are also checked in the case
		  were the user-specified directories are inaccessible.
		* Changed temp/incomming dir variables to "CPath"s, using the
		  previously added Cfg_Path class.
		* Fixed spurious warnings caused by not checking if certain
		  preference files existed before trying to read them. Also
		  removed an unnessesary warning for when known.met doesn't
		  exist.
		* Added wrapper-class for wxThread, to allow us to safely
		  terminate joinable threads without using Delete, a function
		  that is only intended for use with detached threads.
		* Fixed cancelled downloads being reported as succesful.
		* Fixed warning about dirs without shareable files, in the
		  case where there were sharable files, but they were all
		  duplicates.
		* Added support for saving directories (shared, incoming, etc)
		  as well as the filenames of known files in an
		  locale-independant manner, so that changes in locale does
		  not affect our ability to find previously used files or
		  directories. This will break backwards compatibility when
		  using unicoded directory-names.
		* Fixed the search-string being cleared when starting the
		  first search.
		* When starting a search, the entire search string is selected.
		* Fixed creation of ED2k-links with an AICH-hash, in case the
		  file does not actually have a AICH-hash. Also disabled the
		  option in the shared-files window when the file lacks an
		  AICH hash.
		* Removed workarounds for old (and resolved) wxWidgets bugs.
		* Fixed creation of ED2K links without sources, where an
		  superflous "|/" would be appended to the end of the link.
		* Fixed handling of spaces when creating ED2k links.
		* Fixed swapped notify-functions, which caused deleted
		  client-objects to be left on the upload-queue on the GUI.
		* Improved enabling/disabling of items on the right-click menu
		  on the download queue. Among other things, it is now
		  possible to stop a paused download, without having to
		  restart it first. This closes bug #1078.
		* Fixed the setting of priorities for shared files via the
		  remote GUI. This resolves bug #1267.
		* Fixed clipping issues when columns are resized to very small
		  width, causing the contents of one column to be drawn on top
		  of the next column. This closes bug #1171.
		* Fixed copying of text to the clipboard, which previously
		  used the "primary" clipboard (middle-click) under X11. It
		  now uses the default clipboard, which is what DEs typically
		  use for Ctrl+C/V/X. This resolves bug #1139.
		* Improved the displaying of the connection status, and fixed
		  problems where the status of only one of the active networks
		  would be displayed. This resolves bug #981.
		* Fixed percentage display of available parts in the
		  file-details dialog, where the decimal portion of the value
		  would always be zero. This resolves bug #1060.
		* Improved thread-safety of the AICH-sync thread on amuled,
		  and prevented the possibility of deadlocks in a few cases.
		* Fixed bug where the preferences dialog on the monolithic
		  client would not be updated, if the preferences had been
		  changed via EC after the dialog had been first shown.
		* Added support for protocol-obfuscation configuration via
		  the EC protocol.
		* Fixed problem where obfuscation of out-going connections
		  could be enabled even if obfuscation support was not,
		  leading to clients being wrongly dropped.
		* Fixed check-boxes in the preferences dialog for the various
		  obfuscation options not being updated, when one of the other
		  obfuscation check-boxes were checked/unchecked.
		* Added the ability to update the nodes.dat file, and
		  bootstrap from specific IPs,  when using the remote GUI.
		* Added saving/loading of the previous URLs for the server.met
		  and the nodes.dat files, when using the remote GUI.
		* Allow for the creation of ED2k-links on the remote gui.
		  This resolves bug #893, #567 and #584.
		* Fixed link-creation for kad-only clients.
		* Fixed drawing of the grid for statistics-graphs on wxMAC.
		* Reduced needless offscreen drawing of statistics-graphs.
		* Fixed possibility of misordered points on statistics-graphs.

	xor:
		* Fix for crash on amuled when starting up kademlia.
		* Fix for crash when creating backing bitmaps for graphs.

	ycjhi:
		* fix for OSX aMule-CVS-20071115 fails in loading libixml and
		  libupnp.
		* fix for aMule-CVS-20071115 doesn't update server.met on
		  startup.

	Special Thanks to:
		* GeVauDan and gulp for their incredible 'litoral' webserver skin.
		* FreeToGo for implementing the first version of IP2Country on
		  the forum.
		* Mark James (http://www.famfamfam.com) for providing the
		  flags icons and mischamajskij for his unknown icon
		* deloun and mischamajskij for their work on aMule skins and
		  icons for aMule
		* Dimitrios Galanakis for his work on language improvements
		* Bun Bun, for being there to tell me I'm not stupid.

---

## Version 2.1.3 - The "We missed the 6/6/6 devil release and we're very sad" version
2006-06-11

	GonoszTopi:
		* Fixed windows compilation, that was still broken.
		* Fixed locale bug. See http://forum.amule.org/thread.php?threadid=10178&sid=

	ken:
		* Fixed control-clicking (right-clicking) on tabs in notebooks on the
		  Mac.
		* Fixed SmartLowID checks based on a patch/report by eyalzo.

	Kry:
		* Fixed GonozsTopi's fix for locale bug (double init).
		* Added script to import mldonkey downloads into aMule.
		* Fixed "0000867: French traduction is uncorrect grammatically".

	rene06:
		* Allow amulecmd to execute a global, local or kad search. Then
		  you can get the results, which are shown in a list. From that
		  list you can choose one file to download.

	Special Thanks to:
		* Me, because I'm the only one bothering to compile the changelogs. Go me!

---

## Version 2.1.2 - The "We're on fire!" version
2006-03-28

	GonoszTopi:
		* Fixed some warning messages.
		* Fixed windows compilation.
		* Fixed compilation in release mode.

	Kry:
		* Fixed initialization of Partfile, Server and Knownfile objects
		  on remote GUI.
		  This fixes a good bunch of bugs, including but not limited to:
			* 0000741: the total speed possible is incorrect.
			* 0000774: Amulegui show comments ->segmentation fault.
			* 0000605: Incorrect ICH statistics data
			* 0000812: amulegui: wrong ed2k ports in server list
			* 0000776: amulegui segfaults
		* Fixed potentionally huge memory leak on EC. This is the main focus
		  of this release, but that didn't stop us from adding more stuff ;)
		* Fixed "0000809: Amulegui: Changing toolbar orientation shows the
		  Import button."
		* Reworked core/GUI comment handling to allow for future display of
		  comments on remote GUI, and meanwhile, added an nice message to
		  notify it's disabled.
		* Fixed "0000738: Set search type to KAD if only KAD is selected as
		  usable networks in settings"
		* Fixed amule.conf not being saves on remote preferences change.
		* Fixed ping time on servers, down to msecs resolution now.

	lfroen:
		* Prevent bad_alloc thrown on invalid connection attempts on EC.
		* Adding support for 64-bit filesize to webserver and php

	lionel77:
		* Display "Share Ratio" in shared files list.

	Phoenix:
		* Compilation fix for auto_ptr<> on Mac.
		* Fixed crash on amulegui when exiting.
		* Fix for CheckDirExists() for empty directory string.
		* Slightly more informational error message in amuleweb when
		  the template is not found.
		* Fix for bug in ReadyPath() function.
		* Create a backup of the log file upon init.
		* Added SOCKS4a support.

	TimDzang:
		* Fix for wrong filename string in IPFilter.dat.

	Vollstrecker:
		* Added check if locale could be set, before adding the language to
		  the options dialog.

	Xaignar:
		* Ensured that partial files left from failed file-completion attempts
		  would be removed.
		* Fixed crash on remote gui when attempting to reload the ipfilters.
		* Fixed sorting of servers by ping-time, such that servers without a
		  known pingtime are sorted last.
		* Added a "Password incorrect" message to the login pages, for when
		  login failed. Also added a warning in case no passwords were set.
		* Ensured that known-file objects are properly initialized on the
		  remote gui. This among other things fixes not all of the items on
		  the sharedfiles list showing a 'has-comment' flag.
		* Compilation fix for GCC 3.2.
		* Fixed CheckDirExists not working for root-paths (on both windows and
		  linux) and not handling all types of path-separators on windows.
		* Fixed security problems with aMuleWeb:
			* All images could be accessed, even when not logged in, and this
			  included dynamically generated images, such as progress bars and
			  graphs, resulting in various information leakage.
			* It was possible to craft an URL such that any image on the
			  harddisk would be returned, provided that the full path was
			  known. File types were decided by the filename extension and
			  included 'gif', 'jpg', 'ico', 'png', 'bmp' and 'jpeg'.
			* When logged in, it was possible to craft an URL such that any
			  html or php file on the harddisk would be returned, provided
			  that the full path was known. File types were decided by the
			  filename extension and included 'html' and 'php'.
		* Decreased the minimum value for Max-Connections in the preferences
		  dialog to 5.

	Special Thanks To:
		* The usual people
		* From Kry: to the one that makes it all worth it.
		* quinox, for helping us find the security hole in aMuleWeb.

---

## Version 2.1.1 - The "There can be only two! Point one! Point one!" version
2006-03-18

	GonoszTopi:
		* Fixed sources coming from an 'Unknown' origin.

	ken:
		* Fixed Mac aMule showing erroneous version number in Get Info.
		* Disabled the HTTP download progress dialog on Mac (again) because
		  it causes crashes.
		* Suppressed an error dialog on failure to lookup the host's domain
		  name.  Demoted it to just a message in the log.
		* Fixed a bug in ed2kHelperScript.app (the Mac ed2k link handler)
		  which prevented it from working properly if there was a space in the
		  path to the aMule application.  Thanks to Gomaaz for finding this bug.
		* Eliminated false reports of failure to execute the on-completion
		  command.  This happened with amuled and an on-completion command which
		  completes quickly.  Thanks to s0undt3ch for reporting this bug.

	Kry:
		* Fixed a bug on sending sources where sources won't be send to a client
		  uploading from us if he uses multipacket.
		* Fixes some crashes, on systray dying, tho not all till wx is patched.
		* Fixed some possible problem with userhash generation, that could lead
		  a void userhash.
		* Fixed defs.h include on MuleDebug.h causing compilation problems on
		  some systems (must be first wx include).
		* Fixed search type "Any"
		* Fixed translation of empty strings, which is reserved to gettext and
		  must never be used.
		* Fixed the aMule.app container lacking a Frameworks/ folder and thus
		  making the generate_package script fail.
		* Fixed compilation of wxCas with wxWidgets CVS (2.7.x)
		* Fixed ED2K id wrongly used on kad-only setups.
		* Added the --reset-config flag
		* Fixed Kad's sources/nodes search results, based on a patch by tatikiran
		  and further modified by John (eMule) and me.
		* Removed Razorback 2's stats while it's gone.
		* Disabled vertical toolbar on Windows while wxWidgets doesn't fix it.
		* Fixed aMule failing to find configuration folder and any folder that
		  finishes with a "\" on windows. This leaded to shared folders not being
		  shared, too.
		* Fixed drives on windows not being correctly tested.
		* Changed default server.met

	Radek:
		* Fixed amulemd output not being printed immediatly when running in a
		  mingw terminal.
		* Added missing include to GetTickCount.h, which caused the function
		  declaration to be missing in some cases.

	Raziel:
		* Fixed "0000690 bug for browse windows in amulegui"

	Xaignar:
		* Fixed problem with recursivly sharing folders that hadn't been
		  expanded in the tree ctrl.
		* Improved detection of external Crypto++ versions.
		* Fixed somee possibly crashes, caused by failed unicode convertions.
		* Improved error-checking when creating the .aMule data folders.
		* Fixed problem with searching for files of type 'Program', if a
		  search of a different filetype had been done just before.
		* Fixed a problem with shared files, where danling pointers to client
		  objects could be left in some cases.
		* Changed the way MD4 hashes are converted from Base16, in order to
		  improve error-checking. This adds aditional safety to places such as
		  parsing of ED2K links and adding of friends.
		* Fixed bug where clients would be removed from the list of Kademlia
		  clients if the hash, ID or IP changed. This should only happen when
		  the client is deleted.
		* Fixed various problems with logging during startup, including a
		  crash in amuled if an alert was to be displayed.
		* Fixed the HTTPDownload dialog by using events rather than relying
		  on being able to pause the main loop when sending notifications.
		  Also properly aMulified the dialog.
		* Entries for debug-logging are now always saved to the amule.conf
		  file, to allow amuled users to enable these manually. Before, the
		  entries were only written for enabled debuglog-types.
		* Fixed problem in loading of known.met, which would result in
		  duplicate shared files alternating between which file was actually
		  shared. This resulted in statistics for the file being 'lost'.
		* Added locking to the ed2k utility, to prevent races when many links
		  added at once.
		* Changed the way CFile retrieves the file-length, which was causing
		  problems with files shared from a remote drive.
		* Fixed problems with representing 64b values on windows, caused by
		  imcompatible extensions to printf. Thanks to Radek.
		* Improved error messages on startup, when a folder is found to have
		  inadequate permissions.
		* Fixed problems with identifying reconnecting clients, which would
		  cause a number of problems, including exessive bans.
		* Fixing right-clicking (for recursive sharing) only being possible on
		  the directory icon, but not the label.
		* Fixed sorting by client-version on the downloadlistctrl (bug #763).
		* Changed the sort-order of A4AF sources, so that these are always
		  shown last. This fixes bug #761.
		* Fixed assertion in the downloadlistctrl, caused by a bug in
		  wxMemoryDC. This would trigger when a complete file was shown.
		* When a missing shared file is encountered, unshare just that file,
		  instead of rechecking everything, since that would cause noticible
		  lag for people sharing many files.
		* Fixed exec-on-completion being run even if the file failed
		  to perform its completion.
		* Fixed the sanity check for the min/max ext. search parameters, which
		  would cause the min value to be ignored unless a greater value had
		  been set for the max field.
		* Fixed unicode searches, caused by mismatching string conversions.
		* Adding missing exception-handler to the the function searching for
		  shared files. Without this, a failure to retrieve a filesize would
		  result in aMule terminating.
		* Fixed userspecified CPPFLAGS being overwritten by the CXXFLAGS
		  by configure. Thanks to Gerd78.
		* Removed references to amulecmdgui and amulewebgui, which had been
		  left behind from when the utilities were removed.
		* Overrode wxConsoleAppTraits's WaitForChild function for aMuled,
		  allowing wxExecute to be used asyncroniously. This fixes problems
		  with using the exec-on-completion functionality.
		* Improved sanity checks for the TTS implementation.
		* Changed paused state to stopped state in some cases, which had been
		  incorrectly changed to paused by myself.
		* Added Maximize/Minimize buttons to the file details dialog.
		* Fixed dangling pointers left behind, leading to crashes when a
		  server.met file containing dead severs was loaded.

	Special Thanks To:
		* All the translaters who did such a great and fast job.

---

## Version 2.1.0 - The "I just teased you with this release till 2006" version
2006-01-01
Note: This version is dedicated to our great tester Citroklar, for reasons he knows.

	ender:
		* Fix adding AICH links with amulecmd.

	fulgas:
		* Added Kad info to amulesig
		* Fix for reading Kad info on the amule-utils: amps,cas,wxCas,xas

	Gerd78:
		* Fix linkage with static wx libraries.
		* Fix aMule.spec files
		* Fix amule.desktop file

	GonoszTopi:
		* Fixed a small GUI glitch
		* Ported the partfile importer from eMule, it's now capable of
		  importing eDonkey2000 partfiles. MLDonkey partfiles are not yet
		  supported.
		* Hid the "debuglog" entry in webserver, it had the same contents
		  as "log".
		* Moved CTimer class declaration to its own header file.
		* Internal events moved to their own header.
		* Proper termination of working threads in webserver.
		* Moved GetSoftName() to DataToText.cpp.
		* Changed the RGB() function to produce correct rgb values.
		* Added ability to transmit floating point numbers via EC, by
		  transmitting them in their string representation.
		* Using svn revision number as CVSDATE for svn working copies.
		* EC now uses a version ID for detecting binary incompatibilities.
		* New function: CastItoSpeed(), which converts the given integer
		  value (assuming it means bytes/second) into string.
		* Changed 'K' prefix for 'kilo' into 'k'.
		* Brand new statistics tree. Features include:
			- internal data is kept up-to-date realtime
			- support for translation over EC
			- selectable maximum of client versions shown
			- remote gui also has the statistics tree
		* Win32 compilation fixes.
		* Manpage file names now can be transformed.
		* Fixed linkage with shared win32 wx libraries (DLLs).
		* Fixed #538: extended info on tabs aren't removed
		* Fixed webserver search result page blank.
		* Strict POSIX compliance in configure script, fix for NetBSD sh.
		* Removed some strings from translation database that never needed
		  translation, such as "|", "(", "." and so on.
		* Fixed #521, #525, #542: amuled didn't handle shutdown command well.
		* Check for libpng existance and usability even if libpng-config
		  doesn't exist.
		* Fixed #545: Can't tell part number in remote gui
		* Disabled 'Preview' menu item in remote gui.
		* Fixed #543: amuleweb does not load the good language
		* More handy (or proper or native or user-friendly or call it
		  whatever you want) default incoming folder for Mac and Win.
		* Implemented #510: Rename downloaded files from amule
		* Made amulecmd able to connect/disconnect kad and/or ed2k.
		* Proper location for config files on Mac and Win.
		* Reworked amulecmd's command interface.
		* Removed #pragma directives from sources.
		* Various fixes to the new build system.
		* New EC socket code.
		* Fixed vertical position of text in shared files list.
		* Added preference option to select web template for auto-started
		  webserver.

	ken:
		* Use the IPFilter when adding and connecting to servers.  Thanks
		  to MrFaber for reporting the bug.
		* Along with GonoszTopi, proper location for config files on the Mac
		* Along with GonoszTopi, better default location of Incoming directory
		* Mac compilation fixes
		* Added more keystrokes (Backspace, Numpad Delete) as synonyms for
		  Cancel in Downloads list
		* Improvements to internal memory management to protect against leaks
		  in the face of exceptions
		* Protect use of mutexes against exceptions
		* Enabled language translation support for the Mac binary
		* Don't show the 'x' close buttons on the search results tabs on the
		  Mac, since they are non-functional and confusing
		* Maintain the functionality of control-clicks (right-clicks) on tabs
		  for search results and categories in the face of wxMac changes
		* Helped avoid endianess problems with Kad
		* Fixed handling of empty seeds files
		* Fixed crashes involving CSharedFileList.  Special thanks to lionel77
		  for truly heroic debugging efforts.
		* Fixed a crash in amuleweb when the template isn't found
		* Contributed to improvements in the new CTimer class
		* Disabled the tray icon preference settings on the Mac since they're
		  dangerous (can cause crashes)

	KingFish:
		* Fixed systray shared files count.

	Kry:
		* Initial Kademlia import from eMule.
		* Fixed endianess problems on Kad.
		* Cleaning of the CContact class.
		* Fixes on node lookup and distance calculation.
		   This is colaborative development with John from eMule.
		   (Added to eMule 0.46c)
		* Fixed a crash on Kad search terms on the UDP listener.
		   (Added to eMule 0.46c)
		* Proper catching and more debug on Kad search and Data I/O
		* Proper shutdown of Kad on exit.
		* Kad firewalled sources are now contacted properly.
		* Fixed a crash on search manager, caused by erase invalidating an iterator.
		* Proper arrows for ed2k/kad state, using alpha drawing. This means that
		   the little arrows on world globe on status bar are now separate: the lower
		   one is for ed2k and the higher one for Kad.
		* Fixed another wrong usage of stl classes and some cleaning on clientlist.
		* Added GUI checkbox to show/hide Filter options.
		* Added -D_GLIBCXX_DEBUG to compilation flags.
		* Fixed a crash on kad indexes caused by deleting the key invalidating the iterator.
		* Cleaned the connection state functions out of their container classes to theApp.
		   This fixes possible crashes on uninitialised serveconnect/kad classes.
		* Removed all low-level winsock/linux sockets erferences from code.
		* Moved wxEVT_NOTIFY_EVENT to wxEVT_MULE_NOTIFY_EVENT to avoid
		   conflicting with wxWidgets own definitions.
		* Removed daemon fork on windows to fix compilation.
		* Fixed text-mode apps password ask on windows.
		* Fixed preferences close to do a cancel event.
		* Added EC debug messages on connection failures.
		* Fixed memset usage on abstract types, causing crashes on some
		   configurations.
		* Only use date and not hour from CVSDATE.
		* Fixed MULENOTEBOOK events
		* Fixed connect button behaviour, about 17 times (counted).
		   Last implementation does:
		   - Connect to enabled networks if aMule is not connected to any.
		   - Disconnect if aMule is connected to any network.
		* Fixed aMule remote gui to use event-driven EC.
		* Fixed WOULDBLOCK on EC to retry tranfer.
		* Fixed wxSOCKET_NOERROR not triggering a transfer on EC.
		* Rethrow proper info on invalid Kad tag.
		* Deprecated docs/amule-win32.HOWTO.txt, use wiki instead.
		* Fixed GCC 4.0 compilation:
			* ~CMD4Hash()
			* ~CValueMap()
			* CValueMap
		* Update Kad tab on usercount change.
		* Fixed wxSOCKET_WOULDBLOCK/NOERROR on EC to avoid losing packets.
		* Avoid widnows execution writing ont he registry.
		* Fixed Solaris Sparc compialtion (-lrt compilation flag).
		* Throwing invalid kad type tags for debug measures.
		* Acording to RFC3330, 24.* and 14.* must be parsed as normal ips.
		* Some fixes to the (still partial) skin engine.
		* Allow to expand relative paths on skin engine.
		* Fix for too big tags (larger than packet) detection.
		* Updated POTFILES.in, lots of times.
		* Updated and centralized client emule compatible numbers.
		* Fixed wxWidgets includes based on version.
		* Fixed clicking "No" on shutdown confirmation... doing a shutdown.
		* Adding a link over EC now gets proper feedback on duplicates.
		* Added YASO (Yet Another Shareaza Opcode).
		* Allow binding EC and ed2k/kad sockets to an specific address.
		   Use Address= and ECAddress= on [eMule] section of the amule.conf file.
		* Warn for outdated version on daemon, too.
		* Added Kademlia network to aMule daemon.
		  This required an split of core/GUI of the initial import.
		* Removed a big bunch of duplicated EC calls to connection status.
		* Show Kad status on remote apps.
		* Fixed a possible memleak on CKnownFile creation.
		* Added hashing protection about hashing more than one part at a time.
		* Fixed a memleak on global search packet.
		* Fixed Kad crash based on wrong STL iterator usage.
		* Compilation fixes for SafeFile classes.
		* Chat icon on toolbar now blinks red/blue on new message till we press
		   the button to check the message.
		* Make compressed HTTP files be decompressed transparently after download.
		   Allows for server.met.gz and similar downloads.
		* Fixed the statusbar taking too much space.
		* Default server.met uses gruk.org now, to avoid fake servers.
		* Reverted phoenix false fix for my kad iterator fix and adding my fix which
		   was before his fix. Try to say that drunk.
		* Several cosmetic minor changes to GUI.
		* Fixes on wxHTTP crashes caused by heap creation of sockets class.
		* Moved ECAddr to ExternalConnect section and made GUI for selecting the ip.
		* Fixed korean translation compilation failure.
		* Several 2.4 compilation fixes, which turned out to be not used because we
		  now require wxWidgets 2.6.0 at least.
		* Fix NetBSD compilation (fwprintf not implemented on NetBSD).
		* Fixed some unneeded ansi strings conversion to wide chars.
		* Endian fix on Kad UDP packets being sent... elsewhere.
		* Several fixes on endianess over source exchange and ip filtering.
		* Debug output and crash fix for HTTP streams on download.
		* Fixes on keyword hashing on Kademlia.
		* Fixed Kad tag names using ansi chars instead of unicode names,
		   which will be sent as ansi anyway but CTag creation is based on
		   wxStrings, so using a char* uses the int constructor.
		* Removed the CTagNameString, using wxString everywhere.
		* Fix for GUI systray option being enabled when systray compilation
		   is disabled.
		* Server ed2k link (and any link) must be '/' terminated, fixed on
		   generation.
		* Debug output on EC protocol version mismatch.
		* Changed servers toolbar button to networks. Now this has two tabs,
		   one for ed2k and one for Kad.
		* Created Kad GUI from scratch.
		* OP_REASKCALLBACKUDP implementation for Kad lowid
		* 64bits archs fix on webserver image generation.
		* Removed CT_PORT usage on server login - is ignored by eservers now.
		* Removed Kad search list ctrl - it's just debug output user won't need.
		* Removed Kad nodes list ctrl - it's just debug output user won't need.
		* Modification's to lupz's patches on Kademlia sources search.
		* Compilation fixes on ClientList for Kad contacts.
		* Checks for 0-port UDP packets to avoid 100% CPU usage.
		* Lots of Kad cleaning on the imported code, contacts, searches,
		   UDP packets processing and routing bin
		* Removed kademlia/utils/Ping.* - unused on this implementation.
		* Fixed a crash on Kad exit caused by double-removal.
		* Fixed remote GUI compilation with Kad enabled.
		* Changed invalid rating on a file to non-critical (keep source!).
		* CPU fixes on duplicated calls to rating updates.
		* Some fixes to rating icons.
		* Killed muuli's pragmas.
		* Moved search id's setting to search class itself.
		* Fixed searches' timspan on CParfile::Process
		* Reworked src/Makefile.am to handle common files.
		* You can change toolbar to vertical/horizontal on GUI tweaks now.
		* Removed fakecheck (sites down).
		* Fixed a crash on HTTP download dialog caused by wrong usage of delete.
		* Fixed toolbar orientation change not showing proper connection state.
		* Fixing ED2K link handler colliding with status bar.
		* Added 7z to types.
		* Mantain a list of already-known mods to avoid "Compatible client found"
		   messages spamming the console.
		* Revamping of UpDownClient interface. Proper private vars and public
		  accessors, merged the public/private sections, and decoupled credits classes.
		* Fixed possible crashes on dereferencing NULL pointer, specially on EC
		   tag creation on UpDownClients.
		* Separated CClientCredits and CClientCreditsList to diferent files:
		   the later is not needed on remote GUI while the former is.
		* Moved some functions for ID check to theApp, to remove the
		   includes needed on each file, cutting down compilation time.
		* CClientCredits is not more a friend class of CClientCreditsList.
		* Split CClientReqSocket from ListenSocket.*, and renamed to
		   CClienTCPSocket to keep coherence with CClientUDPSocket.
		* Removed event handler local vars on server and client sockets, and moved
		   the classes out of the .h, because those are no needed anywhere else.
		* Removed the possibility of bootstrapping Kad from a host.
		* Fixed the stale unknown clients caused by unanswered kad-buddy requests.
		   The new KADEMLIABUDDYTIMEOUT is 10 minutes. More than enough.
		* Connect/Disconnect button works properly now. Disconnection happens on any
		   network connected, and connection on the selected networks on preferences.
		* Added a Disconnect button for ED2K too.
		* Fixed possible crash on startup.
		* Tray icon is now shown as connected if any network is (ed2k or kad)
		* A lot of class separation and file/class renaming, to prepare the build for...
		* Build system changed:
		   - Added some intermediate libs to avoid double-compiles:
			     (Binary compatible files only)
			   - libmuleappcommon.a -> Common to all aMule derived apps
			   - libmuleappcore.a -> Common to amuled/amule
			   - libmuleappgui.a -> Common to amulegui/amule
		   - Also changed some files to increase the amount of
		     binary compatible files. Would be great to increase
			 this number, but sadly theApp. access is not binary
			 compatible (different base classes).
		   - Created two amule-independant libs:
			   - libcommon.a -> Common to all apps
			   - libecc.a -> Common to all EC apps
			 Those are now on libs/ folder.
		* More changes to build and libs. libeccommon now includes ECSocket,
		   and CRemoteConnection is used to connect to a remote core.
		* Make libec independant from libmulecommon
		* Call realize to fix toolbar on Mac.
		* Open wiki on F1 for help :)
		* Stats have a 64bits, not 32bits, uptime number.
		* No more EC extra needed for having a remote app, yay. Just link to
		   libec.a and use the CRemoteConnector->ConenctToCore and stuff. This
		   will be expanded for a proper EC API.
		* Did some EC API examples so someone can expand it.
		* Tooltips, proper names, and layouts for the connection ports.
		* Fixed compilation flags for base-only apps.
		* Lots of GUI visual glitches fixed.
		* Fixed ping times on servers being in ms instead of secs.
		* Now core timer is on a thread, and it behaves much better.
		* Fixed core timer silliness on time count. Much more acurate now.
		* Workarounded the memleak caused by wx < 2.6.2
		* Fixed it.po (twice).
		* Some debug to aid locating rogue clients and know if it's actually us.
		* Save source seeds now saves 10 sources, but only keeps them for a
		   Max of 2 hours.
		* Added search expressions class and parsers.
		* Fixed flex usage when --header-file is not available.
		* Proper POTFILES.in
		* Fixed systray's Connect/Disconenct to include Kad.
		* Fixed a huge bug that was sending TOO MUCH packets (UDP) to
		   servers. This alone is a reason for a release. Fixes the server list flicker, too.
		* Kad status fixed for remote apps, and included "running" status.
		* Kad info is shown on Kad tab on remote GUI.
		* Avoid ping storms by lugdunummaster request, adding a random value
		   to server UDP ping.
		* We should not publish FT_FILEFORMAT at all. Fixed.
		* Publish only file rating if we have any.
		* Update on server flags - added related search and type tag integer.
		* FT_FILETYPE can be an integer for newer servers, added support.
		* As for lug request, newer servers get a integer filetype tag if supported.
		* Enable connect/disconnect Kad from remote gui.
		* Some basic warnings on value changes for preferences.
		   Now, if you request a change on preferences that requires restart, like
		   ports, incoming/temp folders, and others, aMule will warn you on "OK".
		* Don't connect to ed2k on server double click if the network is disabled
		* More warnings: Kad without UDP port, and Kad conenct while disabled on
		   preferences now raise a log warning message.
		* Dynamic set of GUI options to avoid visiting prefs multiple times.
		* Warn if UDP disabled and Kad enabled on preferences.
		* Fixed Scanner.y to allow compilation with old flex versions.
		* Fix installation or webserver's Kad page.
		* Use the generic function instead of X11-specific one for geometry parsing.
		   Fixes compilation on several platforms and removes dependency on X11 headers.
		* Removed duplicated code and cleaned CDirectoryTreeCtrl
		* Fix for continuously trying to solve a DNS server.
		* Fixed some memleak on contact results.
		* Fixed mem corruption, and contact asserts on the new merge code
		  for kad contact trees.
		* Kad notes filtering
		* Fixes crash on startup onMac and Windows caused by an unitialized
		   variable being used at dialog construction. But not on wxGTK. Go figure.
		* Update on wxwin.m4 to wx-cvs of 15/12/2005 and proper base flags usage.
		* Minor amount of libs to link for wx, instead of all libs.
		* Fixed a crash on wxGetTranslation usage on Windows.
		* Fixed an assert on folders tree control on windows.
		* Fixed the initiazlization of status_arrows to proper size (16x16) on Windows.
		* Fixed the status arrows on windows, and fixed wxWidgets bug that caused it.
		* Changed file to output stream on HTTP download.
		* Fixed a endless loop on downloading files < 10 bytes on HTTP.
		* Fixed Kad nodes download by stopping Kad before the file is renamed.
		* Fixed crashes on HTTP download.
		* Added support for proxy usage on HTTP download, via environment variables.
		* Fixed input streams on FileFunction's handling of gziped files.
		* Fixed download of gziped files on windows.
		* Fixed extension Kad search
		* Fixed crash on search
		* Removed the sending of "Any" type to server - is the default.
		* Fix search types and return values on ed2k/kad search.
		* Fixed a wrong Kad packet being created on a race condition caused by the
		   removal of a file from shares that will just get published. To be added on eMule, too.
		* Fixed Open File command on categories.
		* Fixed detail level on EC tags failing silently on lower values.
		* Fixed crash on remote gui if not config folder not existant.
		* Created, fixed, killed the --enable-kad-compile switch to enable
		   non-kad compilations during test phase. Now is always compiled.
		* Removed platform specific getlocalhost usage.
		* Fixed ntohl usage on gap list saving.
		* Removed wrong Merkur (c) from php libs (sorry Merkur, but those are ours :P)
		* Fixed strings on log categories for protocol.
		* Listensocket's fixed for debug on connection accept.
		* Multiple Kad searches are allowed now, with independant tabs.
		* Debug messages regarding late / unwanted kad searches results.
		* Fixed Kad gui search return messages.
		* Safety code on shared files' RotateReferences.
		* Fixed endiannes on CUInt128::setValueBE / CUInt128::toByteArray
		* Fixed ENDIAN_SWAP_**(x) definitions to use the proper
		   wxUINT**_SWAP_ON_BE/ON_LE/ALWAYS macros.
		* Publishing of keywords (shared files) works now on Kad.
		* Implemented Kad GUI.
		* Fixed low speed connection to sources when only connected to kad
		* Fixed Kad callback of lowid sources.
		* Fixed Kad usage when ED2K is disabled.
		* No more auto-reconnect on disconnect (woops).
		* Speed up catch and proper window ID on HTTP download class.
		* Added wxIdleEvent::SetMode(wxIDLE_PROCESS_SPECIFIED) to
		   app startup, cutting CPU usage a lot. Go figure.
		* Changed the socket destruction to socket's Safe_Delete.
		* Fixed a GetUDPPort usage where GetEffectiveUDPPort should be.
		* Added UDP socket warnings on unknown errors.
		* Client UDP socket error handling rewritten.
		* Fixed UDP socket heap vs stack problems.
		* Proper check for libgd (Sorry!).
		* Showing Kad state on conection for fast reference.
		* Added some code to catch unhandled exceptions on kad
		  and report them, so we know what's going on.
		* Fix for crash/assert on wrong permisions on cryptkey.dat.
		* Fixes for daemon compilation on OnRun usage.
		* Fixed a Crash on Kad caused by packet constructor
		  deataching the data, causing a double-delete.
		* Safety code for uncatched exceptions.
		* Some changes to packet processing.
		* Fixed a big mem bug on Kad.
		* Fixed a bug with iterator usage in SearchManager.cpp
		* Fixed a bug on PARTSIZE calculation that could lead to
		   insanely large partsizes.
		* Fixed possible buffer overflow on gap saving
		* Fixed the RSB of this release. you know, one per release.
		   (for those that are new to aMule, RSB = random socket bug)
		* Cleaned, cleaned, cleaned code.
		* Fixed:
			0000492: aMule gui fails to compile when using wxMotif 2.6.1
			0000514: Not all common file types recognized as Audio
			0000516: crash after repeated search
			0000646: right click on transfer files randomly disabled
			0000659: disconnect button might not disconnect kad and block it's function
			0000661: windows consistency
			0000662: amulecmd crashes on invalid pause command
			0000671: open file on double-click
			0000691: connect/disconnect button is still broken
			0000704: servers connection cancel button
			0000715: prefs -> general -> "downloadlist dblclick to expand" option is
			                broken or something
			0000716: prefs -> seeds save, wrong text
			0000718: more systray ignoring kad
			0000719: searches -> extended -> min size vs max size
			0000730: statistics connections graph Range requires restart
			0000729: search query string parser
			0000732: more brackets related bugs
			0000733: download button activated when search fails
			0000734: non-restored icon in Directories -> share

	lfroen:
		* PHP engine implementation for amuleweb
		* Porting web templates to PHP script

	lupz:
		* Kad speed improvements.
		* Kad sources search improvements.
		* Fixed manual bootstrapping via the Kad dialog.
		* Properly swap IPs when doing logging in Kad.
		* Avoid trying to close the file multiple times when resuming a
		  part-file that failed to complete.

	Phoenix:
		* Removed wxGTK and wxGTK-devel dependencies from the spec
		  file. They don't work on all distros, even worse, don't always
		  work with Fedora Core.
		* Created a new spec file, compliant with Fedora Core.
		* Fixed a crash when aMule was shut down by amulecmd and an
		  assert happened.
		* Fixed asserts on exit about non-empty lists when aMule was
		  shut down by amulecmd.
		* Small compilation fixes.
		* Fixed deadlock in ClientUDPSocket.cpp.
		* Crash handler improovement, avoid calling functions that
		  may allocate memory.
		* Fixed some compile warnings in WebServer.cpp.
		* Fixed a crash in SharedFilesWnd.cpp due to aMule beeing now
		  multithreaded.
		* Changed wait4 to waitpid in amule.cpp, to improove
		  compatibility with old HP-UX systems.

	Ramiro:
		* Patches to compile on a NSLU2 (ARM).

	RazZziel:
		* Changes on parent ownership on windows. Partially fixes
		   0000690: List of windows that can be overlapped by main
		                   window and leave aMule apparently freezed

	schtroumpf:
		* File rating in search dialog.
		* New file rating icons.
		* Replaced file rating good/bad with a rating average like in emule.
		* Amule submits file rating to the server.

	Seagull:
		* Fixed a small bug on client list view.

	shakraw:
		* Merged with 2.0.3 latest fixes (r4630, r4631, r4633, r4639)

	stefanero:
		* Fixed cas,wxCas and xas infos for Kad when only connected to
		Kad
		* Imported amps in aMule source

	thedude0001:
		* Added CVS snapshot date to frame title.
		* Fixed #560: "aMuleWebDLG and aMuleCMDDLG do not report version"

	volpol:
		* A4AF transfer speed display fix

	Xaignar:
		* Fixed the possibility of crashing when sending a message to a non-
		  friend client, caused by the fact that the client could be deleted
		  before the user entered the message. Also prevented attempts at
		  sending messages clients that wern't ready.
		* Fixed crash when '--version' was used, caused by an uninitialized
		  pointer. Serveral other uninitialized pointers were also fixed.
		* Fixed assert in the Type-To-Select code which would trigger when
		  items were removed and the old tts index pointed past the last item.
		* Fixed kad-searches with a filetype specified not producing any
		  results, caused by using obsolete type-strings.
		* Added missing calls to va_end at places where va_start is called.
		* Remove unneeded calls to wxMutexGuiEnter/Leave.
		* Fixed the listctrls asserting if one were to click past the end of
		  the last column header.
		* Fixed unhandled-exception handling in unittests, which had been
		  broken when they were made console apps.
		* Fixed sscanf call in PHP lexer, which had switched the source and
		  the format arguments.
		* Performed audit of printf type calls. Serveral bugs caused by using
		  the wrong printf variant were fixed in the webserver. All instances
		  of calls to sprintf variants were changed to snprintf to prevent
		  buffer overruns and calls to printf that passed a dynamic string as
		  the format string were changed to prevent using untrusted format
		  strings. Lastly a few places where widechar and char where mixed
		  were fixed.
		* Avoided checking the same folders multiple times when looking for
		  shared files, by ensuring that duplicate entries (from categories,
		  etc) are ignored.
		* Fixed minor mem-leak in CTimer.
		* Deleting a static server now also removes it from the static list.
		* Fixed disabling of graphs while the prefs-dialog is still open.
		* Fixed logging on UDP-sockets displaying an integer value rather
		  than a dot-IP.
		* Made the ipfilter.dat URL field independant of the auto-update
		  check-box, to allow for easier manual updates.
		* Fixed log-events not being written the logfile on full daemon.
		* Improved displaying of errors when starting the webserver from
		  amuled.
		* Allow resuming of files that error'd out during completetion.
		* When checking if a file is already being downloaded/shared, check if
		  the actual file is still available. This allows redownloading of
		  shared files that have been removed, without having to reload the
		  list of shared files.
		* Added checks to see if the target filesystem is fat32 when
		  completing files, and removing known illegal chars in that case.
		* Important log-lines are now bolded in the log textctrl.
		* Redirect wxWidget log-events to the aMule log. This avoid the popups
		  that wxWidgets would display by default.
		* Made the unittests proper wxConsoleApps.
		* Open the preferences dialog non-modally, so that it doesn't block
		  the main GUI.
		* Switched manual path-joining to using the generic function.
		* Fixed the "pause all" and "cancel all" commands via remote.
		* Fixed bad replies on sharedfiles-list requests when public viewing
		  of the list is disabled.
		* When a message is filtered, always display the "Message filtered
		  ..." log-entry instead of the "New message ..", rather than only
		  displaying the "Message filtered" the first time, and then only the
		  "New Message" the following times.
		* Cleaned up the file-completion thread and fixed the following:
		  * If creation or starting of the thread failed, the file would
		    silently fail to complete.
		  * If the file was renamed, the download queue show the old name.
		  * If the file was renamed and didn't have an extension, the "(x)"
		    component would be added to the front of the filename.
		  * When checking for unused filenames, if an file with the same name
		    exists, the path would be a changed to the standard incoming
			folder regardles of the file's category.
		  * wxFileExists was used to check for the existance of the files,
		    possibly leading to false negatives with unicoded filenames.
		* Fixed files being added in stopped-mode when the "Add downloads in
		  paused mode" setting was enabled. Since the "Start next ..." works
		  on paused files, this makes more sense.
		* Fixed bug #513. When "Start next ..." and "Same category .." was
		  enabled, we would still select downloads from the wrong category,
		  when there was still paused files in the desired category.
		* Changed the StopPausedFile from actually stopping the file to simply
		  clearing the sources, as this is the intended goal. Stopping the
		  file was wrong, considering that it would leave a window of one hour
		  in which the "Start next paused download" code would be useful.
		* Added generic function for joining two paths.
		* Dont allow renaming of downloads that are being completed.
		* Made the comment-list dialog resizable.
		* Enabled use of tool-tips on all wx-variants.
		* Fixed Kad-Info and ED2K-Info lists not having any scroll-bars.
		* Fixed compressed Kad packets having the wrong procotol set. Thanks
		  to Gnucco for the pointing this out.
		* Only show the root-item circle for incomplete part-files.
		* Prevent the adding of friends without IPs, via the clientlistctrl.
		* Fixed serveral problems caused by the reuse of the preferences
		  dialog window.
		* Improved the popup menu on the downloads listctrl.
		* Fixed starting of next download being called under the wrong
		  conditions when files were deleted via remote.
		* Dropped the HTML version of ed2k-links.
		* Fixed shutdown of the amulegui when the systray is enabled.
		* Fixed bug #359. The preferences dialog is now reused between
		  sessions, so the last used page and the state of the shared-files
		  tree is remembered.
		* Only enable the host-version of ed2k-links when a hostname has been
		  specified (still no perferences widget for this).
		* Fixed bug #700. The partfile conversion window is now raised
		  properly when the button is clicked again (doesn't work with gtk1).
		* Improved logging in CFile in situations where system-calls are used.
		* Improved permissions checks for the .aMule folder. Also added checks
		  for the Temp and Incoming folders.
		* Fixed an unconditional Close call when creating part-files, which
		  happened even if opening the file failed.
		* Fixed the names of friends being cleared on the chat-notebook when
		  the clientobject disconnected.
		* Ensures that both the downloadlistctrl and sharedfileslistctrl are
		  both up to date when a file has been renamed. Also switched to using
		  the same dialog on both listctrls.
		* Check for items being sorted was moved to the CMuleListCtrl class,
		  and to fix flickering on the server-list and and searchresult-lists,
		  which is caused by insertions and deletions, the list is resorted
		  instead, if an item is out of order after an update.
		* Drop the use of jugle.net. It's dead, Jim!
		* Changed the 'Clear' button on the search-page to only clear
		  search-results. The 'Reset' button now takes care of the text-field
		  and any extra parameter-fields. Serveral fixes were made to make
		  sure all fields were properly cleared.
		* Properly set filtering on newly added search-results.
		* Fixed broken sanity check in AddDownload
		* Bug #688. Made the popup menu on the searchlistctrl similar to those
		  on the downloadlistctrl and sharedfileslist.
		* Added serveral missing exception-handlers.
		* Ensured that the internal libs are only built when needed.
		* Fixed ed2k-links causing duplicate entries on the download-queue and
		  made the sanity checks in AddDownload safer.
		* Made the interal CryptoPP files part of the one of the temporary
		  libraries to avoid building it three times (amule, amuled, amulegui).
		* Removed printf-call from signal-handler.
		* Unified download-handling on the search-page and fixed the download
		  button, which was broken by previous commits.
		* Fixed a leak in the UDP sockets which occurs when packets are sent
		  via a dead or closed socket object.
		* GetInstallPrefix is broken on wxWidgets 2.6.2, so only use it when
		  building autopackages (since we can patch the sources).
		* Improved logging in case of clients requesting invalid file-data.
		* Cleaned up autoconfigure files a bit.
		* Added sanity checks to the downloadqueue's AddDownload function to
		  catch this, should the problem appear again.
		* Added checks to avoid loading duplicate partfiles, since downloads
		  are identified by the hash. A warning is now issued when this
		  happens.
		* Add a "Download in category" sub-menu to the right-click menu on
		  searchresult lists and moved download handling to CSearchListCtrl.
		  This fixes bug #673.
		* Specify if debugging was enabled on version strings.
		* Ctrl+a now select all items on listctrls.
		* Make aMule relocatable in regards to locales, and amuleweb
		  relocateable in regards to templates. This is needed to allow usage
		  of autopackage.
		* RotateReferences() now properly handles shifts larger than the
		  number of files present and use std::rotate.
		* Files that are larger than the limit imposed by the ed2k network are
		  now filtered from search-results.
		* Fixed drawing of the first column on the shared-files list, caused
		  by the upgrades to the listctrl code.
		* Made one-shot CTimers interruptable and fixes a memleak in the Start
		  functions caused by not freeing old threads.
		* Upgraded our included listctrl with the bugfixes from v2.6.1
		  and v2.6.2 of wxWidgets.
		* Fixed a couple of AICH log messages that were mixing unicoded
		  strings and non-unicoded strings.
		* Made middle-clicking on the client-list work in the same way as
		  middleclicking on the downloadqueue, and cleaned up click-
		  handling in general.
		* Fixes the overhead-handling code in CTimer which wouldn't
		  check if overhead was larger than the period, resulting in
		  calls to Sleep with an underflown value. Also fixed events
		  possibly being lost due to overhead.
		* Fixes crashes due to uncaught read-past-EOF exceptions when a
		  cliented requested a block from a file past the end of the
		  actual file-length.
		* If aMuled is run and ECs are enabled and no password is set,
		  dont reset the EC setting, but rather display instructions
		  that specify what to do before terminating.
		* Added warning which will be displayed if aMule is run as
		  root, which is adviced against for obvious reasons.
		* Removed the --disable-systray configure option, since extra
		  libraries are not required now. To disable the systray now,
		  simply use the preferences.
		* Removed support for wxWidgets version older than v2.6.0. Support
		  for wxWidgets 2.4.2 had been broken for a while, without anyone
		  complaining, and the v2.6.x branch has been out for long enough
		  to make usage of the v2.5.x branch nonsensical.
		* Added workarounds for the wxWidgets memleak when using GTK2 on
		  versions of wxWidgets < 2.6.2 to the remaining places where this
		  would occur.
		* Changed failure on file-seeking into a catchable exception,
		  rather than a runtime error.
		* Fixed a crash on shutdown caused by the listensocket now being
		  closed which caused a call to Accept to return NULL.
		* Fixed compilation with GCC-4.1 (snapshot).
		* Syncronized look of client-icons on download-queue and the
		  client-lists (upload, queued, all), so that all display the same
		  information.
		* Display an icon when downloads have comments but no rating, and
		  added the same icons for both to the shared-files list, making it
		  easier to keep track of what files are commented/rated.
		* Fixed all warnings reported by -Wshadow and -Wundef.
		* Added the compiler-flags -Wshadow and -Wundef, and changed
		  configuration such that warnings are enabled for both debug and
		  non-debug builds.
		* Largly reworked the CTimer class:
			* Fixed all timers sending events with the same ID.
			* Removed use of static variables which would cause troubles if
			  more than one repeat-timer was used.
			* Ensured that no event would be sent if the timer was stopped
			  while sleeping.
			* Improved thread-safely a lot and made the threads detachable.
			* Added function for terminating all timer-thread on shutdown, so
			  that no timer-threads will be left running.
		* Fixed SSE2 support check in the embedded cryptoPP code, for gcc-4.
		* Fixed a couple of bugs caused by variable-shadowing.
		* Flush log-buffers when waiting for either of the hashing threads to
		  terminate.
		* Removed manipulation of gui-mutex in AICH thread, which are no
		  longer needed due to changes in log-handling.
		* Removed local variable which shadowed a variable when checking if a
		  client was a friend. This caused the friend to link to said client
		  even after the client had been deleted, since the client would not
		  unlink itself from the friend.
		* Only store the descriptions of IP-Ranges for the ipfilter on
		  debug-builds, since this value is not used on non-debug builds and
		  can account for serveral MB of used memory.
		* Fixed new-connections being opened on shutdown and the new clients
		  being created. This should fix the assertion in CClientList.
		* Added a call to wxUpdateUIEvent's SetMode function, to reduce the
		  ammount of unnessesary events being generated.
		* Fixed clearing of background for list-items that do not have a
		  background color set.
		* Resized a couple of buttons that were too small to display their
		  image. This fixes bug #648.
		* Improved double-buffering of listctrls a bit.
		* Fixed auto-sorting checks on the server-list, which were inverted,
		  causing items that were already sorted to be re-position and so
		  forth. This was the source of the large ammount of flicker on the
		  server list.
		* Fixed the "Time Remaining" column on the downloadqueue when no
		  downloads were taking place.
		* Removing unneeded checks for fat32 filesystems.
		* Improved handling of closing of the preferences dialog.
		* Changing kad-nodes label to display "Nodes (0)" by default.
		* Force the UBT to take a increasingly longer nap between loops when
		  it fails to send anything, which ensures that it wont go bananas it
		  is unable to upload at the specified rate. This would happen for
		  instance if the limit is set to a value higher than the physical
		  connection limit. This fixes bug #606.
		* Re-added the node count above the kad-graph, and a few other changes.
		* Removing unused color-setting, which was causing problems with the
		  kad-graph. For this change to take effect, you will have to remove
		  your StatColor* entrires from amule.conf.
		* Fixed bug on the kad-nodes statistics, where entries added while the
		  dialog was not displayed would have the value of zero. This fixed
		  bug #652.
		* Fix for selecting tabs (+ popup menu) via right-clicking on GTK2.
		* Allow previewing of audio-files, fixing bug #654.
		* Reworked the ED2KLink class:
			* Simplified parsing a lot.
			* Moved the task of handling sources specified in file-links
			  almost entirely to the download queue.
			* Improved error checking.
			* Implemented handling (not just parsing) of part-hashes and
			  master-hashes specified via file-links.
			* Fixed support for multiple sources in a file link, which fixes
			  bug #506
		* Properly replicate file permissions when copying files via the
		  UTF8_CopyFile function. Also removed an unneeded free/malloc set of
		  calls by allocating on the stack.
		* Added the ability to execute commands when a download has been
		  completed and removed some unimplemented options from the
		  preferences. This fixes bug #152.
		* Update the "clients on queue" count when purging clients. This
		  should resolve bug #478.
		* Properly disable filtering on searches when filtering is supposed to
		  be disabled. This approach does also not remove the existing
		  search-string if filtering is toggled on and off.
		* Fixed the kad-statistics using the colors of the download-statistics
		  rather than its own settings.
		* Implementing kad-node graph. This patch does not add support for the
		  graphs on the webserver.
		* Removing trailing "i"s from time values created by CastSecondsToHM.
		* Reduced log verbosity when deleting downloads.
		* Sync deletion of items on friend, download and server lists via the
		  Delete key. This resolves bug #649.
		* We now completly disallow the sharing of the users home-dir.
		* Changed the check for file-size in the hasher-thread, which was
		  using a too large value, greater than what is actually supported by
		  the ed2k network.
		* Fixed compilation on the x86 version of MacOSX.
		* Added specialization of the CRangeMap class which doesn't contain a
		  user-value per range, dubbed CRangeSet.
		* Added the IP and port of friends to the initial text when opening a
		  chat window. This should more easily allow for adding of clients to
		  the friends list if they message us. This is not a final solution.
		* Added sanity checks to CStatisticsDlg's getColors function.
		* Changed some CList instances to stl containers.
		* Fixed bug in CKnownFile where auto-priorities would be updated
		  before the source had been added to the list.
		* Improved testing of CRangeMap's iterator classes.
		* Final changes to CFile, CMemFile and CFileDataIO:
			* Documentation of the classes and functions completed.
			* Completed unittests for CSafeFileIO, CFile, CMemFile.
			* Changed systems calls to explicitly use 64b calls on win32
			  systems, since win32 uses 32b calls by default.
			* Lots of other small improvements.
		* When sorting search-results by type, sort items with the same type
		  by their extensions.
		* Added the hotkey Ctrl-Q for closing aMule.
		* Dont store the results of unittest that didn't fail when executed,
		  since we ignore successes anyway. This causes a great speedup on
		  some tests, where a large number of checks are made.
		* Set the update frequency for the statistics, fixing bug #637.
		* Strip 's from paths set via amule-config-file, resolving bug #638.
		* Reworked the TTS implementation, so that control-sequences are
		  passed to the widget, improved walking through the list by
		  repeatedly pressing a letter and finally fixed the use of
		  arrow-keys on some locales.
		* Also clear the log-line (lower-left) when the log is reset.
		* Replaces a few "wxASSERT(x); if (!x) return" with wxCHECK(x)s.
		* Force an update when the file has been completed, which allows the
		  DownloadListCtrl to detect that a file has been completed.
		* Optimized the unicode-conversion functions, which were causing
		  unneeded copies to be made.
		* Only enable the clear-completed button and menu-item when there are
		  completed items. This resolves bug #403.
		* Fixes deadlock triggered when a UDP socket tried to recover.
		* Fixed compilation for 64b systems, caused by mismatching parameter
		  types in a pure-virtual function.
		* Improved sanity checking of DNS resolutions in CServerUDPSocket.
		* Fixed a few calls to CFile's Create function, which were using a
		  wrong parameter type for the second argument.
		* Changed MuleUnit to output results as soon as possible.
		* Added generic CMuleUDPSocket class, which unifies common tasks such
		  sending, receiving, error-handling and interfacing with the
		  UploadBandwidthThrottler. I also included a recovery mechanism
		  for when a socket becomes invalid, which fixes bug #489.
		* Fixed crashes when kad is enabled but the ClientUDP-socket is not.
		* Fixes names not being prepended to debug messages.
		* Fixed potential mem-leak on the download-queue.
		* Fixed secondary sort-ordering on the download-queue.
		* Changed source-handling so that we can distinguish between sources
		  returned from the local server and sources returned from global
		  servers.
		* Added debugging messages for when sources are received from an
		  unknown file.
		* Removed remaining fake-check stuff and fixed assert repported by
		  stefanero, caused by a bit of fake-check code left behind.
		* Changed handling of log-entries from worker-threads, so that these
		  are queued rather than sent immediatly. This is needed since adding
		  a pending event requires locking of the gui-mutex, which easily
		  leads to deadlocks.
		* Fixed race-condition in the download-queue, where multiple DNS
		  resolution threads could be created for the same hostname.
		* Fixed an assertion in the kad-dialog caused by an insertion at an
		  invalid index. This only happened for some versions of wxWidgets.
		* Fixed color-updating of items being downloaded from the search-lists.
		* Re-implemented rating icons on search-result lists using the builtin
		  support for icons on wxListCtrls. This saves us from having to
		  manually draw everything and fixes the crash on using TTS.
		* Fixed a bug in the ObservableQueue class, which would cause UDP
		  requests to servers to be done only once, whereafter no further
		  requests would be made. This was the source of the problem with
		  aMule not finding sources for newly added files.
		* Fixed a race-condition in aMule when shutting down while a global
		  search is running. This should resolve bug #563.
		* Reworked the CServerUDPSocket class a bit, most importantly, changed
		  it so that servers being deleted while we are doing a DNS lookup on
		  their hostname cant result in accessing of dangling pointers. This
		  should bug #581.
		* Fixed bug #558. Sources not being sorted when the download-queue was
		  sorted by the "Time Remaining" column.
		* Cleaned up file-ratings and comments handling:
			* Dropped the m_hasRating and m_hasBadRating booleans, as these
			  can be infered from the value itself.
			* Dropped the SetHasComment and SetHasRating functions, as this is
			  more safely handled in UpdateFileRatingCommentAvail.
			* Cleaned up the UpdateFileRatingCommentAvail function since it
			  was rather messy.
			* Removed a unnescesarry call to Notify_DownloadCtrlUpdateItem in
			  the function ProcessMuleCommentPacket, since this is already
			  done in the UpdateFileRatingCommentAvail function.
		* Added sanity checks to the code that made use of said file-ratings.
		* Added sanity checks against file-ratings read from other clients,
		  since we later rely on these values to be in a specific range.
		* Fixed some uninitialized variables.
		* Make ascending the default sort-order and fixed loading of the
		  sort-order in the CMuleListCtrl class.
		* Added a missing call to Skip in the TTS event-handler for item
		  selections, so that subclasses will still be notified.
		* Reworked CMuleListCtrl and added support for "Type To Select", or
		  the ability to select items by typing parts of their name. The
		  selection is made against the start of the text-strings and is
		  case-insensitive.
		* Fixed some more warnings.
		* Fixed compilation problems with external CryptoPP sources, caused by
		  a preprocessor define which clashed with a variable name.
		* Changed the length parameters of the read-funtions in the CFileDataIO
		  interface to be unsigned, since signed lengths doesn't
		  make any sense in this regard and makes error-checking harder.
		* Merged checks for the ARM and Sparc architectures.
		* Changed a call to bzero to memset, since win32 doesn't have bzero.
		* Fixed remaning issues with template usage in MuleUnit.
		* Cleaned up error handling in CClientUDPSocket a bit, and added
		  error-checks to CServerUDPSocket. This should allow us to see if the
		  INVSOCK errors are local to CClientUDPSocket or if they happen to
		  all wxDataGramSockets.
		* Added check requiring a valid port to CClientUDPSocket's SendPacket
		  function, since we apprently tried to send to port 0 once in a
		  while.
		* Moved adding of sources read from seeds files out of the
		  exception-handler, to avoid the obscuring of possible bugs elsewhere.
		* Final touches made on the CMemFile class, which includes cleanups,
		  improved error-checking and complete documentation.
		* Added missing destructor to CUInt128, which was causing compilation
		  failure for some GCC-4 users.
		* Fixed an attempt to fprintf a wide-char string.
		* Enabled the use of kad with wxWidget versions 2.5.x.
		* Improved handling of uncaught exceptions in MuleUnit and changed the
		  library from being an actual wx application, since we only need to
		  make use of wxWidgets classes.
		* Expanded the CFormat testcases a bit, to better cover use of illegal
		  values and the checks against those.
		* Improved checking of value convertions in CFormat, now properly
		  detects nagative values converted to signed values and signed to
		  negative, plus some other situations.
		* Fixed format-strings in the statistics-tree that did not specify a
		  type large enough to actually represent the possible values.
		* Disabled certian tool-tips for wxWidgets-2.4.2, since the calls made
		  use of functions that were introduced in wxWidgets-2.6.x.
		* Moved archive-unpacking functions from the HTTP-thread to
		  FileFunctions.*. This allows for compressed files to be read both
		  when the source is the inbuilt HTTP downloader, or if a compressed
		  file (ipfilter.dat or server.met) is explicitly moved to the .aMule
		  folder.
		* Changed C++ style comments in C sources to using C style comments.
		* Added check against trying to write NULL pointers in the CFileDataIO
		  WriteStringCore function.
		* Added some initial tests for the string reading and writing
		  functions to the CFileDataIO unittests.
		* Removed the RepeatLastAction stuff from CClientReqSocket.
		* Fixed the check for BOM-header failing on strings that were
		  3 bytes long (an empty string).
		* Fixed empty UTF8 strings with BOM headers not having the header
		  written, even though we had already written a length which
		  included the header.
		* Changed CSafeFileIO's ReadUInt128 to return an instance, which
		  simplified usage and matches the other Read-functions.
		* Added missing exception-handler to CIndexed in case of invalid tags.
		* Marked the log-event triggered when an IP was filtered as
		  non-crticial, since this event isn't critical and can be very common
		  depending on the ipfilters used.
		* Changed unittests for CFormat when empty strings were specified for
		  a field of type '%s', since some implementations of printf produced
		  different results than others, making it impossible to check against
		  those.
		* Fixed unittests for reading of UInt128 values which didn't consider
		  endianess.
		* Changed the use of Cmp to either '==' or '!=' to improve
		  readability, and simplified the sorting of the server-list when
		  sorting by name to only use the displayed name, since the special
		  cases that were being considered led to unpredictable results.
		* Fixed non-wxbase apps not terminating properly.
		* Fixed adding of comments to shared files.
		* Properly implemented a couple of functions for the remote version of
		  the DownloadQueue, which did not match the signatures of the normal
		  class.
		* Changed CMuleListCtrl's SetSortFunc to public, so that subclassing
		  isn't required in order to sort a list.
		* Dropped the "otherfunctions" namespace, since we ignored it almost
		  everywhere anyway, via the "using" keyword.
		* Updated CFileDataIO unit-tests.
		* Fixed UpdateState getting called on clients after they had been
		  deleted (in some cases) and moved the call to the CUpDownClient
		  destructor.
		* Made CTag and CPacket unassignable.
		* Renamed ReadHash16 and WriteHash16 functions of CFileDataIO, and
		  changed them to return instances and take const references of
		  CMD4Hashes, rather deal with char*. A few other places were
		  similary changed.
		* Dropped the static Exists function from CFile, as it is simpler to
		  just call wxFileExists directly.
		* Removed the ability to attach/deattach file-destriptors to a CFile.
		* Merged handling of seeking in the CSafeFileIO interface.
		* Some more changes to CMemFile:
			* Making seek const and dropped resizing of the buffer if it
			  seek'd past the end.
			* Made the class uncopyable and unassignable.
			* Changed the constructor that takes an external buffer to take a
			  char* rather than a const char*, since the class allow for
			  modifications of attached buffers.
			* Removed the growth-rate from the attached-buffer constuctor, as
			  we dont make use of it and should avoid it in any case.
			* Added sanity check for the length passed to the SetLength
			  function, to avoid accepting negative values.
			* Other misc changes.
		* Removed the ability to detach a buffer from a CMemFile and the
		  accessor function that returned the current buffer. Instead, we now
		  simply use the Read function, which is equivalent of what we did
		  before in any case, but safer.
		* Unified the logging of packets received from other clients, so that
		  the type of packet received is always logged, as is the cause in
		  case of an error.
		* Fixed a couple of assertions which had the checks inverted.
		* Merged CFile and CSafeFile. Checks on reads and writes are now
		  performed in the CFileDataIO base class. The CFileIO class used in
		  kad was updated to handle this, though it currently only understands
		  EOF exceptions. This completes the majority of the changes
		  resolving around the usage of exceptions.
		* Fix compilation error that would only trigger on some versions of
		  GCC, even though the code appears to be illegal.
		* Disabled pragmas when building unittests.
		* More fixes in MuleUnit for templates.
		* Disabled logging when running unittests.
		* Changed CFileDataIO to use the new IO exception types, which allows
		  for better error handling (i.e. EOF exceptions, IO read/write
		  failures) and prepared for making use of the IO failure exceptions.
		* Reorganized, and removed some includes.
		* Fixed a couple of places that threw exceptions by pointer.
		* Moved exception handling from CServer to CServerList when loading
		  servers, which better allows for handling of invalid servers.
		* Fixed some debug-strings which were wrongly marked for translation.
		* Added IO-exception types, which will be used by CFileDataIO.
		* Moved exception handling from CFriend to CFriendList when loading
		  the list of friends, so we can stop trying to read a bad list.
		* Added missing include to MemFile.cpp
		* Changed some runtime-error checks from throwing the CInvalidPacket
		  class to instead using the MULE_VALIDATE_* checks.
		* Simplified the usage of CTags by changing the getter functions to
		  throw an exception if the function didn't match the type of the tag.
		  This allowed for the elimination of explicit checks in most places
		  where CTags are used.
		* Initialized an uninitialized variable in CContact.
		* Fixed stack-trace parsing for files with '+' in the name.
		* Improved exception handling in the CTag constructor would could leak
		  if the tag had a string name and reading the body raised an exception,
		  or if the tag was a blob and reading the body failed.
		* Added checks for code that uses the CTag class, since just assuming
		  that a tag with a specific id is of a specific type is unsafe. Also
		  changed the getter functions to return a default value should they
		  be called on a tag of the wrong type to avoid crashes in that case.
		  Finally, we no longer just ignore unknown tag-types, instead we
		  throw an exception. This is needed because we cannot determine the
		  length of the unknown tag, and thus can't skip it, making further
		  reads from the input file suspect.
		* Largely reworked the use of exceptions. Catch(...) is out, only to
		  be used when memory-leaks are to be avoided. This insures that
		  unexpected exceptions can be detected.
		* Removed an exception handler that didn't have anything to catch.
		* Changed CreateHashFromInput to use the CSafeFileIO interface and to
		  safely handle exceptions without leaking. Also removed some
		  definitions of MFC debug-macros and replaced them with wx macros.
		* Fixed the largefile-checks under windows.
		* Changed CMemFile and CFile to implemenations of the CSafeFileIO
		  interface. CSafeFile was moved to CFile.* to avoid circular
		  dependancies.
		* Dropped the CSafeMemFile which didn't provide any extra
		  functionality and instead made CMemFile derive from CSafeFile.
		* Simplified CFile a bit, in preparation for larger changes:
			* Removed the Length() function, since there is also GetLength().
			* Removed duplicate definition of seek enums.
		* Changed the checks for large-file support so that users wouldn't
		  have to export the LD_LIBRARY_PATH variable or similar when running
		  configure.
		* Updated CIPFilter documentation.
		* Changed the ipfilter class from just asserting on invalid ranges to
		  not actually inserting them, since that would cause undefined
		  behavior.
		* Compilation-fix for Mandrake Linux.
		* Added checks against largefile support to configure.
		* Added helper-function that returns the length of a file, without
		  having to open it first.
		* Moved the loading of the ipfilter-files so that they are loaded
		  before the server.met file is loaded. This ensures that the servers
		  are filtered when start aMule.
		* Fixed some problems in MuleUnit when used with templates.
		* Fixed the CheckNewVersion function, which would crash on failure.
		* Dropped extra verbosity from CFormat's assertions, since they now
		  produce backtraces anyway.
		* Moved backtrace functions to the MuleDebug.* files and added
		  backtraces to uncaught exceptions.
		* Improved assertion-handling on shutdown and other situations.
		* Increased the verbosity of assertions in CFormat.
		* Fixed the "Is Textfile?" check which didn't handle whitespace.
		* Added support for gzipped ipfilter.dat files and added checks that
		  should ensure that we only try to parse text-files.
		* Added function for converting long-longs to strings in MuleUnit.
		* Moved some functions not part of the CFile class from the CFile.*
		  files to FileFunctions.*.
		* Fixed a bug where shared files could be added to the shared-files
		  ctrl multiple times.
		* Fixed the hasher-thread, where the wxMutexGuiLeave function was
		  called twice and improved error-checking on thread-creation. Lastly
		  moved static variables from the header, since they need not be
		  specified there.
		* Removed non-functional hack from CClientUDPSocket, which would cause
		  an infinate loop when triggered.
		* Improved handling of assertions that occur during startup.
		* When adding sources, add the source to the appropriate file first,
		  before trying to update comments and ratings availability.
		* Removed a couple of checks against 'this' being NULL.
		* Changed the handling of UDP requests for sources, so that the
		  locally connected server would be entirely skipped, instead of the
		  packets just being discarded.
		* Fixed a number of places where attempts were made to catch by
		  pointer, even though the exception was thrown by value.
		* Removed various unused variables.
		* Fixed a bug in the download queue which would result in duplicate
		  entries on the queue for local source-requests. At the moment this
		  did not result in any problems since all entries were removed from
		  the queue once sources had been requested for the file.
		* Removed the 'h' modifier from a number of format-strings where the
		  field type is 's', since that modifier does not apply to that type.
		* Simplified mule-exceptions and added more information to the
		  unhandled-exception handler.
		* Added unittests for CSimpleParser.
		* Removed the need for exception-handling in CSafeFileIO's
		  ReadOnlyString function, by allocating the buffer on the stack.
		* Fixed potential deadlock in CClientUDPSocket that could trigger when
		  an error occured during receiving.
		* Removed a number of overloaded functions from the CSafeMemFile,
		  since neither of those added any functionality. Also fixed a bug in
		  the checks against reads past the end, that checked against the
		  buffer-size rather than the (possibly smaller) file-length.
		* Marked CFile's GetLength() function as virtual.
		* Removed the unused class CSafeBufferedFile, which didn't implement
		  buffered file-IO anyway.
		* Added the ability to filter search-results. The filter select which
		  entries are displayed and supports regular-expressions. See
		  www.wxwidgets.org/manuals/2.6.2/wx_wxresyn.html for an overview of
		  the syntax. Also added the ability to filter known files from the
		  results.
		* Added sanity checks on values read when loading settings for lists.
		* The middle mouse button now opens the details-dialog for sources and
		  files when clicking on the download-queue.
		* Fixed sort-arrows on listsctrls not being displayed after startup.
		* Set the background color of the chat textctrls to white, in order to
		  ensure that the text stays readable regardles of the theme used.
		* Largly changed the way ipfilter.dat files are handled by the
		  ipfilter class:
			* When updating the list of ip-ranges, either via the reload
			  button or the update-from-url functionality, the existing ranges
			  are dropped to allow for dropping of ranges no longer to be
			  filtered.
			* In order to allow for ip-ranges specified by the user, a second
			  file has been added (ipfilter_static.dat), which is always loaded
			  after the normal ipfilter.dat file, so that it takes precedense.
			* When either of the two ipfilter files don't exist, a template
			  file is created which contains a description of the use that
			  that file.
			* When loading zipped ipfilter files, the files are unpacked in
			  place. Doing so largely elimates the overhead compared to
			  loading normal files.
			* Moved loading of the ipfilter.dat files, so that it done after
			  the GUI has been loaded.
		* Removed the unused ExternalConnClientThread class.
		* Merged two copies of the validateURI function in StringFunctions.*
		  and fixed a mem-leak.
		* Simplified the Update() function in the ipfilter-class, removing the
		  use of special cases when calling it.
		* Moved custom tokenizing code from the ipfilter-class to a seperate
		  class and dropped a couple of custom functions that didn't provide
		  enough of a performance boost to warrent the extra code.
		* Added unittests for the StringIPtoUint32 function, updated the
		  documentation for the function and fixed the bugs that appeared:
			* The last field was not restricted to the range 0..255.
			* Fields containing huge values could overflow to negative values
			  and would not be caught by the sanity checks.
		* Changed ASSERT_EQUALS so that descriptions only gets created in case
		  of a failed comparison, since this would otherwise result in the
		  attempted deference of end iterators and the like.
		* Moved the RLE classes to a seperate set of source files.
		* Removed probematic operator<() template function from WebServer.*,
		  and replaced it with a specialized struct. This was required since
		  the < operator would be instantiated for incorrect data-types.
		* Updated documentation for the CFormat class.
		* Dropped support for long doubles in CFormat and merged handling of
		  the other floating-point types.
		* Improved CFormat unittest, which was cluttered by serveral variables
		  with too similar names.
		* Fixed the ASSERT_EQUALS macro in MuleUnit, which would previously
		  evaluate parameters multiple times.
		* Removed the unused NeedUTF8String() function.
		* Fixed master-hash parsing for ed2klinks, which would always fail due
		  to a couple of assertions that had been badly translated into
		  exception.
		* Changed the way clients are deleted on shutdown, to help detect the
		  presence of dangling pointers caused by incorrect removals.
		* Fixed bug #494. Clients with score zero not being considered as
		  candidates for uploading.
		* Fixed a few warnings.
		* Improved handling of uncaught exceptions in the MuleUnit framework.
		* Added unittests for the CFormat class and fixed discovered errors:
			* Improved handling of string format fields.
			* Fixed a < comparison of 0 against a wxString which caused segfaults.
			* Fixed the range checking code which would fail in some cases.
			* Fixed escaped percentage signs.
			* Added the missing implementation of IsReady().
			* Improved adherence to printf as specific in 'man 3 printf'.
		* Added unittests for the CRangeMap class and fixed the errors that
		  cropped up while writing said tests:
			* The assignment operator didn't return *this.
			* The equality operator was broken.
			* The erase function was broken.
		  Also changes ASSERTS to MULE_VALIDATE_PARAMS to enable testing and
		  ensure that the controlflow stays the same for debug and non-debug
		  builds.
		* Added a minimalistic unittesting framework called MuleUnit, which is
		  based on the EasyUnit framework (http://easyunit.sourceforge.net/).
		  The build target 'check' compiles and runs all existing unittests.
		* Fixed crash in CClientUDPSocket caused by two threads trying to send
		  and receive at the same time.
		* Removed unused Pause() function from UBT.
		* Fixed inf. loop in CClientUDPSocket, caused by poor error-handling.
		* Rewrote some poorly phrased messages.
		* Fixed uploaded data not being recorded in statistics.
		* Compilation fixes for wxGTK-2.4.2.
		* Removed the unused 'MakefileWin32' file.
		* Fixed crash in sockets that were destroyed after the UBT thread.
		* Improved source handling for known-files:
			* Fixed the possibility of source-counts getting out of sync.
			* Optimized source-removal slightly.
			* Added extra debugging checks to spot potential problems.
		* Changed access to vector of source statuses from using the []
		  operator to using the at function, to see if out-of-bounds access
		  was causing a specific crash.
		* Imported the UploadBandwidthThrottler from eMule, which should help
		  ensure that upload-limits are more closely followed.

	Special Thanks To:
		* All the translaters who did such a great and fast job.

---

## Version 2.0.3 — "Hell 2.0.3: Now with improved daemons!"
2005-06-15

	ken:
		* Enabled amuleweb to work from within the Mac application bundle
		* Fixed Online Signature not actually being enabled when user sets the
		  preference

	Kry:
		* Fixed #471 "compile error". Should compile on GCC4 again.
		* Fixed Solaris compilation error on XParseGeometry.
		* Fixed wrong MD5 hash calculation on 64 bits arch.
		  This fixes storing the wrong EC/webserver password on config file.
		* Fixed unneeded GTK libs usage on aMule remote GUI.
		* Added a warning on gd-lib not found (progressbar not shown on amuleweb).

	lfroen:
		* New daemon socket code, event based. Improved reliability and
		  speed problems fixed.

	volpol:
		* Fixed #417 "Upload priority is changed for completed files."
		* Added new display filter "Active"
		* Display of QR and aMule OS info in "Clients Details" dialog

	Xaignar:
		* Fixed warning on EC disabled for aMule daemon.

	Special Thanks To:

		* All the usual people.
		  You don't know who they are? Just check previous changelogs
		  (just not the previous one, ok?) :P

---

## Version 2.0.2 — " [Your Ad Here] "
2005-06-04

	boutros:
		* Ported the eMule Chicane web template to aMule.

	GonoszTopi:
		* Fixed #421: 'In Windows XP it lets to choose Konqueror,
		  Galeon and other Unix based browsers.'
		* Fixed #406 and #380: 'some clients get an unexpected very
		  high priority'

	ken:
		* Fixed a hang-using-100%-cpu-on-exit bug
		* Fixed a crash when enabling UDP after startup

	Kry:
		* Added Version Check (you can disable it on preferences).
		* Added "source comes from" (on the "Time remaining" column)
		* Now you can compile aMule without gettext, using --disable-nls
		  Additionally, aMule no longer stops configure if there is no gettext installed.
		* Fixed aMule shutting down if a source seeds file is 0-size.
		* Fixed HTTP download code not returning proper error code (causing crashes).
		* Fixed OS_Info packet only being sent to downlaoding clients.
		* Fixed Solaris mount info file name.
		* Fixed includes on daemon for Solaris.
		* Fixed mldonkey detection. Did anyone notice mldonkey bans aMule?
		* Fixed SetAllTimeTransfered parameter size (thanks eylzo)
		* Fixed #430: "Sources order by priority/status"
		* Fixed #442: "Sort by 'Time Remaining' puts files which are not transferring first"
		* Fixed #453: "Add option to export links with AICH hashes"
		* Fixed #458: "Wrong gauge size on shared files control "

	volpol:
		* Ports display fix.
		* A4AF swap to this fix.

	Special Thanks To:

		* Bug reporters:
			Ateo
			BeFalou
			MrFaber
			xushi

		* All the usual people. You don't know who they are? Just check
		   previous changelogs :P

---

## Version 2.0.1 — " Woops, HotFix "
2005-05-18

	ken:
		* Fixed Tray Icon compilation on Mac.

	Kry:
		* HOTFIX: Fixed 100% CPU usage because of network errors on some servers.
		* Fixed crash after removing a server.
		* Fixed sorting on the UploadList by Transferred (thanks eylzo).
		* Users/Files on server no longer show as negative if server sends wrong values.
		* Check for autopoint on configure to warn for gettext not installed.

	niet:
		* Updated xal.pl (some fixes).

	Phoenix:
		* Added DNS resolving functionality to amulecmd's connect command.
		  This is usefull for dynamic IP servers.
		  Now you can use the server's name instead of the server's IP address.
		* Fixed a bug in http proxy authentication code.

	Special Thanks To:

		* Contributors:
		  eylzo

		* Bug and feature reporters:
		  albatros_la
		  Lucky_JL
		  Mr Faber

		* All the usual people (translators, debugers, people at #amule, etc)
		  C'mon, this is a hotfix release, I can't add everyone again.

---

## Version 2.0.0 FINAL - The "Let's dedicate this to Tiku" version.
2005-05-01

	BigBob:
		* Compilation fix for WebServer.cpp and BaseClient.cpp with wx-2.4.2.
		* Compilation fix for OtherFunctions.cpp with Slackware 9.1.0

	CosmicDJ:
		* NetBSD compilation fixes.

	deltaHF:
		* Preferences for auto-sort download queue.
		* TCP and UDP port start now at 0 (remember - running amule as root is insecure!!)
		* Added aMule version info into "About" popup.
		* Show current DL speed from a client you are uploading to in "Remote
		  Status" column instead of in the "Speed" column.

	geeko:
		* Patch to complete html functionality of cas.
		* Fixed seg fault in cvs due to wrong type check.

	gnucco:
		* Improved the sources column and sorting in search window.
		  Now can toggle total sources/completed ascending/descending.

	GonoszTopi:
		* Unicode fixes:
			- UTF-8 conversion (reported by littletux)
			- webserver search results (reported by poulpe)
			- aMule version on webserver's Statistics page
		* Endianness fixes in EC.
		* Fixed appearing strange characters at the end of webserver's
		  log and debug log pages.
		* Fixed logo.jpg being not installed.
		* Webserver graphs are now resizable and rescalable.
		* Removed some unneeded code/data from daemon.
		* Added gcc #pragmas to reduce executable size.
		* Several improvements on EC network code:
			- EC now uses buffered I/O, so most EC transmissions will only
			  require one socket operation.
			- Added the ability to compress large packets with zlib, thus
			  reducing network load.
			- Some (not-so-CPU-consuming) compression is applied to small
			  packets, too.
		* A number of i18n fixes, mostly changing debug messages to be
		  untranslated.
		* Removed ECv1 compatibility mode. Now all EC communications are
		  using the new v2 protocol.
		* Remote applications do not log to core's log anymore.
		* Fixed the GetLog() function to be compatible with wxWidgets-2.5.4
		* Reworked template finding - after installation, no more copying
		  of webserver files are needed.
		* Added new command 'reloadshared' to amulecmd, to force reloading
		  of shared files list.
		* Fixed configure script to use the right arguments with gdlib-config.
		* Fixed configure script to check for gd in the right order.
		* Fixed preferences being not saved when set from web interface.
		* Fix for setting download priorities via web interface.
		* Added configuration file for remote apps.
		* Reworked command-line parameters, also added a lot new ones
		  (for remote apps).
		* Fixed *.desktop files to be really UTF-8.
		* Fixed Makefiles to be able to compile alcc without alc.
		* Added man pages - English only, for this time. Great thanks to
		  Vollstrecker for his initial work on the man pages!
		* Fixed pressing the 'Clear Completed' button causes a logout
		  on the web interface.
		* Added CVSDATE checks to EC, to make sure that core and remote
		  apps are from the CVS tarball (for CVS users).
		* Improved filename cleanup.
		* Fixed setting priorities via web interface on both downloads
		  and shared files.
		* Enabled translations on amuleweb and amulecmd.
		* Fixed the language selector on Preferences to show the languages
		  that we really have.
		* Language list is now always sorted alphabetically, but 'System
		  default' is always the first item in the list.
		* Changed locale saving method, so it won't have to be reset to
		  'System default' on each version change.
		* Added Hungarian man pages.
		* Fixed sorting in web interface.
		* Compilation fix for gcc-3.2.2 and 3.2.3.
		* Win32 (wxMSW) compilation fixes.
		* Enabling configure way of aMule compilation under MinGW/MSYS.
		* Several improvements of the win32 version of aMule and utilities.
		* Totally disabled the ability to connect to aMule with an empty password.
		* Enabling translations on remote GUI, too.
		* Configure will now list (almost) all libraries it will/wants to
		  use for build.
		* Hungarian translation update.
		* Remote GUI compilation and link fixes for optimized builds.

		**** For users, who already got used to amulecmd's or amuleweb's
		**** command-line parameters: PLEASE READ DOCUMENTATION CAREFULLY!

	Hetfield:
		* New popup menu and events management for new wx SysTray
		* Speed Bar color (on the new wxTray) is setted in the statistics color selection
		  (as old GTK tray!)
		* Some configure checks and cleanup

	Kry:
		- Global -
		* We're now fully compatible with the ed2k Unicode implementation, allowing Unicode searches,
		   comments, usernames, file names, ...
		   This works both for unicode-aware servers and clients.
		* New SysTray code using wxWidgets' wxTaskBarIcon with several hacks for making it
		   properly transparent while keeping the nice download speed bar. Multiplatform, also.
		   Activated by default on > wx2.5.3
		* Corrected a nice mistake where wxSOCKET_LOST was identified as error.
		* Fixed clasic systray code to support unicode names properly.
		* Removed/Cleaned/etc header includes.
		* Fixed unicode bug on wxOpen preventing to share some files.
		* Fixed the SERVER_IDENT packet processing.
		* Auto-sort code for list controls. Disabled by default, too much flickering on mac and gtk2.
		* Fixed eMule+ version popping up on eMule stats.
		* Debug log lines now go to console on daemon
		* Moved hello packet sending to after client successful connection.
		* Added the RepeatLastAction function that turned up to be... well, funky.
		* Fixed debug of disconnected clients.
		* Fixed duplicated mod string on clients.
		* Fixed unhandled exception from server TCP socket.
		* Fixed lowid clients callback.
		* Fixed duplicated floating point functions being called every second (CPU improvement).
		* New file is added: tree.hh, credits to Kasper Peeters, <K.Peeters@damtp.cam.ac.uk>
		   It's a stl-like tree and I really enjoyed coding with it.
		   More info on http://www.damtp.cam.ac.uk/user/kp229/tree/
		* Fixed a crash on Proxy code created by bad string initialization causing mem corruption.
		* Added wxProxyData::Empty() to properly clean aMule proxy data when needed.
		* Fixed unitialized variables on MemFile.cpp and SafeFile.cpp that made valgrind scream in pain.
		* Fixed the CUpDownClient::SendFileRequest crash you were all screaming about on rc8 :P
		* Fixed SUI failures with kernels >= 2.6.10. This failures and asserts were created by the locking
		  of /dev/urandom that was introduced on 2.6.10, and that made CryptoPP fail on creating a random
		  pool for the SUI identification. This is more a workaround actually than a fix, but will work perfectly.
		* Completed files now go to shared as the should.
		* Fixed search on localised languages.
		* UDP disable is working properly now.
		* Close the UDP socket if we're not listening anymore.
		* Permisions for shared files are no more. They make no sense, network-wise.
		* Fixed comment updates being... fuzzy.
		* Fixes to timeout handling of sources to avoid timing out a source that was never processed.
		* Fixed a memleak on log code.
		* Proper handling of Thread reating/Running errors.
		* Fixes for wrong string creation on several places over the code.
		* Fixed log reset asserts and made it work properly (at last!)
		* Auto-run webserver on startup functional
		* Fixed a wild assertion if a empty line gets to ED2KLink file
		* Merged Gonosztopi's work on EC for the stats tree with performance and safety fixes.
		* Merged Gonosztopi's work on a patch from Mayfoev to use aux server ports, with some cleaning.
		* Fixed the crash on non-std locales because of date/time functions.
		* Get rid of more ugly unicode2char stuff by making the logfile a wxFFileOutputStream.
		* General speedup of log file.
		* Proper order of files on Makefile.am, much better to know compilation progress by first letter.
		* Moved at last all stats to where they belong: the new files Statistics.cpp and Statistics.h.
		* Fixed assert on client list view caused by unknown client state.
		* Hopefully avoid the never-deleted sockets (passive sources)
		* Fix for the case that someone dares having 65536 active connections
		* Made the sources connection spread evenly among part files.
		* Fixed server-list packet from server not being handled properly.
		* Fixed crahes on re-sort of download queue.
		* Fix for server connection packet not using unicode username.
		* Search results on unicode are displayed properly now.
		* Files on download queue with unicode names are displayed properly now.
		* Unicoded filename is saved correctly on .met file, and loaded according to it.
		* Files with utf8 chars can be completed now ;)
		* Shared files with uciode names do show correctly now.
		* Modification time for files is fixed to keep coherence (GetLastModificationTime usage).
		* Filenames on known files list (known.met) are saved in utf8 too now, so correctly loaded
		  and compared lately.
		* Fixed unicode identification to clients and server.
		* Use BOM header on the known.met, part.met and emfriends.met for unicode tags.
		  Sad, but there's no other way to keep compatibility with eMule files.
		* Fixed memleak on ExternalConn.cpp.
		* Fixed the "Invalid UTF8 string passed to pango_layout_set_text()" messages on GTK2 builds.
		* Fixed (again) the Shareazza identification. They have used 3 compat. client numbers already,
		  will they take one once and for all?
		* Fixed memleak on log reset.
		* Fixed memleaks on closing while global search.
		* Fixed serious memleak on tag code for packets. And I mean serious.
		* Removed the unused UTF82char function.
		* Fixed queue limits on upload queue (off-by-one bug).
		* Fixed hash for files with size (n*PARTSIZE).
		* Fixed compilation for systems where zlib is not linked by default.
		* Fixed OP_SENDINGPART to actually be a edonkey protocol and not emule protocol packet.
		* Fixed memleak on AICH thread.
		* Fixed several memleaks on ed2k links handling.
		* Fixed threads not being closed properly, specially the global search one.
		* Fixed serious memleak on client UDP reask
		* Don't remove the server because of failedcount if it's static.
		* When the user tries to remove a static server, we prompt for confirmation.
		* Files on non-ansi named folders are no longer rehashed on every restart.
		* Don't discard UDP packets on wxSOCKET_WOULDBLOCK. This improves UDP socket
		  reliability a lot. Remove the packet from queue if sent, keep it if it's not sent because of wouldblock,
		  and drop it on any other error.
		* Send previously queued UDP packets before we send a new UDP packet.
		* Fixed aMule crashing on second global search under certain circunstances.
		* Fixed the hanging on connecting to server.
		* Fixed dynip servers to connect properly (happy portuguese users!).
		* Moved:
			CMemFile.h		-> MemFile.h
			filemem.cpp		-> MemFile.cpp
			packets.cpp		-> Packet.cpp
			packets.h			-> Packet.h
			sockets.cpp		-> ServerConnect.cpp
			sockets.h			-> ServerConnect.h
			UDPSocket.cpp		-> ServerUDPSocket.cpp
			UDPSocket.h		-> ServerUDPSocket.h
			types.h			-> Types.h
			server.cpp			-> Server.cpp
			server.h			-> Server.h
			timer.cpp			-> Timer.cpp
			otherstructs.h		-> OtherStructs.h
			otherfunctions.h		-> OtherFunctions.h
			otherfunctions.cpp	-> OtherFunctions.cpp
			opcodes.h			-> OPCodes.h
			color.h			-> Color.h
			endianfix.h		-> EndianFix.h
		* Changed OP_GLOBFOUNDSORUCES  -> OP_GLOBFOUNDSOURCES
		* Unicode fixes for "Gtk-CRITICAL **" errors on shell.
		* Unicode fixes preventing compilation for Packet sources.
		* Unicode fixes for StrToULong usage over atoi.
		* Fixed eMule+ version string.
		* Implemented lugdunums new extension of GETSOURCES, includes SIZE (uint32)
		  to avoid problems created by anti-p2p companies
		* Removed MetaTags extraction code, we're not going to use it anyway.
		* Fixing some crashes on wrong string handling.
		* Support for unicoded comments for files.
		* Moved Online Signature (aMule and eMule) to wxTextFile for proper handling.
		* Fixes a serious issue on UDP packets (and contributed to eMule).
		* Debug output of server sources added.
		* Fix for garbage saving on file copy.
		* Fixed the server disconnection due to bad handling of TCP packets.
		* Added a fallback for wrong TCP packets handling to avoid server disconnect.
		* Proper memory overruns checks on SafeFiles.
		* Fixed the partfiles being the only thing shared under certain circunstances.
		* Fixed bug #193: False display with empty share list
		* Fixed bug #258: "Max port-value allowed is too high due to secondary port"
		* Fixed bug #276: aMule crached when tried to start. (It says "crached on the original report)
		* Fixed bug #299: "Assertion when clicking in DQ/Last Reception column"
		* Fixed bug #303: "Too many files republished by your client software. Please upgrade it."
		   Proper handling of incremental file publishing avoids server bans ;)
		* Fixed bug #317: Added GUI and functionality for 'Start next file on same category'.
		* Fixed bug #319: When sort is changed, make sure the item focused is again focused.
		* Fixed bug #321: Razoback2 stats page for shared files.
		* Fixed bug #331: 'ED2k link bar gone after 2x click on search button' making it a feature
		   instead of a bug. Now you can toogle the ed2k link handler clicking on search toolbar button.
		* Fixed bug #334: Main category type not stored on crash.
		* Fixed bug #345: [Mac] popup windows open on other monitor.
		* Fixed bug #348: "Right-click on friend in friends list does not select it"
		* Fixed bug #362: "receive file list fails for non-ascii chars"
		* Fixed bug #349: "sorting of sources in 'Downloads' window"
		* Fixed bug #375: "Misc GUI bugs in Statistics window"
		* Fixed bug #374: "misc. problems with friends"
		* Fixed bug #405: "Downloaded files have wrong priority"
		* Fixed serious bug with 0-sized files.
		* Fixing serveral threading issues and possible crashes/missbehaviours on search.
		* Searchs now start inmediately and also finish sooner.
		* Added a warning if no video player is set on preferences and tried to preview.
		* Decoupled NetworkFunctions and StringFunctions headers.
		* Added QueueDebugLogLine for... uh... queueing debug lines.
		* Encapsulating network stuff at NetworkFunctions.
		* Removed all network platform specific code from the main code, and leave it to
		  NetworkFunctions (and gsocket). And I removed the htons and htonl everywhere.
		* Fix for egcs compiler crashing on aMule compilation.
		* Changed the CTags structure to a safer and nicer version, compatible with eMule's.
		* Added support for a lot more ed2k Tags.
		* Support for download stats per client.
		* Added the hability to rename a file using F2
		* Fixed crash on sorting an old tab.
		* Improved socket debug, and moved the backtracing function to OtherFunctions.
		* Fixes dynip servers not being detected by server UDP socket.
		* Fixed a lot, lot of input data lost on EMSocket, causing much better transfers.
		* Fixed corrupted parts info store/retrieve on partfiles with eMule compatibility.
		* Fixed ed2k protocol file type publishing.
		* Fixed a lot of network performance issues and lost packets all over the TCP/UDP code.
		* Fixed download bar on tray icon (Icon file has now red background to create a mask from it).
		* Fixed crashes on Logger class derived from bad unicode2char usage.
		* Added "Prefix where amule will be installed" to configure output.
		* FileDetailDialog is now resizable, and file names list ctrl resizes vertically and horizontally with it.
		* No horizontal scrollbar on log, let lines wrap to avoid auto-scrool on long lines.
		* Gnucco's alternate sorting of search list ctrl
		  See http://forum.amule.org/thread.php?threadid=5344&sid= for details.
		* Big rework of the Friends class, list, and everything.
		* Cached the Operating System info and added to --version flag.
		* Added Online Signature update time functionality and widget disabling on OS disable.
		* Slightly bigger list for the preferences items to fit them all
		* Added a static text for recursive sharing via right-click to avoid questions.
		* Systray can now be enabled/disabled on preferences, dynamically, and is applied
		  as soon as the checkbox is checked. Default is DISABLED.
		  Also, the minimize to tray checkbox is disabled when systray is not enabled, and when using
		  the new systray code (the wx tray), we don't have the Window Manager dialog anymore.
		* Check for Online Signature folder existance when enabled.
		* Fixed a lot of unicode bugs on file handling by adding fallbacks to proper encoding.
		* Set minimize to tray to false if no tray enabled.
		* Fixed a crash... on... assert... hum... that one was actually funny.
		* We should not start next file on cancelling a download. Now we do not ;)
		* Stopping a global search works properly now, the thread for global search is deleted on stop.
		* Zero the Online Signature on exit.
		* Fixed a crash on exit while stillstarting up.
		* Fixed aMule nto starting anymore if skin file name is void and skins are enabled.
		* Proper use of wxWidgets functions for ISO date formatting.
		* Never show the download list filter on search category selector.
		* Lots of fixes for wx2.6.0 compilation, wxSizer, and other changes.
		* Fixed the download limits not being applied correctly. this should amke MUCH BETTER download
		  speed for people with download limits set.
		* Fixed sockets not being closed on daemon.
		* Fixed chmod message on Incoming/temp folder on smbfs.
		* More info on the init. text and on backtraces (Operative Sytem, kernel version, etc).
		* Fixed crash caused by random value returned on DeletePage().
		* Fixed Reload Shared Files not re-reading sharedfiles.dat
		* Fixes the hangups on exit, specially on Mac.
		* Fixed the AUTHORS file.
		* Fixed UDP socket bug on size of OP_REASKFILEPING message.
		* Abort loading of shared files if we are shutting down.
		* Fixed crash caused by socket die on ConnectionEstablished function.
		* Added contact info to documentation and about button.
		* Fixed (again) mplayer usage as video previewer.
		* Fixed a network bug on SetStartNextFileSame not being set.
		* Proper usage of wxProcess::Exists( for webserver running on start check.
		* Cleaned configure/Makefile from a lot of bad usage of flags and libs.
		   This makes for a smaller executable now also.
		* Merged Martimac's fix for FreeBSD 5.4-PRERELEASE
		* Fixed friendslot assignation, about 12 times.
		* Fixed logging of not-yet-sent messages by adding it to queue and send on connect.
		* Fixed message sending to unknown clients.
		* Avoid the posibility of a Too Many Connections blocking a chat.
		* Fixed buttons/textentry not enabled on new chat tab.
		* Fixed tabs' 'X' not working properly when there are too many and don't fit on screen.
		  Use new wx code instead of Madcat's code on wx2.5.4 and above, for the 'X' closing.
		* Multiple selecting ed2k links and clicking on copy ed2k works now for search items.
		* Fixes the multiple removal of friends
		* Fixed multiple message send to friends.
		* Fixed multiple filelist requests
		* Fixed multiple friend details dialog show.
		* Adds a warning for trying to set multiple friendslot.
		* Fixed Incoming folder content not being sent on shared files request.
		* Fixed completing of file setting transfered instead of completed to file size.
		* Fixed --with-crypto-prefix flag not pointing to actual crypto folder.
		* Added memleak check on exit using wxWidgets native fucntions, enable via wx qa lib.
		* Rewrote wx*Sizer* handling on Stats page and making more space available.
		* There is no curl anymore needed/used on aMule. Coded my own handling using wxHTTP.
		* Added partial/total bytes to the http download dialog.
		* Fixed sizers usage on Client Details, fixes overlapping labels and such stuff.
		* Fixed client stats not updating on clientnumber going down to zero.
		* Fixed "total transfered datal isn't saved on crash/kill" bug.
		* Fixed flushing of files on copy with read-only flag set.
		* Added "total downloaded"/"total upload"/"total requests"/ "total accepts" to partfile saving.
		* Fixed rehashing of unicoded file names on aMule restart.
		* Fixed aLinkCreator compilation for wx2.6.0
		* Fixed upload speed not being reset when all clients lost and keeping old value.
		* Fixed port output on console showing negative numbers.
		* Lot of Kad porting (NOT functional yet).
		* Fixed (c) strings all over the code with proper year specifications.
		* Fixed unicode2char usage to a bare minimum.
		* Moving from libc usage to wxWidgets multiplatform implementations.
		* Killed c_str() usage from aMule, except on very specific ways and only for speed reasons.
		* General cleanups and speedups here and there.

		- CPU arch Specific -
		* 64 bits archs fix for AICH thread.
		* Some amd64 compilation warning removal.
		* Fixed endianess bug on PeekUInt16
		* Fixed client IP endianess on big endian archs.
		* Getting ENDIAN_SWAP_* to a bare minimum (just interface)
		* Fixes endianess of local_ip, which is anyway almost all times 0.

		- Core/GUI Specific -
		* Fixed daemon unhability to handle sources properly. Daemon now takes, handles, and
		   processes sources in a proper way (making it at last a real competitor for monolithic).
		* Don't show geometry option for daemon, makes no sense.
		* Properly display "aMule Daemon" instead of "aMule" on daemon.
		* Fixed statistics tree interdependence with GUI, splitting it to core/gui way.
		   In short, we have statistics tree on webserver, amulecmd and remote GUI :)
		* Graphic statistics are now decoupled from GUI.
		   We have statistics graphics on webserver remote GUI.
		* Decoupled Friend list from GUI.
		* Fixed a bug on set comment on a file on ECv2.
		* Fix for log on unicoded webserver.
		* Fix for global daemon thread not closed on exit.
		* Splitting of core/gui on SearchDlg.
		* Fixed a crash on websocket thread creation.
		* Reactivating Chat windows on remote GUI.
		* Proper fix for the segfault on exit caused by EC.
		* Removal of CryptoPP usage on amulegui.
		* Fixed a possible crash on daemon startup.

		- BSD Specific -
		* Fixed BSD compilation for <sys/types.h> inclusion.
		* Fixed FreeBSD 4 prerelease (DragonFly) compilation on gtkplugxembed.c

		- Solaris Specific -
		* Fixed Solaris compilation and linking.
		* Fixed need for inet_addr on webserver on Solaris.

		- Mac Specific -
		* Fixed Mac friends handling.
		* Proper importing of files for Mac.
		* Proper reading for amuleweb config on Mac.
		* Made default Incoming folder for Mac to "~/Documents/aMule Downloads"

		- Windows Specific -
		* Fixed a lot of compilation problems.
		* Use proper wxLog class to avoid popups on Windows.
		* Remove the usage of chmod on Windows.
		* Fixed the systray background on Windows.
		* Fixed systray menu on Windows for proper layout.
		* Fixed DirectoryTreeCtrl on Windows to show all disk drives and folders.

	Ken:
		* Fixed Mac bug: window was a little larger each restart
		* Fixed aMule.tmpl so Safari can work with amuleweb
		* On Mac, enabled Command-clicking in lists to toggle selection
		* Solved the DECLARE_ABSTRACT_CLASS() mystery on wx-2.4.2. Now
		  we can have UDP socks5 with wx-2.4.2.
		* Included CVSDATE with version in amulesig.dat
		* Fixed an endianness bug with webserver
		* Fixed last (I hope!) endianness bug with IPFilter
		* Fixed a major endianness bug with widespread effects.  On Mac,
		  servers don't fail continuously until eventually removed from the
		  list; server pings work.  Global search seems to work better.
		  DNS lookup of servers and ED2K link sources should now work.
		* Enabled support for ed2k links in web browsers for Mac
		  (although idiosyncracies of common browsers prevent it from
		  being as transparent as one would like).

	lfroen:
		* aMule remote gui implementation
		* Support for categories in webserver
		* EC additions
		* RLE encoder for shared files

	martymac:
		* Fix for FreeBSD 5.4-PRERELEASE

	ObsessionAl:
		* Patch to include CVS date in about box.

	Phoenix:
		* Fixed crash in CClientReqSocket::ProcessExtPacket()
		processing of OP_COMPRESSEDPART.
		* More UNICODE fixes.
		* Fixed WX_SYSTRAY compilation on wx-2.4.2.
		* More proxy updates, we are getting there.
		* Small UI bug: double click on a server did not change the
		"Connect" button to "Cancel".
		* Changed some deprecated IsKindOf(CLASSINFO()) to
		wxDynamicCast().
		* Fixed crash in CUpDownClient::SendFileRequest(), short
		circuit evaluation was reversed.
		* Created Proxy dialog on preferences.
		* Updated muuli.wdr for wxDesigner version 2.11 -- no more
		manual patching for wxFIXED_MINSIZE required.
		* Fix for rommel's report of IP filter problem.
		* No more IsKindOf(), all replaced by dynamic_cast<>().
		* No more wxDynamicCast(), all replaced by dynamic_cast<>().
		* Fixed multiple instances of event handlers in
		CClientReqSocketHandler	and CServerSocketHandler.
		* In StateMachine.cpp, m_state is now private and state machine
		code is now thread safe.
		* Added base64 encoding/decoding support to aMule.
		* SOCKS5 and SOCKS4 proxy support is working now.
		* HTTP proxy support is working now.
		* Changed the output of the "Oops" to give better instructions
		to the user.
		* Fixed a bug in proxy code that was making gui too slow. Code
		was performing unnecessary DNS.
		* Applied patch from volpol to fix use of deprecated functions
		in wxGTK-2.5.3.
		* Applied patch from geeko to complete html functionality of
		cas.
		* Fixed a big bug in proxy code. Sockets were not continuing
		conversation after connecting to sources.
		* Fixed a crash due to an unicode issue while logging.
		* Show some activity upon destruction of the DownloadQueue.
		* Preparing the field to bind to a fixed interface.
		* Sanity checks on socket creation.
		* Fixed the backtrace message.
		* Added a static text to Preferences->Connection->Client TCP
		port to show the value of the client UDP port.
		* Fixed a crash on webserver, all return values of
		SendRecvMsg_v2 must be checked for NULL return value.
		* Fixed an uncountable number of potential segfaults on
		amuleweb because almost no return value of GetTagByIndex and
		GetTagByName were beeing checked for NULL.
		* Fixed the following bug in the search dialog window: if you
		typed a letter by mistake or if you use the down arrow from 1
		to 0, both actions on a wxSpinCtrl, aMule would crash.
		* Fixed the GetTagByIndex and GetTagByName segfaults in
		amulecmd.
		* Fixed a problem with saving the preferences, that in some
		situations would not be saved.
		* Fixed an assert when loading skins, the count number was one
		unit too high.
		* Fixed amuleweb template processing, Clear Completed button
		on transfer link was not showing.
		* Fixed amuleweb template processing, Reload List button was
		not beeing translated.
		* Small adjusts to ObsessionAl patch to include CVS date in
		about box.
		* Fixed a bug in UTF82unicode(), reported by Mr Faber.
		* Got rid of sscanf in NetworkFunctions.h. This has caused a
		crash once, reported by Mr Faber.
		* Fixed a lock with high CPU usage when crashing in amuled,
		because wxExecute() could be called from the FatalErrorHandler()
		not from the main thread, which is currently prohibited in
		wxWidgets.
		* Fixed preview with mplayer or any other app that needs
		stdout/stderr.
		* Fixed lots of segfaults in amuleweb, thanks to alandar and
		Mr Faber.
		* Updated proxy debug code to use new logger.
		* Fixed a subtle bug in UINICODE builds. Now UTF-8 enabled
		UNICODE builds can read extended ANSI file names. In
		particular, UTF-8 UNICODE aMule build was not remembering
		an extended ANSI directory name for a shared directory.
		* Added a spec file to the CVS tarball. Now users can do
		rpmbuild -ta aMule-CVS-20050309.tar.bz2 and generate rpms for
		the tarball of the same day.
		* Fixed a bug in the spec file. The testing was beeing done
		with files from amule-dev-cvs, but CVS snapshots tarballs are
		done in amule-cvs directory.
		* Implemented changes suggested by bootstrap in aMule-CVS.spec,
		merged all the packages in a single rpm, changed the packager
		to "The aMule Team" and updated %BuildPreReq.
		* Fixed a crash in ListenSocket.cpp when a client could
		disconnect suddenly.
		* Spec file does not need autogen.sh, as noticed by
		GonoszTopi.
		* Removed krb5-libs require and krb5-devel buildprereq.
		curl-lib and curl-devel is enough.
		* Fixed an assertion in CFile.cpp, when browsing broken
		symbolic links. Now aMule is aware of them.
		* Added a test to the spec file to discover UTF-8 enbled LANG,
		so that we build the rpm with --enable-utf8-systray.
		* Removed curl dependencies from spec file, aMule now uses
		wxHTTP.

	Stefanero:
		* Work on the Man-Pages
		* Minor compile fixes
		* Lots of support and testing

	stsp:
		* Compilation fix for STL enabled wxWidgets.

	volpol:
		* Patch to fix use of deprecated functions in wxGTK-2.5.3.

	Vollstrecker:
		* Initial and further work on aMule and utils' man pages.

	Xaignar:
		* Improved logging for CFile, getting rid of the annoying
		  pop-up windows which were previously displayed.
		* Workaround for fonts getting changed on the log-view
		  when the clear-button was pressed (wxMac specific).
		* Work on getting aMule ready for win32, including fixing
		  the custom-drawing for listctrls.
		* Fixed threading issues with the UDP-sockets in daemon-
		  mode, which were the cause of a number of crashes.
		* Made the preferences dialog modal to fix problems where
		  it would be displayed at bad locations.
		* Ensured that the Banned-Count would be initialized to zero
		  rather than display a random value until it gets properly
		  set (not yet implemented).
		* Improved the "aMule has crashed" message, adding some
		  more information and fixed the backtrace to skip unneeded
		  frames properly.
		* Fixed some static text-ctrls not properly expanding, so
		  that some text would be cut off the end.
		* Fixed some position bugs in the progress-bar drawing and
		  addeed a black border. A4AF sources now displays that text
		  instead of an empty area.
		* Moved the placement of the "Initializing aMule" message on
		  startup so that --version will only result in the version
		  information and ensured that amule wont start in case an
		  invalid commands was given, instead printing the help info.
		* Fixed problems with selection on the clients-list.
		* Improved usage of compressed packets. Now only files that are
		  not in the list of known archive-formats are compressed, rather
		  than just Zip, Rar and Ace.
		* Improved error-handling when opening ports. If either the
		  EC or Server-UDP ports conflict with the other ports, then
		  a random safe value is selected in the range 1025 ... 2^16-1.
		* Fixed shared files being located twice during startup, which
		  also resulted in the AICH thread being run twice.
		* Fixed logging to stdout containing extra newlines.
		* Cleaned up and merged a number of split translated strings,
		  which should make it easier for translaters to work.
		* Fixed some status changes not resulting in removal from or
		  addition to filtered download categories.
		* Improved handling of multi-line log events on the main dialog.
		* Reduced the ammount of output to the console, changing printfs
		  to either normal or debug log events.
		* Escape-codes in ED2k links are now properly unescaped.
		* Cleaned up and improved the readability of the clients-details dialog.
		* Updated the modified listctrl widget used by aMule, so that
		  wxWidgets 2.4.x and 2.5.x will use a modified version from
		  that branch rather than a more generic hacked version. For one
		  thing, the headers are now drawn using the current GTK theme.
		* Properly handle rehashing of empty part-files.
		* Changed the "Filter Bad IPs" option to "Filter LAN IPs". Invalid
		  IPs will always be filtered, but LAN IPs will now only be filtered
		  if the option is enabled.
		* Added back-traces to asserts, in order to help debugging efforts.
		* Made usage of wxASSERT thread-safe.
		* Attempted to fix some longstanding problems with the notebooks.
		* Removed unused files: Preview.h and Preview.cpp
		* Updated, cleaned and unified license-headers for all aMule
		  related source files.
		* Improved the error-message displayed when a server couldn't
		  be added, so that it is clear as to why it couldn't be added.
		* Avoid flooding the console when searching for filetypes,
		  mismatches are now logged as debugloglines instead.
		* The "Clear" button on the search page now also clears the
		  search text.
		* Better handling of multi-line chat messages: The complete
		  message will be split by linebreaks and each line timestamped.
		* Fixed entries for connected servers in server-list not being
		  completly reverted to normal after disconnection.
		* Added handling of SIGINT and SIGTERM for gracefull shutdowns.
		* Renamed the config file from ~/.eMule to ~/.aMule/amule.conf.
		  The old file will not be removed, in order to allow backwards
		  compatibility.
		* aMule now automatically removes unavailable files from the
		  list of shared files.
		* Fixed right-clicking not selecting the tab being clicked on.
		* Fixed casts to pointers of higher alignment where it could
		  cause allignment crashes on SPARC, created general function
		  for doing this safely both SPARC and non-SPARC machinces.
		* Added a typesafe replacement for printf, designed with
		  inspiration from the format class in the boost library.
		* Improved logging capabilities. It is now possible to enable/
		  disable debugging output by category. All existing debug
		  calls where changed to support this. This can be controlled
		  in the preference dialog.
		* Fixed some problems with the connect dialog for remote gui.
		* Some pass-by-value fixes.
		* Moving de-initialization code from the CamuleApp destructor
		  to OnExit. This insures that the app-object would be valid
		  while the shutdown is in progress.
		* Moved deinialization code from OnRun in amuled to OnExit in
		  order to ensure that it was also run on premature exits.
		* Made safe connection-rate calculations the default behavior,
		  which should help avoid too fast connections.
		* Add class for keeping track of unusable sources, based on
		  the same class in eMule. This should reduce the ammounts
		  of connections made since bad sources are not re-asked too
		  often.
		* Fixed servers with IP 0.0.0.0 being added to serverlist.
		* Fix to IP-range parser in CIPFilter. Incorrect range in the
		  form "a.b.c.d-e.f.g." would not be caught.
		* Misc cleanups in CServerList.
		* Fixed creation of online-sig files.
		* Made DownloadQueue and ServerList observables.
		* Added a Observer/Observable implementation. This was needed
		  to implement a queue that would be kept in sync with another
		  queue thus allowing thread-safe delayed iteration over a list.
		* Fixed crash in search-list, where the search-packet would be
		  deleted twice.
		* Removed the usage of "ED2KServers" file, as the download-queue
		  now takes care of handling all types of ed2k-links.
		* Rewrote 'ed2k' utility in c++ and fixed support for extra
		  information appended to ed2k links.
		* Merged IP-check functions and moved it to NetworkFunctions.*.
		* Fixed usage of uninitialized variables in CPartFile constructor.
		* Removing unsused functions from CServerList.
		* Removed unused CArray.h file.
		* Fixed pontial wrong tag-count in server.met writing, which
		  would result in a corrupt file.
		* Disabled connection-try code, due to inherent problems with it.
		* Reworked the CDownloadQueue class.
		* Fixed creation of ED2K links for servers.
		* Removed the need for seperate AICH hashings of completing files.
		  Instead both AICH hashsets and MD4 hashes are created during
		  completion, and the AICH is simply discarded if corruptions are
		  found. This however is rare, and thus doing both at the same time
		  results in less time spent hashing.
		* Improved upon the "requested file not found" log-message, which
		  would happen when a client requested the hashset for an unknown
		  file.
		* Reworked the checks for free disk-space, should behave much
		  more consistantly now.
		* Fixed files being hashed twice, once when completed and again
		  after aMule had been restarted.
		* Make use of native GTK2 popup menu for text-ctrls when possible.
		* Disabled aMule on systems where wxGTK is older than version
		  2.5.1 and is compiled against GTK2. The big honking warning
		  in the log proved to be useless, but this should work ...
		* Added helper-function to of.h for removing values from a stl-list.
		* Fixed usage of windows font-type "Arial" in statistics-dialog.
		* Fixed logging of filtered IPs. Only 2 of four cases were logged.
		* Disallow External Connections if no valid password has been set.
		* Fixed both sources and files getting shown for the file-count
		  in the transfer dialog.
		* Added date to version-information for CVS snapshots.
		* Reworked CBarShader, making it use the CRangeMap class and getting
		  rid of needless floating-point math. This fixes some problems where
		  large chunks would be drawn as complete, even though only a small
		  part of the file was complete.
		* Fixed downloads being assigned to the default category despite
		  the extended options being disabled in search dialog.
		* Moved overhead calculations to the CStatistics class.
		* Removed enabling/disabling of the clear-downloads buttons. The
		  checks touched far too much code without adding much.
		* Moved StripInvalidFilenameChars from CamuleApp to StringFunctions
		  and renamed it to CleanupFilename.
		* Fixed pending file-blocks not being properly removed when
		  client-objects were destroyed, resulting in parts of files
		  that could not be downloaded until aMule had been restarted.
		* Fixed re-filtering of sources when IP-filter level had been
		  changed in the preferences.
		* Reworked CIPFilter class:
		  * Huge improvements in loading-speeds (~6x).
		  * Added support for loading zipped files.
		  * Switched to using the CRangeMap class.
		* Added CRangeMap class, which is a map with two keys, an
		  start and an end key, with a single value attached. This
		  was previously duplicated serveral places.
		* Fixed problems with deleting multiple items on serverlist.
		* Misc code-cleanups.
		* Added the ability to delete servers using the delete-key.
		* Fixed sorting by the "Transfered down" field on client-list.
		* Added ruby-script for detecting common issues.
		* More work on properly marking getter function const.
		* Reworked the CDownloadListCtrl class.
		* Added overloaded versions of CmpAny functions for strings.
		* Reduced memory usage of IP-ranges in CIPfiler by removing
		  redundant information.
		* Fixed extremly non-optimal function in CDownloadQueue which
		  was used many places. Could locate item in vector through
		  counting of iterator increments.
		* Fixed pre-shutdown message to something more closely reflecting
		  the actual events taking place.
		* Collected common "Data To Human-Readable" functions in file-set.
		* Reworked the ED2K-link classes.
		* Reworked handling of ED2K links, making behavior consistant
		  everywhere and fixing support for |serverlist| URLs.
		* Changed time-span of overhead calculations from 5s to 15s.
		* Removed redundant message displayed when files were added to a
		  a non-connected mule.
		* Added missing Add-Overhead calls for various packets.
		* Fixed a mem-leak in CFileDataIO::WriteString.
		* Fixed compilation of Proxy with wxGTK-2.4.2.
		* Changed default configure options. Now only 'amule' and 'ed2k' are
		  compiled by default, since other apps require extra dependancies.

	xmb:
		* id2ip awk script (with Jacobo221)


	Special Thanks To:

		* Translators:

		  Very, very special thanks to all of them, since they
		  translated the whole app in just _one_ week!

		  Ateo:		(US english	/ en_US)
		  Ateo:		(Spanish	/ es_ES)
		  gaspojo:	(Portuguese	/ pt_PT)
		  guest:	(German		/ de_DE)
		  GhePeU:	(Italian	/ it_IT)
		  Gusar:	(Slovenian	/ sl_SL)
		  ilbuio:	(Italian	/ it_IT)
		  KamiKazeNH:	(Brazilian	/ pt_BR)
		  nbfnw:	(Chinese	/ zh_CN)
		  Ogon:		(Polish		/ po_PO)
		  piarres:	(Basque		/ es_EU)
		  shafff:	(Russian	/ ru_RU)
		  supersnail	(Dutch		/ nl_NL)
		  thedude0001:	(German		/ de_DE)
		  toshi:	(Russian	/ ru_RU)

		* Contributors:
		  hanzo
		  markb
		  Mayfoev
		  monkeyboy
		  ObsessionAl
		  rommel
		  S0undt3ch
		  stsp
		  Vollstrecker
		  volpop

		* Bug and feature reporters:
		  alandar
		  Angel
		  BigBob
		  feralertx
		  Frankk
		  Mr Faber
		  OldFrog
		  RedDwarf
		  skolnick
		  thedude0001
		  Valery

		* eMule developers for their support, friendship, and collaboration.

		* MindForge & Freenode irc admins

		* People at #wxwidgets on freenode.

		* Everyone at:
		  #amule	irc.freenode.net
		  wiki		http://wiki.amule.org
		  forums	http://forum.amule.org
		  bugtracker	http://bugs.amule.org

		* All aMule users!!!

	Welcome our new aMule team members:
		blerfont, m2kio, skolnick, thedude0001 & thorero

---

## Version 2.0.0rc8 - The "last rc" version.
2004-12-21

	Baz:
		* Fix for server stats for users/files not being updated correctly.
		* Fix for ERROR and WARNING server messages not being shown.
		* Fixed server / transfers window splitters not being loaded/saved correctly.
		* Fixed categories on search dialog not being refreshed on category name change.

	deltaHF:
		* Show comments for shared files

	Hetfield:
		* Some fix in new Tray system and desktopMode bypass

	Jacobo221:
		* Added option to select the max and min size-type in advanced
		  searches.
		* When "Extended Parameters" in Search tab is not selected,
		  defaults are used.
		* Now "Auto-update serverlist at startup" checks if there's a
		  serverlist to avoid annoying messages at startup.
		* "Clear completed downloads" is now disabled while no
		  completed downloads are listed.
		* Context menu for download items only enables relevant
		  information now.
		* Context menu little optimization (removed an unuseful loop)
		  and Open File fix.
		* Added bitmap button wich pops-up the last status log line
		  (useful when it doesn't fit the window).
		* Merged Preview and Open File and enabled Open File.
		* New Port column in Servers tab (splitting IP column).
		* Moved "Always filter bad IPs" from Server to Security
		  in Preferences.
		* Changed "Preference" in servers tab as suggested by Sir and
		  "IP" to "Address" since that's more accurate (could be DNS).
		* Optimizations in the RLE code.
		* Based on kry's patch, also darken paused files' progress
		  bar.
		* Translations updates.
		* Fixed: Servers priority now working. (reported by Sir)
		* Fixed: Now all unset Server Priorities are set to normal.
		  (reported by plaenky)
		* Fixed: Sorting Servers by priority works now.
		* Fixed: Setting "A4AF to others" works now.
		* Fixed: Server names sorting now differences between names
		  and IPs.
		* Fixed: Last byte is now drawn in bar progress.
		* Fixed: Stop button now working after second global search
		  and another hidden bug in global searches' progress bar.
		  (reported by ecforum)

	ken_aMule:
		* Fixed ipfilter on big endian archs.
		* Fixed wxWidget's bugs that were creating serious memleaks on Mac

	Kry:
		===============::MULTIPLATFORM::===============
		* When a socket connection error like WOULD_BLOCK happens, aMule retries
		   the connection to avoid just-once errors
		* Stopped files are now darker than non-sources ones.
		* AICH e-links working now, with masterhash and with hashset
		* Proper handling of removing -fomit-frame-pointer flag that worls on all platforms.
		* Initial support for wx-compliant systray. Will be ready for 2.0.0 final release.
		* aMule no longer crashes on opening a non-existing folder. CDirIterator is safe now.
		* Fixed crash on app close - never call a pure virtual function from a destructor.
		* Moved the init/close code of aMule to where they belong: destructor/constructor.
		* Much more debug info available to debug packets (packet dump and others)
		* Major network improvements:
			* Improved the socket processing on CPU usage and performance.
			* Coded the functions handling the network string/bytes conversion of ips and
			   hostnames and the generic hostname solving thread, non dependant from host's
			   socket implementation. Less CPU and more reliable on both cases.
		* Crash fixed on wrong arguments for wxString::Format
		* New option on right click on downloading or search files for showing eserver's stats for
		   that filehash. Needs browser correctly configured on preferences.
		* Implemented messages filtering, from know clients/bogus clients/by words.
		* Fixed hashing files changing display status.
		* Fixed crash where transferwnd and clientlistctrl could be accessed before created.
		* Listen socket on accepting connection no longer uses a blocking socket (CPU improvement).
		* Not linking anymore to gtk libs if not needed.
		* "GTK: Not Detected" is now either "Not Detected" or "Not Used" to avoid confusion.
		* Fix for crashing on 'OK' button on preferences.
		* Fix for preferences window being unreachable if aMule is minimized while showing it.
		* Fix for crash on HTTP dialog if StopAnimation() was not called on destructor.
		* Fixed crash when shutdown and preferences window open.
		* Implemented OS_Info tag. Broke it 400 times, and fixed it 401 times, so working.
		* Implemented statistics tree for OS_Info tag.
		* Fixed several memory corruption issued caused by icons with wrong size.
		* Fixed several memory corruption bugs on amule init/close.
		* When aMule crashes, it not longer fails saving:
			* Preferences (Saved on 'OK')
			* Categories (Saved on changes)
			* Total upload / download bytes (saved while running).
		* Fixed crash on	OP_MULTIPACKETANSWER
		* Sent wxInt and wxUInt classes usage down the drain for the standard int / uint
		* Implemented "Share hidden files" checkbox.
		* Immplemented the CT_EMULECOMPAT_OPTIONS new tag.
		  Right now only OS info support capabilities.
		* Implemented new short tags style for server and client interchange of info.
		  Fixes not being able to browse eMule >=0.42x shared files.
		* Fixed aMule daemon compilation to use wxBase headers and libraries.
		  This fixes amuled not compiling on wxBase only-boxes, thus making it kinnda pointless.
		* Fixed AMD64 and GCC4.0 compilation/run, closes debian bug #285110
		* Fixed some performance issues on Log text controls.
		* Fixed long browsers requests on WebSocket. Buffer is now enlarged accordingly.
		* Fixed timeout on webserver socket being... 10 minutes!!!
		* Fixed several 100% cpu errors on WebSocket.
		* Fixed our source exchange implementation that was... uh... wrong.
		* Fixed stats tree on webserver.
		* Misc. work on ECv2 implementation of messages.
		* aMule can send now RGB encoded images via ECv2
		* Webserber can read ECv2 Image tags via the new CDynPngImage class.
		* eMule+ is now recognised under compatible client tag 0x05
		* Unicode fixes on webserver.
		* Got rid of almost all wxString::GetData()
		* Major CPU improvements on WebServer.cpp
		* otherfunctions.* is now clean from aMule specific stuff. Can be used anywhere.
		* otherfunctions now have a namespace (surprinsigly named 'otherfunctions')
		* Changed wxFileStreamInput -> wxFile (less class overhead).
		* Several speed fixes on Stats code.
		* Fixed possible crash on search thread creation + verbose on error.
		* Fixed aMule crashing when local search is not returning and we click stop
		  or start another search.
		* Fixed severeral endianess bugs.
		* General rewrite of UDP Socket
			* Received packets when app is not ready are now discarded.
			* Small fix preventing memleaks and some strange asserts
			* Fixed a severe memleak if 2 UDP packets are send at the same time, before the
			   first one finishes.
			* Fixed the host solving fail not cleaning the data (another severe memleak)
			* Fixed sending wrong data to wrong servers and thus not being replied.
			* Fixed some server udp packets never reaching destination.
		* Unicode fixes (char*/wxString issues)
		* General cleaning, bugfixing and documenting.
		* Added files:
			StringFunctions.(h/cpp)
			NetworkFunctions.(h/cpp)

		==================::MAC::===================
		* Fixed server connection crashes related to accepting a connection from a being
		   destroyed socket. Probably fixes also some random BSD/Linux crashes on conection.
		* Got rid of all <wx/wx.h> includes, improved compilation speed greatly.
		* Fixed stats color boxes
		* Fixed servers saving, not anymore stored wrong internaly.
		* Coded Mac packager script for releases with included libcurl and wxWidgets.
		* Included Mac aMule.app bundle on sources.
		* Fixed sharing /Volumes and other special folders.
		* Fixed crash on server.met download

	permats:
		* FIXED: Preferences -> Security -> Permissions wasn't being
		  correctly saved for directories.

	Phoenix:
		* Lots of unicode fixes.
		* Added readline and history support to amuleweb/amulecmd text
		  clients.
		* Added template loading capability to amuleweb with the new
		  command line parameter -t.
		* Changed m4/readline.m4 so that readline libs are only used
		  when needed, i.e., no longer append readline libs to LIBS,
		  use READLINE_LIBS instead.
		* Fixed crash in aMule when amuleweb tried to get transfers
		  tab and aMule had never connected to a server before.
		* New backtrace output with demangled function names, file
		  names and line numbers, when possible.
		* Initial (not functional yet) SOCKS5 proxy support.
		* Initial (not functional yet) SOCKS4 proxy support.
		* Initial (not functional yet) HTTP proxy support.
		* Updated some tests in configure.in.
		* Fixed a problem with _() usage. Static string initialization
		  must be done with wxTRANSLATE, and wxGetTranslation() must
		  be explicitly called in code instead of _().
		* Fixed a bug in WebServer.cpp:CWebServer::GetStatusBox():
		  return value was missing end tags.
		* Changed back to macro the inline function version of
		  unicode2char() when using UNICODE. Unfortunately, when the
		  fucntion returns, the string object gets out of scope, so we
		  stick to the macro version for now.

	lfroen:
		* Moving amuleweb to EC version 2.0
		* Fixes on amuleweb socket code
		* Added generated png images to amuleweb
		* Added RLE encoder for gap and parts status to EC
		* Fixes in amule daemon

	Madcat:
		* Added support for detecting HydraNode clients.

	GonoszTopi:
		* Initial work on EC protocol version 2.0.
		* Fixed a crash on broken language files (.po)
		* Some GUI cosmetics.
		* Lots of i18n fixes.
		* As a side effect, fixed the "Any" search in webserver.
		* Fixed webserver connection with empty passwords. :)
		* Fixed webserver connection with guest account.
		* Added "add <ed2k link>" command to amulecmd.
		* Tracked down and killed a number of hidden bugs.
		* Added commands to change/monitor bandwidth settings to
		  amulecmd.
		* Made wxTRANSLATE actually work.
		* Fixed graphs in webserver. Also added the missing back.gif file.
		* Fixed buffer overflow problem in ed2k link handler.
		* Stats bug fixed.

	wizeman:
		* Helped finding the code snippet where WebSocket was failing on request.
		* Fixed 'Safe Max connections' code. It's safer to use it now, and it works.
		* Fixed bug where amule would start consuming 100% cpu when it received a
		  corrupted EC packet.
		* Fixed webserver, it wouldn't close connection when it received a POST request.
		* Fixed webserver crash: added mutex to make variable wcThreads thread-safe.
		* Fixed webserver <-> amule communication corruption when the webserver
		  received simultaneous requests. The problem was that all webserver threads
		  were using the same socket for sending/receiving EC packets to/from amule
		  without synchronization.

	Xaignar:
		* Added the new casting macros to otherfunctions.
		* Added a helper-function to CMuleListCtrl for use in the Sorter functions.
		* Fixed the priority-column on Server List.
		* Added the handling of friends to ECv2 implementation.
		* Merged CUploadListCtrl and CQueueListCtrl on CClientListCtrl.
		* Added the posibility to see a list of all existing clients.
		* Fixed aMule dialog not always being unfrozen upon restoring it from tray.
		* Some changes to the overhead calculation functions.
		* Slight improvement of the GetScore function CPU usage.
		* Replaced "theApp.glob_prefs->" with the new usage "thePrefs::"
		* Fixed the MyTimer class behind GetTickCount returning random values on close.
		* Fixed two crashes on ClientList.
		* Fixed compilation for solaris on several places.
		* Make sure that clients cant just crash us by sending a aich-request for an invalid hash.
		* Fixed a couple of sub-menues.
		* Removed the leech-mod checks, they were getted outdated anyway
		* Fixed open sockets count.
		* Avoid re-layouting the entire dlg when updating some labels.
		* Small fix to CMuleNoteBook.
		* Adding a missing event-handler en shared files tab.
		* Changed the primary hashing thread to do both MD4 and AICH hashing for non-part files.
		  This cut down hashing of ~2.8gb of data from ~12:40 minutes to ~7 minutes on tests.
		* Adding checks against the user sharing the following dirs: Home-dir, .aMule, Temp-dir.
		  Sharing home is allowed but results in a warning.
		* Fixed the Upload-parts drawing.
		* Fixed sorting by filename on the Uploading list.
		* Fixed crash on server list auto-update. Removes the possibility of overrunning a array.
		* Optimization of UpdatePartsInfo, which now no longer needs to traverse the parts-info
		  arrays of each source for that file.
		* Fixed the redraw problems where some things wouldn't be erased on list controls.
		* Code cleaning, documenting and rewrite.

	Special Thanks To:

		* Translators:
		  Ateo:             (US english / en_US)
		  biger [HUN]:      (Hungarian  / hu_HU)
		  experience.chris: (German     / de_DE)
		  GhePeU:	    (Italian    / it_IT)
		  Gusar:	    (Slovenian  / sl_SL)
		  ilbuio:	    (Italian    / it_IT)
		  KamiKazeNH:	    (Brazilian  / pt_BR)
		  mad_soft:	    (Spanish    / es_ES)
		  nbfnw:	    (Chinese    / zh_CH)
		  Ogon:		    (Polish     / pl_PL)
		  piarres:	    (Basque     / es_EU)
		  pukyxd:	    (Catalan    / es_CA)
		  Supersnail	    (Dutch      / nl_NL)
		  Typhon:	    (Slovenian  / sl_SL)

		* Contributors:
		  alehack,	alus,
		  boutros,	fossybaer,
		  Frankk,	han,
		  junaru,	sebaX,
		  skolnick,	sLiCeR\,
		  Vollstrecker,	volpop,
		  {xmb}

		* Bug and feature reporters:
		  Banerjee,	chisky2003,
		  Danny,	ecforum,
		  fctk,		Gnucco,
		  hades,	jaguarwan,
		  jolupa,	juanii,
		  kdka,		kno,
		  m2kio,	MichaelLong,
		  Pableron,	pi-c,
		  plaenky,	realcruncher,
		  Sir,		Sniffer,
		  sosonok,	|Syrius|,
		  xplode_me

		* Everyone at:
		  #amule	irc.freenode.net
		  wiki		http://wiki.amule.org
		  forums	http://forum.amule.org
		  bugtracker	http://bugs.amule.org

		* All aMule users!!!

	Welcome our new aMule team members:
		lionel77, ken_aMule, nachbarnebenan & one2one


---


## Version 2.0.0rc7 - The "99,6% Final" version.
2004-10-19

	bisley:
		* Added session ratio and total ratio to XAS

	deltaHF:
	        * Got back from hell and changed one icon on the GUI ;)

	Jacobo221:
		aMule GUI:
		* Fixed two almost-the-same bugs when clicked download button
		  and no items where selected (as reported by powtrix/willy,
		  thanks).

		aMuleWeb:
		* Fixed a bug where up/down limits woudln't be displayed
		  correctly if their string length were different.

		aMuleCMD:
		* Added 'list' (or 'find') command to search for a file in
		  the downloads queue by name or by number (or just show all).
		* Added the ability to resume/pause all downloads at the same
		  time through amulecmd (very handy when all downloads have
		  been paused due to lack of space).
		* Fixed two bugs on amulecmd by which using 'pause' or 'resume'
		  without arguments would pause/resume the oldest download.
		* Fixed a bug so that help command no longer is send to core.
		* Fixed other commands sending blank data to core.
		* Cleaned unneeded output log messages + added sent command
		  messages to log (for easier security monitoring).
		* Several command simplifications on amulecmd to make it easier
		  to use (while maintaining backwards compatibility).
		* Lots of translations lacks

	KingFish:
		* Fixed broken compilation in SysTray.cpp with gcc 3.3.4.

	Kry:
		* Fixed:	Crashes related to animation deletion on http download dialog
		* Fixed:	0-size server.met file crashing aMule on startup and on download.
		* Fixed:	GUI blocking on server connection.
		* Fixed:	The last (hopefully) "fixed minsize" bug. FileDetail dialog was growing :)
		* Misc code cleaning.
		* Mac:
			* Enabling wxCocoa compilation
			* Fixed:	Secure Ident was not working on big endian archs.
			* Fixed:	ClientID endianess issues leading to faking low/high id
			* Fixed:	Several fields were not having correct size on preferences.
			* Fixed:	Curl preform_multi was crashing the http download dialog on Mac.
					This means server.met update and ipfilter update was crashing.
					Currently the fix disables 'Cancel' button on that dialog, while we
					wait for curl lib to fix this issue.

	lfroen:
	        * Removed debug printf's in timer.cpp.
		* Fix for deadlock on connection timeout in ServerSocket.cpp.
		* Fixed assert when build with wx-cvs.
		* Added option for disabling SIGSEG handling: useful for
		  debuging in amuled.cpp.
		* EMSocket.h cleanup.
		* Fixed unclosed sockets (CLOSE_WAIT) and few stability
		  problems.
		* Make CEMSocket::OnReceive thread safe. MAX_SIZE reduced,
		  cause even theoretically tcp can buffer up to 64K.
		* amuled fixes.

	mfs:
		* Fixed crashes on friendlist when keeping keys pressed
		* Fixed one server not being removed when several servers selected
		* Fixed access problems on deleting the ipfilter while accessing it

	Phoenix:
		* Fixed '&' char next to Preferences in amuleweb web page, as
		  reported by DreamWalker.
		* ExternalConn: protected GETCATTITLE command from buffer
		  overflow.
		* Start removing unused code from ExternalConn.cpp.
		* Fixed high CPU usage problem in amuleweb, thanks to jaguarwan for
		  the report. Daemonizing amuleweb should be done using the -q
		  switch.

	ThePolish:
		* Implemented new hits system in wxCas to display and save download rate records.
		* Changed wxCas layout to try to avoid display bug with wx-cvs
		* Added translations update (Thanks to all translators)
		* Removed wxCas documentation to slim source tree (now downloadable from berlios)

	Seagull:
		* Patch adding "Directory" column to the shared-files dialog.
		* Patch to add "Swap to this file" option for sources marked as
		  "Asked For Another File" on download queue.

	Unleashed:
		* Better fix for amuleweb's high CPU usage problem. Now main thread only gets
		  woken up when absolutely needed.

	Xaignar:
		* Reinsured that the preferences will be saved upon clicking "Ok".
		* Removed SSE2 specific optimizations from the embedded Crypto++ sources,
		  they would break very easily and crash aMule.
		* Fixed a bug where we would sometimes attempt to remove a client
		  from the wrong file, resulting in dangling pointers and crashes.
		* Ensured that the statistics-dialog would be updated when preferences
		  relating to it where changed.
		* Added sanity checks to category-loading, to avoid adding categories
		  without incomming dir or name.
		* Initial fix for crashes if aMule tried to share an inaccessible folder.
		* The redraw problems on restoring from minimized state should be fixed.
		* Fixed the shared-files list, which would draw columns regardless
		  of whenever or not they were hidden.
		* Fixed the progress-bars in the shared-files dialog. It should now
		  work properly for both part and completed files.
		* Fixed a bug in the ipfilter, where non-numeric chars on lines would
		  cause wrong ranges of IPs to be filtered.
		* Re-added the priority menu for servers, which had gone missing due
		  to a mistake.
		* Stopped the client-credits class from attempting to load older
		  versions of the lists, which again would lead to mem-corruption.
		* Fixed hidden columns on download queue, which would still be drawn.
		* Added sanity checks to loading of clients.met file, since corrupted
		  files would lead to potentially huge ammounts of mem-corruption.
		* Added "Completed Sources" column to the shared-files dialog.
		* Fixed a bug in sockets where disconnected sockets wouldn't be removed
		  immediatly, but left to timeout instead.
		* Fixed an end-less loop on the AICH thread if a file on the queue
		  was removed from the list of shared files.
		* Fixed an end-less loop when changing file-status by category.
		* Fixed the auto-priority menu-item on the download list when multiple items
		  where selected. It would un-set auto-priotity instead.
		* A bit of optimization in CPartFile. More work will follow later.
		* Properly initialized a number of variables.
		* Fixed the column-width saving/loading which I managed to break shortly before
		  rc6 was release. Whoops. :p
		* Ampersands will no longer be doubled when lines are added to the log-view.

	Special Thanks To:

		* Translators in this release:
		   biger [HUN]:		(Hungarian / hu_HU)
		   GhePeU:		(Italian / it_IT)
		   mad_soft:		(Spanish / es_ES)
		   Ogon:		(Polish / pl_PL)
		   piarres:		(Basque / es_EU)
		   powtrix/willy:	(Brazilian / pt_BR)
		   punkyxd:		(Catalan / es_CA)
		   stefanero:           (German / de_DE)
		   Supersnail:		(Dutch / nl_NL)

		* Testers and bug reporters:
		   angel,	BiByFoK,
		   bill_bool,	boutros,
		   elui,	Gaenya,
		   jolupa,	ken_aMule,
		   mad_soft,	Mig21,
		   one2one,	powtrix,
		   RedDwarf,	skolnick,
		   wi777

		* Everyone at:
		   #amule	irc.freenode.net
		   wiki		http://wiki.amule.org
		   forums	http://forum.amule.org
		   bugtracker	http://abugs.amule.org

		* All aMule users!!!


---


## Version 2.0.0rc6 - The "We're so EVIL that we make you lose a sock in every pair" version.
2004-10-03

	deltaHF:
		* GUI for MyInfo at Server window.
		* Added 'About' button.
		* Fixed sorting upload list by speed
		* Changed the Search dialog.
		* Fixes websearch for jugle.net
		* Added hability for send msg to clients in upload queue, without having to add
		  them as friends (based on Kry's download queue send-on-right-click implementation)
		* Translations update.

	falso:
		* New upstream cas version. Now supports creating html pages with the statistics
		* Now cas runs on netbsd.
		* Misc fixes on cas.

	GonoszTopi:
		* Patch to fix buffer overflow in cas when line had more than
		  80 chars.
		* Patch to fix help switch in ExternalConnector.cpp
		* Patch to create -c switch in amulecmd: now the command line
		  version can connect, execute a command and exit.

	Hetfield:
		* Lots of 3.4.x compilation fixes, due to -DWX_PRECOMP
		  and wx headers checks.
		* Configure cleanup, safetray remove and nice cosmetics for tools
		* Configure option added: --enable-embedded_crypto to use amule crypto code
		and bypass crypto libs. Also fix freeze problem.
		* fixed crypto usage in core with configure and compilation flags
		* Re-enable Pentium4 and SSE2 optimizations fro Crypto stuff

	Jacobo221:
		* Fixed issue on the About button.

	Kry:
		* Got back from hell.
		* Imported eMule's 0.44x new corruption handling: AICH
		   AICH stands for Advanced Inteligent Corruption Handling, and avoid having to
		   re-download a full part everytime we get corruption on a file. With AICH, you will
		   just re-download the 184Kb block that has corruption. It uses HashTrees to achieve
		   the corruption diagnosis.
		   More info: http://www.emule-project.net/home/perl/help.cgi?l=1&rm=show_topic&topic_id=589
		   *********************************************************************************
		   WARNING: AICH thread will re-hash all your files on your first rc6 startup. This can
		   take very long when the user has lots of shared files. We're sorry but that's the only
		   way to build the HashTree and thus making AICH able to work.
		   *********************************************************************************
		* Fixed the AICH implementation to support big endian archs (like ppc).
		* Implemented IPfilter auto-load on startup
		* Implemented IPFilter 'Update Now' button on preferences.
		* Revamped the HTTP download dialog, used to download IPfilter and server.met
		   (and probably other files in a near future) Now it's the thread who runs the dialog,
		   and dialog no longer block aMule while loading. It also has a progress bar. Yay!
		* Fixed amule daemon not allowing auto-dowload of server.met.
		* First rework of the Search dialog, later re-worked by Xaignar using the
		  hide/show engine I did.
		* Implemented "Send messages" via right-click on source.
		* When aMule is running and you try to run a second aMule, it now send a
		   'raise' message to the current runing one. This is designed to fix the problems
		   with aMule being in a inexistant systray and thus people being unable to recover it.
		* Fixed documentation:
			* Bugs on  kb/kB mistakes
			* Added "What are all those fancy colors in the download progress bar about?"
		* --version switch now returns 0 (sucessfull app termination)
		* MOD_VERSION_LONG does no longer show 2.0.0 version on CVS
		* Cleaned the GUI for LOTS of unnecessary wxSizers that were looking ugly on Mac
		   and making wxDesigner project file much cleaner.
		* Fixed memleaks on curl usage (thanks Seagull)
		* Systray is now skinnable
		* Safety checks: A File can't have more than 441 partcount
		* Added a file-access tracker that allowed us to fix lot of file access bugs:
			* We were closing invalid file descriptors!
			* Random Error responese from CFile class, again
			* Misc multiple bugs that made me kinnda rewrite the class
		* Fixed user not being notified of duplicated files on shareds
		* Safe load for clients.met (no more removing to load amule)
		* Fixed PrefsUnifiedDlg using wrong events for Spin controls.
		* Search textbox now accepts enter key (did it work before? or never worked?)
		* aMule now compiles and works with wxWidgets 2.5.2, with no gui bugs
		* Fixed a nasty cvs bug that was just taking '0' on upload settings as 0, not unlimited.
		* Fixed CArray implementation to avoid ints and make usage of size_t and off_t
		* Added GetConnectIP() implementation to BaseClient so we can hold the supposed IP
		   or (after we had a connection) the real IP
		* Implemented extra-file_corruption_safety on files. No more 'please rm -rf .aMule/'
		* Implemented safe recover of .part.met files.
		   This means that if a .part.met file gets corrupted, aMule will take care of it and try
		   to recover it with minimal info. As a matter of fact, only filesize and hash is need,
		   so any other info will be recovered or set to default instead of discarding the part file.
		* Fixed mem corruption on BaseClient
		* Fixed a crash on UploadListCtrl due to access to a either uninitialised or removed client.
		* Fixed the annoying empty message being sent every time a client connects to us while
		  we have a chatwindow with him. this was really pissing people off ;)
		* Reworked SafeFile.cpp and made it compatible with eMule 0.44x.
		* aMule defaults to maximize if not size not overriden and no gui size stored (robably first run)
		* Implemented CDirIterator.
		   Used to get rid of wxFindFirstFile and such buggy functions (breaking filenames on Mac and others).
		* Added GUI preferences fo AICH's hash trusting and IPfilter new options.
		* Corrected xMule version show. xMule started sending correct version tags on 1.9.1b, only 4
		   months after I told them, and only 1 after eMule+ developers did. Is based on our implementation
		   (x.y.z instead of eMule's x.ya), so it was not hard to show them correctly ;)
		* Misc developing, memleak fixing, code rewrite, and co-workers abuse by insulting
		   them and degrading them to worm state.

		* Kademlia Import:
			kademlia/utils
			* UInt128.cpp (class for handling 128-bits integers, added hability to read/write on SafeFile).
			* UInt128.h
			* All other files on the kademlia/utils are not needed by aMule.
			kademlia/kademlia/
			* Defines.h
			* Entries.h
			* Error.h
			* Tag.h
			kademlia/routing/
			* Map.h

		* Mac:
			* Fixed compilation near every day :)
			* Fixed the file descriptor problems, using the new file access tracker.
			* Fixed the clients.met file being saved badly and thus breaking load.
			* Fixed Search page not setting the SearchType to default.
			* Fixed the start, clear and clear all buttons on Search page
			* Fixed wrong usage (at least on Mac) of multi line control functions on single line text control
			* Fixed sharing dirs giving access errors (and probably on other archs than Mac).
			* Fixed amule daemon for taking 100% (or 198% on a dual system) CPU.
			* Fixed wrong filenames being shown when more than 24 chars. See CDirIterator above.
			* Fixed 'MyInfo' tab showing wrong endianess on IP.

		* Deleted files:
			eMule-Import-Status	-> Very old unused file.
			RC1-KnownBugs	-> Very old unused file.
			HTTPDownloadDlg.*	-> HTTPDownload.* (no longer a GUI file)


	lfroen:
		* Core/GUI separation:
			* Moved all GUI code out of Core files.
			* Made a new socket engine to be able to use wxSocket on wxBase, even when
			   wxBase has no event pool.
			* aMule daemon is now functional,  but it still need hard testing.
			   Enable it using --enable-amule-daemon.
			   You can control it via any EC app (amulecmd, amuleweb)
			* aMule separated GUI does not compile right now, and the communication
			   with the core will be improved as EC is rewritten by GonoszTopi.
		* Fixed crash on DownloadClient
		* Misc aMule fixes here and there :)

	Littletux:
		* Patch to include UTF-8 support in systray.
		* Patch to fix configure.in UTF-8 SysTray code.

	Phoenix:
		* Fixed a compilation warning + appartently useless code in
		  DirectoryTree.cpp.
		* Fixed amuleIPV4Address for wx-2.5.2 and up.
		* Fixed the low number of sources problem with wx-2.5.2 and
		  up. Problem was in CUDPSocket::SendBuffer, now there is a
		  macro to test. aMule should be 2.5.2 network ready now.
		* wxCHECK_VERSION(2,5,0) no longer necessary in
		  amule{web,cmd} for wxApp because we have now -DwxUSE_GUI=0.
		* New command line parameter in amulecmd: -pw or --password.
		* New commands in amulecmd: serverconnect, reloadipf and
		  setipfilter. Thanks rommel for the initial patch.
		* Fixed amulecmd command parser. Help was not coherent and
		  giving syntar errors.
		* Rewrote command parser/processor im amulecmd to use
		  wxStrings.
		* Some i18n stuff in amulecmd.
		* Rewrote amulecmd and amuleweb, creating a new module,
		  ExternalConnector.cpp. This module has a lot of code
		  common to both programs, and will make it easier to
		  maintain.
		* Fixed a small wxString bug in CamuleDlg::AddLogLine()
		  in amuleDlg.cpp.
		* Improoved wxSting usage in ExternalConn.cpp.
		* Yielding in DownloadQueue.cpp Init() so that gui is not
		  blank when loading lots of files.
		* A little better font/color handling in amulewebDLG and
		  amulecmdDLG.
		* New command line parameter for amuleweb, amulewebDLG,
		  amulecmd and amulecmdDLG: -f. This parameter reads the
		  ECPpassword and the ECPort from the [ExternalConnect]
		  section of file ~/.eMule. This way, the plain text password
		  doesn't have to be passed in the command line.
		* Updated socket-2.5.c to the latest wx-cvs code.
		  Fast reconnect -> lowid bug is fixed in wx-cvs now. When
		  wx-2.5.3 is out, we will finally be able to drop this file.
		  It will only be needed for versions 2.5.0(?) to 2.5.2.
		* Removed gsocket-2.5.h from the project. This file was not
		  beeing used anymore.
		* Added command line parameter "-q" or "--quiet" to
		  amuleweb(Dlg) and amulecmd(Dlg). This is to run amuleweb
		  without any output to stdout, so that it does not need a
		  terminal.
		* Changed amulewebDLG and amulecmdDLG to use sizers.
		* Removed a bug in WebSocket.cpp: was not testing the return
		  value of Accept, this could create a thread with a NULL socket.
		* Added two new commands to amulecmd(DLG), GetIPLevel and
		  SetIPLevel <new level>.
		* Rewrote most of the wxString usage of amule web server in
		  ExternalConn.cpp. There should be some speed improovement.
		* Removed pop up when web server requested ed2k source link
		  and amule was low id.
		* Fixed a problem with Server Connect command in amulecmd, it
		  was not working. It has been renamed to ConnectTo. Also
		  fixed help command output, should look better now.
		* Added "-fmessage-length=0 -W" flags when --enable-debug.
		* Changed m4/wxwin.m4 to recognize wx-config --libs base (no
		  equal sign from 2.5.3 and up).
		* Unicode fix in SysTray and new compiler wanings fix due to
		  new compiler debug option -W.
		* Some more consts in code due to CDownloadQueue::GetFileByIndex()
		  and CSharedFileList::GetFileByIndex(). Also cleaned those
		  functions.
		* Fixed Resume/Pause bug in amulecmd/amule. Now Resume/Pause
		  argument starts at zero.
		* More gsocket.h update.
		* Debug protocol options. Comment/Uncomment:
		    #define DEBUG_LOCAL_CLIENT_PROTOCOL in BaseClient.cpp
		    #define DEBUG_REMOTE_CLIENT_PROTOCOL in ListenSocket.cpp
		    #define DEBUG_SERVER_PROTOCOL in ServerSocket.cpp
		    #define DEBUG_CLIENT_PROTOCOL in sockets.cpp
		* Changed configure.in to no longer use gsocket-2.5.c for
		  wx-2.5.3 and up.
		* Fixed the Random Lowid Bug.
		* Cleaner solution to RLB: Accept() the connection and
		  Destroy() the socket immediately.
		* Fixed a lot of bugs in amuleweb. In particular, stop / pause
		  / cancel / priority(up/down) now works.
		* Removed bubble sort code in download queue from amuleweb.
		  This code did not scale for large number of files, like
		  hundreds. There is still room for improovement here.
		* Fixed a bug in SafeFile.cpp. wxString.Length() returns the
		  number of codes in the string, which is less than or equal
		  to the number of bytes in a multibyte encoded string. This way,
		  amule will also not crash with locale search strings like korean,
		  japanese and chinese.
		* Several amuleweb/ExternalConn bug fixes. Now the
		  communication is in UTF8, so that soon amuleweb non-unicode can
		  communicate with amule unicode and vice-versa. There was a
		  bug when the number of files was more than approximately 90
		  because the communication routines could not handle strings
		  greater than 64K chars. There is still some replicated code
		  in ExternalConn.cpp, but the idea is that it will use the
		  code in ECSocket.cpp.
		* Bug fix in ExternalConn.cpp. ECSocket must have the
		  wxSOCKET_WAITALL flag to work properly when the message has
		  more than 64Kbytes. aMule now uses ECSocket.cpp, no more
		  replicated code in ExternalConn.cpp.
		* Fixed a bug in ListenSocket.cpp, m_client can be null after
		  ProcessSecIdentStatePacket(), so, we must check.
		* Fixed conversion problems in ECSocket.cpp. Now external
		  connections in UTF-8 are really working, and
		  amuleweb/amulecmd (unicoded or not) can connect to amule
		  (unicoded or not).
		* Fixed an unprotected call to strlen() in ECSockets.cpp, if
		  you pass a NULL pointer to it, the program segfaults.
		* Added a timer for idle repainting in amulewebDLG and
		  amulecmdDLG.
		* Fixed this assertion in Preferences.cpp: [Debug] 07:02:00 AM:
		  include/wx/longlong.h(155): assert "(m_ll >= LONG_MIN) &&
		  (m_ll <= LONG_MAX)" failed: wxLongLong to long conversion
		  loss of precision.
		* Reimplemented "Show Rates On Title" preference.
		* Initial import of new MD4 hash code from emule 0.44a into
		  KnownFile.{cpp,h}.
		* Removed amuleweb html template 12 char password limitation.
		* Small fixes to UTF-8 SysTray support patch.
		* Several unicode fixes.
		* New macro in otherfunctions.h: unicode2charbuf(x) -- used
		  when you need to store a (char *) to use several times.

	Rommel:
		* Patch to implement the commands serverconnect and reloadipf
		  in amulecmd.

	ThePolish:
		* i18n amule log lines (server window)
		* amulecmd and webinterface i18n fixes
		* Some win32 fixes (slashes and backslashes)
		* Automake 1.8 fixes
		* Add traditionnal Chinese translation (zh_TW) from Paul (Thanks !)
		* Add it, nl, fr, pl, es, eu, ca translation updates (Thanks to
		  all translators)
		* Fix copyright for alc icons
		* Replace amule, wxCas, alc .ico simple icons by icons group .ico
		* Replace alcc's printf by wxLogMassage
		* Make runtime to be in seconds in amulesig.dat
		* Modify Xas to handle runtime in seconds
		* Modify wxCas to handle runtime in seconds

	Unleashed:
		* cas: some sprintf -> snprintf conversions, ifdef unix specific
		  code, and revert get_path() breakage

	Xaignar:
		* Other stuff I'm too lazy to write or have forgotten about. ;)
		* Initial multi-sorting on download list. Upon changing sort-column,
		  any items that were evaulated to equal will be resorted by the
		  last used column.
		* Fixed the constant resetting of the category dropdown-menu in
		  the searchdlg.
		* Fixed "&"s being replaced with "&&" on the log-view.
		* Only displayed category color when the items arn't highlighted
		  on the download list, to improve readability. (thanks to Seagull)
		* Optimized the IPFilter-code.
		* Improved the CDownloadListCtrl::Updateitem function so that it
		  doesn't search the list for hidden items.
		* Improved sorting of clients by QR on the download list.
		* Removed a number of unsued files, cutting down archive-size
		  by around 900kb.
		* Changed systray behavior to match KDE/GNOME. Single-clicks hide/show.
		* Fixed the "Last Recieved" column, which would show the
		  same as the "Last Seen Completed" column.
		* Fixed the placement of sources on the download list, where they
		  would sometimes be placed with the wrong file.
		* Cleanup of the new AICHSyncThread class.
		* Removed extra newlines before writing text to the logfile,
		  to avoid having a double-spaced file.
		* Fixed loading of addresses.dat, where the first line would
		  be ignored and replaced the messagebox with a log-line.
		* Fix the percentage displayed on the progress-bars being rounded,
		  which would result in non-completed files showing 100%.
		* Added the ability for the user to specify permission settings for
		  fildes and directories. These settings default to 640 for files and
		  750 for directories and are used throughout the app, with the
		  exception of files created with wxTextFile, as that class lacks
		  support for permissions. Will be fixed later
		* Cleanup of CServerListCtrl:
		  - The sorting of the list is now always maintained, including when items
		    on the list are updated or new items updated.
		  - Cleanup of the popup-menu.
		  - Disallow connecting to multiple servers at the same time.
		  - Other changes.
		* Reduced the overhead of the overhead calculation by using
		  code that didn't require iterating through a list every time.
		* Added checks to avoid the user getting spammed with the "Connected
		  to user" and "Disconnected ..." when having an open chat-window.
		* Second reworking of the SearchDlg
		  - The crash on searching should be fixed now.
		  - Initial cleanups of the SearchList class
		* Cleanup of the SearchListCtrl class
		  - Results will now always be sorted
		  - Syncronized all lists during runtime, so that they behave
		    as a single list.
		  - Improving the coloring of items.
		* Cleanup of the CMuleNotebook class
		* Cleanup of the CMuleListCtrl class:
		  - Added double-arrow for alternate sorting.
		  - Centralized a lot of logical plus lots of other changes
		* Double-buffered all listctrls using custom drawing, to reduce flicker.
		* Added warning if the user recieves LowID from the server.
		* Disallowing the user to send empty messages in the chat window.
		* Rewrote the PrefsUnifiedDlg class
		  - Removed the Rse classes and create a more clean replacement.
		  - Made the dialog mode-less.
		  - Removed the un-implemented Notify page
		  - Serveral other changes.
		* Updated the version reporting capabilities of aMule, so that it
		  will report version, wxWidgets type and version and if unicode
		  has been enabled or not.
		* Added the new MuleTextCtrl class which supports the traditional
		  popup-menu with Cut/Copy/Past/Clear and Select All. All existing
		  wxTextCtrls were replaced with this new class.
		* Imported the parts of Crypto++ that aMule needs into two files
		  with permission from the Crypto++ developer. This means that aMule
		  now compiles without the user having Crypto++ installed, though it
		  is still possible to use external Crypto++ installations if the user
		  wishes to do so.
		* Fixed some compilation problems with aLinkCreator and wx-2.5.2.
		* Fixed the First-Time-Message being displayed twice and rewrote it
		  somewhat since it was becomming quite outdated.
		* Fixed the "unable to open preferences.dat" bugs.
		* Fixed the ability to add static servers.
		* Cleanup of column sorting functions.
		* Fixed a bug where CServer::HasDynIP would always return true.
		  This would result in need-less dns lookups.
		* Removed a redundant attempt at adding servers from connected
		  clients.
		* Fix for Packet::PackPackets function where new size of packet
		  wouldn't be saved.
		* Fixed some access to the dialog-window ptr after it had been
		  deleted. This was causing some odd behavior once in a while
		  on termination.
		* Fixed the downloadqueue sorting, which was reversed. Low-priorty
		  files having high priority and high-priority files having low
		  priority. (Thanks to thomas001 for noticing)
		* Rewroked the systray:
		  - Fixed the the problems with the rate-limiting functionality.
		  - Enabled use of PublicIP requests, so that the tray will show
		    the users actual IP rather than the interface IP.
		  - Some changes of the menu-structure.
		* Complete reworking of the hashing thread:
		  - More informative output
		  - Much better error handling
		  - Handles duplicate files gracefully
		  - Reads only 128kb (instead of 9mb) at a time to avoid killing
		    the harddisk entirely while the thread is running.
		  - Made the thread terminate when no files are left, instead
		    of timing out as before.
		* Disconnected otherfunctions.h from the rest of the aMule code,
		  so that it should be possible to use it in external apps.
		* Added checks when using the client-pointer in the socket-code,
		  since that suffered from the same problem as the previously
		  fixed clients (they have a habbit of dying at random).
		* Added function for truncanating displayed filenames, which is now
		  used in file-details dialog, to avoid it getting resized to
		  extreme widths.
		* Some work on readying the Info tab on servers, deltaHF_ did the
		  rest of the work.
		* Small re-fix for the "mis-matching hash"-bug fix
		* Reworked the SearchDlg once
		  - Added Jugle.net websearch
		  - Added results-count to the result tabs
		  - Other smaller changes
		* Fixed mem-leak where certian client-objects wouldn't be deleted.
		  Specifically those that were removed from the download queue but
		  wern't on the upload queue and didn't have a active socket.
		* Removed debugging functionality no longer needed.
		* Removed variable-arguments logging functions, since they were
		  only needed in a very few places and posed a potential risk
		  everywhere else.
		* Fixed StripInvalidFilenameChars function to avoid legit letters
		  being dropped (thanks to likesylph).
		* Changed all file-accessing to use CFile rather than a mix of CFile,
		  wxFile and FILE.

		* Removed a number of warnings.
		* Cleanups of the following files
		  - AICHSyncThread.*
		  - ServerListCtrl.*
		  - SearchListCtrl.*
		  - MuleNotebook.*
		  - MuleListCtrl.*
		  - PrefsUnifiedDlg.*
		  - SysTray.*
		  - AddFileThread.*
		  - SearchDlg.*
		  - CMemFile.h and filemem.cpp
		  - SafeFiles.*
		  - CFile.*


	Special Thanks To:
		* Lucasvr, for providing fixes for compilation with some wx versions.
		* Seagull, for providing fixes and suggestions.
		* likesylph, for providing a fix for the StripInvalidFilenameChars function.
		* All translators
		* All testers
		* BrianHV and the people at #wxwidgets for their help and support
		* EVERYONE at #amule (even codewarrior2!)
		* All the people in aMule's forum
		* All the users, for having the patience to wait the delayed rc6 release.
		* Hellimod, one_2_one, ASTIOBOY, sssnake, lami123, Ocimin, agav,  PowerMike
		   and all the mac testers and people providing Macs for ssh & vnc.

	Funny stuff about this changelog:
		* You can notice that the Search dialog was rewritten 3 (THREE!) times
		   between rc5 and rc6. You only get to see the final version (Xaignar's),
		   but the initial one was Kry's (when the extended buttons show/hide
		   were added) and then deltaHF changed it later.
		   We just love changing that page.

---

## Version 2.0.0rc5 - The 'Let's recover our release speed' version.
2004-07-18

	deltaHF:
	        * Better sorting of some columns

	Kry:
		* Some gui design and coding of the upcoming Kad window
		* Protocol update:
			* UDP protocol upgraded to eMule 0.43b
			* TCP Standard Base protocol upgraded to eMule 0.43b
			* TCP Extended Base protocol upgraded to eMule 0.43b
		* Fixed memory corruption and crashes on 'cas'
		* Fixed gsocket-2.5.c for big endian archs.
		* Fixed CFile class to actually return error when a error ocurred and not only when it feels like.
		* Fixed bug where the 'All' category could be removed leading to crashes and other funny behaviours.
		* No more minimize when no tray has been selected.
		* Fixed browse skin file button to actually browse a file ;)
		* Fixed high 32 bits of transfered bytes not being loaded on known.met (sorry fluffly!)
		* Some Mac bugfixes.

	Hetfield:
		* Some gcc 3.4.x compilation fixes

	lfroen:
		* GUIEvents updated
		* core2gui events added.
		* Some gcc 3.4 fixes to GUIEvents

	Phoenix:
		* Added a test with a warning to
		  CSearchDlg::OnBnClickedSdownload in SearchDlg.cpp. A NULL
		  value has been reported on the foruns, we don't know how
		  GetPage() or FindWindowById() could have returned NULL.
		* More unicode fixes to alcc and ed2khash.
		* Fixed flags for console applications. -DwxUSE_GUI=0 is
		  required so that amuleweb, amulecmd, etc, run fine with
		  wxWidgets version 2.5.2 and up.
		* Fixed a problem with gsocket-2.5.c when using wxWidgets
		  version 2.5.2 and up. Now amule runs with 2.5.2.
		* New ipfilter code.
		* Found the reason why wx-2.5.2 gui was messed: starting with
		  wx-2.5.2, a new flag must be added when adding components to
		  sizers to keep the old behaviour (wxFIXED_MINSIZE). This
		  constant is defined to zero in amule.h when wx-version is
		  less than 2.5.2, so that amule still compiles in old wx.

	ThePolish:
		 * Add win32 MakefileWIN32, configureWIN32.h and project file amule.msp
		 * Make win32 use winsock2 for IPFilter
		 * Enable alc, alcc, wxCas translations with aMule catalog
		 * Use normalized includes for wx in wxCas, alc and alcc
		 * Limit the server name length in wxCas to avoid a too large window
		 * New icon for alc
		 * Global fr translation
		 * Fix win32 ToolBar problem

	Xaignar:
		* Added the ability to search for "Texts"
		* Attempt at fixing both Random Socket Bugs and Random Client Bugs.
		* Fixed new IPFilter code.
		* Cleanup of CPartFile::SavePartFile
		* Got rid of some unneeded includes.
		* Fixed compilation when using crypto++ 5.2
		* Ensuring that the ServerListCtrl gets unfrozen in case of corrupted met files.
		* Fixed a crash-bug added by Kry's UDP commit.

	Special thanks to:
		* The usual people, those on the other 'Thank you!' sections of changelog.
		* All the people at the Mac section of forums, for testing compilation and run.


---


## Version 2.0.0rc4a - HOTFIX release for lugdunum 16.47 servers (The 'Ooops!' version)
2004-07-14

	Kry:
		* eserver 16.47 fix for shared files packet not compressed

	deltaHF:
		* Translations update

---


## Version 2.0.0rc4 - The 'Mules and rabbits like apples too' version.
2004-07-12

	alehack:
		* Patch to show extra QR info
		* Patch to colorize the download list

	aquatroll:
		* Fixed includes for Win32 compilation
		* Cleaning of unused variables on Win32
		* Fixed compilation on Win32

	Citroklar:
		* lots of unicode slave work ;)

	croakerc:
		* Fixed OpenBSD compilation

	deltaHF:
	        * Added websearch function (filehash.com)
		* Added jugle.net as Fake-check URL
		* New buttons added:
		  - reload sharedfiles
		  - switch upload/uploadqueue
		  - clear completed files
		* Added 3 new columns in upload window (Client Software , Upload/Download , Remote Status)
		* Added 'Client Software' column in upload-queue window
		* "Asked for another file" on sources now with the filename that is asked for ( i.e. A4AF -> xyz.avi)
		* Added 'copy file feedback to clipboard' function
		* Added new Toolbar icons [ thx to http://www.everaldo.com ;) ]
		* Added icons in Preferences
		* Download menu changed
		* Work on skin support

	falso:
		* Typo fix: bandwith to bandwidth

	hellimod, one_2_one:
	    * MacOSX support

	Hetfield:
		* Fixed unicode issues on SysTray.cpp, now apps is really unicoded!
		* deleted separated i18n stuff from SysTray, now uses global one
		* Fixed 2 memory leaks in SysTray
		* updated italian and napoletanean translations
		* Fixed unicode issues in serverlist updates and download tab
		* Fixed unicode issues that stopped adding files to download from ed2k utility
		  and internal link handler

	Jacobo221:
		* New feature to open webpages in new tab instead of new window
		* Fixed a compatibility bug in OnlineSig with eMule's and added connecting support
		* Fixed bug in Statistics limits in Preferences
		* Fixed bug in Upload/UpQueue button
		* Fixed SERV.4 bug
		* Fixed DISP.14 bug
		* Added DOS compatibility into CAS and update onlinesig support
		* Several features in XAS (see XAS's changelog)

	Kry:
		* Fixed wxWidgets 2.5.x socket code. aMule now works on wx2.5.1 perfectly, wx2.5.2 introduces some GUI bugs.
		* Rewrote Preferences engine to be much nicer, and Mac compatible :) Thanks to deltaHF for the new icons.
		* Added a hack to make new preferences work on wxWidgets 2.4.2. I hope we can get rid of wx 2.4.2 soon ;)
		* Wrong .part.met files no longer make aMule abort on startup. Now a warning is displayed on log and aMule ignores that file.
		* Added the new compatible client flags tag agreed with lphant devs and eMule devs. xMule devs refused to use it.
		* Overloaded the wxSocketClient::Destroy to a safer version, to check cases when deletion is not called from Destroy()
		* Fixed the disconnection of clients that have MS_CHATTING state.
		* Fixed the usage of QueueLogLine fucntion to avoid crashed on too fast computers ;)
		* Remove spaces from search string start and end.
		* Remove spaces from ed2k links start and end.
		* Fixed a mem corruption due to lphant icon size (we all know lphants are big)
		* Splitted internal core and GUI events
			* Socket events mover to core
			* Timer got separated into core_timer and gui_timer, each one with the matching functions.
		* Fixed UDP socket handler being... the TCP handler. Since lmule times.
		* Delayed deletion of sockets to avoid async deletion issues that happens when Destroy() is called on a event
		* Fixed several rare crashes happening on some fast computers on shutdown aMule.
		* Added a debug function to get track of double-deletion of clients.
		* Socket handlers now stop notifying new events when Safe_Delete() is called.
		* m_pszUsername inited before a new call to handle 'new' exceptions correctly.
		* Added a hack on  IsRunning() to check for current app object not existing yet (or deleted on shutdown)
		* Fixed all icons to be 16x16 to avoid asserts on 2.5.x for unmatching wxImageList sizes.
		* Fixed all wxImageList sizes to avoid asserts on 2.5.x on object construction.
		* KnownFileList takes account of the duplicates now, so those are not rehashed each time anymore.
		* Fixed EC password not being shadowed on preferences.
		* The preferences dialog should be resizable now.
		* Updated lphant stats to show the version as they added the extended version tag.
		* Fixed 1 double-delete on ListenSocket, when socket is not connected.
		* Each socket has its own handler now. Much safer and faster.
		* Fixed hashing thread implementation to make it shutdown safely.
		* Fixes on geometry handling to make it work properly from commandline.
		* Fixed minimize to tray to work properly with no more double-minimizes.
		* Coded the skeleton of the core/gui separation event system, improved by lfroen later.
		* Fixed CString implementation for operator '+'
		* No linking cas, wxcas and ed2k against crypto, please :) Fixed.
		* Lots of speedups on ClientUDPSocket handling, someone went paranoid and added lot of redundant code.
		* Changed most of the wxT("") to wxEmptyString
		* Fixed the splitter position and client size on restart.
		* Fixed compilation on wxWidgets CVS
		* Fixed amuledlg not being set to null + moved the init to beginning on amule.cpp
		* Fixes mem corruption and crash on PrefsUnifiedDlg
		* Fixed missuse of  inet_addr on BaseClient.
		* Fixed crash on stats disabled
		* Reduced memory usage with a centralised icon handling.
		* Fixed wrong var type on EMSocket.h causing mem waste.
		* Fixed bug on SetFileSize (thanks to Pichuein on eMule forums)
		*  wxWidgets 2.5 compatible CDirectoryTreeCtrl.
			WARNING- NEW BEHAVIOUR IS: LEFT CLICK ON ICON -> SHARE, RIGHT CLICK -> RECURSIVE SHARE
			Also made the icon red if the folder is shared.
		* ModString fixed - Now mods identify themselves correctly.
		* As xMule now identifies as eMule 0.0a, added xMule detection based on username
		   and modstring to keep stats coherent.
		* On debug builds, client stats now show the amount of clients with open socket.
		* Changed theApp.glob_prefs->GetAppDir() to theApp.ConfigDir for speed improvements.
		* Fixed crash on empty shareddir.dat
		* Fixed listen socket being processed before created on fast computers and thus causing crashes on startup.
		* Fixed server version tag.
		* Added frame name to the aMule main window to be handled correctly by X server
		* Fixed a crash on log file re-creating on startup.
		* Fixed the update of the categories tab names to show the file count and the downloading files.
		* Fixed the update of the categories tab names tp happen only when needed to save cpu.
		* Changed several vars and functions to const for speed improvements.
		* Enter button working now for web search.
		* Added a check to disconnect clients sending non-hello packets before finishing handshake.
		* Added preferences items for the upcoming Skin engine.
		* Fix from lugdunum to avoid blacklisting on servers because of key repeat on pressing enter for search :)
		* Use generic BSD wx preprocessor define to make aMule FreeBSD and OpenBSD compatible.
		* Fixed Incoming folder not being shared on strange situations.
		* Fixed usage of '/' instead of '\' on Win32 builds.
		* Made file comparison case-insensitive on Win32.
		* Better fitting of notebooks
		* Fixed shared files reloading to stop being dependant of buttons/labels
		* Socket handling now deletes the client if connection fails ;)
		* Fixed some wxSizer usage causing compilation compatibility problems between wx 2.4.2 and 2.5.x
		* aMule now filter bad ips on source seeds.
		* Autoconnect and onlinesig are now on by default.
		* Added a check on graphic stats drawing to avoid crashes if no DC is created yet.
		* aMule now uses crypto++ for MD4 calculation (faster, and endian safe)
		* Added two sanity checks for source drawn with no reqfile associated, avoiding crashes.
		* Fixed mem corruption and possible memleaks and crashes on file comments received.
		* Fixed a BAD and UGLY and EVIL mem corruption happening since more than a year ago and still present
		   on the original program (xMule).
		* Client sending wrong OP_FILEREQUEST packets are now disconnected to avoid further problems caused by their
		   corrupted packets. Old shareazas and most xMule versions have been warned since 2004/04/13 from aMule and
		   since much more time ago from eMule. Shareaza fixed it, but xMule refuses to fix it. eMule 0.43x disconnects them too now.
		* Fixed crashes on sockets because of packet overhead being calculated after packet was deleted.
		* Fixed the CVS mod reporting for aMule 2.x
		* Fixed the Online Signature dir selection.
		* Fixed some shared files not being shared due to a return; on a wrong place ;)
		* Fixed some events being posted to wrong event handler.
		* Added GUIEvents.h to take care of the core/gui separation events.
		* Cleaned ColorFrameCtrl class
		* Cleaned otherfunctions.*
		* Lots of misc code cleaning
		* Several minor messages and GUI bugs.
		* Several warnings removed.
		* Removed useless files:
			XBMDraw.cpp
			XBMDraw.h
			SplitterControl.cpp
			SplitterControl.h

					------------ MAC -------------
		* Fixed compilation on wxMac CVS and 2.5.x
		* Fixed socket connection on Mac.
		* Fixed endian issues causing crashes on server communication.
		* Fixed string tags being read wrong.
		* Fixed known.met being corrupted on every save and reload.
		* Fixed stats not working on Mac (no longer crashes because of drawing)
		* Fixed mnemonics on file search not being endian-safe.
		* Fixed server TCP flags.
		* Fiexd bug on lowid callback.
		* Fixed serverlist on Mac:
			- Server users
			- Server files
			- Server ip being reversed on restart
			- Server port set to 0 on restart.

					-------- UNICODE ---------
		* Fixed unicode compilation of most files (except those by Citroklar, Hetfiled, and shakraw)
		* Fixed search on unicode builds.
		* Unicoded most of the app internals :)
		* Fixed part.met on unicode builds
		* Hunted and killed (char*) casts and c_str() calls.
		* Fix unicode client names and misc.
		* Percentage & Download speed fixed
		* Reported several bugs to wxDesigner's mantainer to make it work properly on unicode builds
		* Fix usage of st_mtime to allow files with non-std chars to be shared without crashes on wx2.5.1
		* Fixed PerformFileComplete to allow unicoded files to be finished :)
		* Fixed part met filename being 001.part everytime on unicode builds.
		* Fixed renaming on file completion causing crashes on unicode builds

	lfroen:
		* Started to implement various changes needed to split the core and GUI.

	Madcat:
		* Fixed preferences layout of panels.
		* Simpler ed2k link integration for Mozilla 1.3+ / FireFox 0.6+ - Using Mozex plugin

	niet:
		* Added support for memory usage and binary name (on xas)

	Phoenix:
		* Code cleaning in several modules due to making the members
		  size, opcode and prot private in packets.h.
		* CFile Close(), Read() and Seek() made const. Seek() needed
		  the use of mutable with m_fd to be const.
		* Put lots of consts around the code in the routines that
		  should be so.
		* Patch to --enable-stdin to aid in debug with valgrind.
		* Code cleaning in module Packets, made a lot of stuff private
		  now.
		* Small hacks to print debug messages and avoid crashes,
		  mainly in PartFile.cpp.
		* Sanity checks in debug mode (MagicNumbers) to aid finding
		  bogus clients and files.
		* Created debugstuff module, debug build only.
		* New configure option --enale-verbose, so that normal users
		  are not flooded with debug messages.
		* MagicNumbers are swapped to signal deleted source/PartFile.
		* Removed deprecated wxArrayString::Remove(size_t nIndex,
		  size_t nRemove = 1) using wxArrayString::RemoveAt(size_t
		  nIndex, size_t nRemove = 1) now.
		* Get rid of evil wxString::GetWriteBuff() and
		  wxString::UngetWriteBuf() in ECSocket.h.
		* Added -pw/--password command line option to amuleweb.
		* Small unicode fixes.
		* Fixed a messed up display in html code in aMule.tmpl (thanks
		  to steve.reaver)
		* Fixed font problem after Xaignar's great flicker free
		  work in download list control.
		* Fixed broken sort arrow after flicker free clean up.
		* Enabled mouse wheel scrolling in all aMule list controls.
		* Fixed two unhandled events in amule.cpp: CHAT_REFRESH_FRIEND
		  and CHAT_FIND_FRIEND.
		* Fixed compilation in 2.5.x and some unicode issues in
		  aLinkCreator. Using wxAppConsole when wx > 2.5.0.
		* Fixed compilation and linking in 2.5.x for amuleweb. Now
		  uses wxAppConsole when wx > 2.5.0.
		* Added a test for the return value of
		  theApp.serverlist->GetServerByAddress(), which could be
		  NULL. This was the reason why aMule was crashing when trying
		  to connect to server with wxWidgets-2.5.2.
		* Fixed compilation and linking in 2.5.x for amulecmd. Same
		  problem as amuleweb.
		* Commited a patch from wolti that fixes compilation on
		  sparc/Solaris systems.
		* More sparc compilation fixes, thanks to wimms.
		* Removed the declaration of void ParseCommandLine(); from
		  TextClient.h and WebInterface.h. It seems to have been
		  forgotten here.
		* Patch to listctrl.cpp, was segfaulting in 2.5.1 when
		  hiding/resizing columns. In 2.4.2 was just asserting.
		* Patch to Partfile.cpp, workaround the socket == NULL bug, so
		  that amule does not crash.

	shakraw:
		* Fixed the "remote connect" bug
		* Unicode support for amuleweb
		* Fixed typos on amuleDlg
		* Unicoded some files.

	steve.reaver:
		* Fixed a messed up display in html code in aMule.tmpl

	thepolish:
		* wxCas:
			- Fixed for amulesig.dat changes
			- Solved localized decimal separator pb
			- Embeded all pixmaps in src files and remove now unused pixmaps dir (better for portability)
			- Win32 toolbar pixmaps have transparency now
			- Added variable refresh timers
			- Added user preference system
			- Added statistic image creation
			- Added FTP support for an automatic upload of the statistic image

		* aLinkCreator:
			- Added this new maaarvellous tool suggested by DeltaHF to compute ed2k links from a file (same behavior as eMule link creator, but no shared code)
			- Rewrote md4hash and ed2khash code to avoid external dependencies (libcryptopp free), and to be Big Endian proof (works on Mac afaik)
			- Added alcc, the "alc for console" command line client
			- Added toolbar themes (KDE and DeltaHF's default for now)
			- Thanks to Phoenix (Unicode, Hook, commandline...) and one_2_one (Mac tests)

		* aMule:
			- Rewrote Makefile.am tree to fit to GNU standards
			- Removed Makefiles stuff for wxwidgets < 2.2.6
			- With >= wx-2.5, use wx-config --libs=base,net instead wxbase-config (because base in buggy on 2.5), and keep using both on 2.4 versions
			- Check for wx >= 2.4.2 instead of 2.4.0
			- Removed GTK2 warning with wx >= 2.5
			- Fixed GTK2 not detected
			- Enabled documentation installation
			- Install xas in $(libdir)/xchat/plugins. Will work if aMule and xchat are installed with same DESTDIR
			- Suppressed widlcats in makefile (not fully supported in all make)
			- Enabled make dist and make distcheck targets
			- Force automake scripts update (missing...) to suppress warning in configure
			- Force autogen.sh to regenerate intl at each call to keep sychronised with system gettext templates
			- Some minor i18n and unicode fixes
			- Updated POTFILE.in
			- Removed Win32 stuff from autotools scripts
			- Added static MakefileWIN32 for win32 compilation

	Unleashed:
		[ From rc3 (not on changelog)]
		* Cache get_path homedir to speed up multiple calls
		* Removed unused Tag_Struct
		* Fixed var init and memleak in SearchList
		[ rc4 ]
		* Fixed COMP.10 bug
		* Wiped out USE_DEBUG_SYMS

	wimms:
		* More sparc compilation fixes.

	wolti:
		* Patch that fixes compilation on sparc/Solaris systems.

	Xaignar:
		* Merged lists used to identify file-types to avoid duplicity.
		* Added wrapper-class around MD4 hashes.
		* Fixed a number of places where the hashes where used as NULL-terminated strings, despite
		  them not having a NULL-terminator.
		* Most functions using hashes now use the MD4 wrapper class for arguments.
		* Fixed rare possibility of ending with an unclosed file in CServerListCtrl.
		* Fixed unsafe parsing of OP_SERVERIDENT type packets.
		* Fixed unsafe passing of strings as arguments to functions using format-strings.
		* Changed the chat-dialogs to textctrls, which means that it is now possible to copy text (the unix way) by highlighting it.
		* Fixed some memleaks.
		* Fixed "&"s not being escaped on status-bar.
		* Fixed incorrect source exchange packet format (Many thanks to the eMule Plus team for reporting).
		* Started to document source-files with a Doxygen compatible comment format.
		* Fixed the height of the barshaders used on the download list, it was 2 pixels too high, resulting in a slight cutoff.
		* Reducing CPU-usage of auto-priority by not forcing a redraw every time the priority was automatically changed.
		* Fixed that some overloaded functions hadn't been declared virtual in the base class.
		* Replaced gif-animation widget with something more lightweight.
		* Added sanity checks to CMemFile::Read.
		* Fixed a number of uninitialized variables.
		* Fixed several warnings about non-existing files.
		* Fixes warning about not being able to create dir "" on first run.
		* Changed "Extended Drop Sources" preferences, with the result that the option will be reset to "Swap Sources" when this version of aMule is first run.
		* Got rid of most warnings when compiling.
		* Lots of work on getting rid of c-strings.
		* Fixed bug that would cause deleted sources not to be removed from the A4AF lists. This was a major source of crashes.
		* Improved performance and safety of the source lists used with PartFiles.
		* Lots of small imports from eMule.
		* Made reqfile attribute of CUpDownClient private and added wrapper functions to fix the avilable-part information getting out of sync.
		* Cleanup of includes.
		* Fixed that we were always sending an OP_REASKACK packet and then the correct packet when recieving an OP_REASKFILEPING.
		* Fixed Bug 45: URLs are now properly escaped when opening browsers for Fake-check and such.
		* Fixed Bug 62: aMule will now be brought to front when left-clicking on the tray icon and when it is redisplayed after having been hidden.
		* Added checks against aggressive clients (clients who reask for files too often).
		* Imported checks for known leech-clients from the BlackRat eMule mod ( Many thanks to Le Rat Noir and inoteb for allowing us to use their work ).
		* Fixed wrong initialization of headers for some packets ( Thanks to thomas001 for reporting ).
		* Fixed a delete called on an uninitialized pointer in the statistics dialog and properly initalized serveral other pointers.
		* Optimizing the Comp(Up/Down)DatarateOverhead functions to something that didn't require traversing a list at each call.
		* Complete rework of the source-swapping functions.
		* Fixed the possibility of sources being added to multiple source-lists at the same time (No more mis-matching hashes warnings).
		* Fixed the new columns added by deltaHF not being displayed and added checks in case the same thing happens again.
		* Almost completly eleminated flicker on the download list and did a cleanup of the drawing routines associated the the download list widget.
		* Fixed some lists (Server list, maybe others) not being sorted when aMule is started.
		* Fix mem-corruption bug in SysTray code if the systray was compiled in but hidden.
		* Fixed the problem with deleting the last (connected) server on the server list.
		* Removed the following files:
		  - ini2.*
		  - CString.h
		  - mfc.h
		  - position.h
		  - resource.h
		  - strings.en
		* Cleaned up the following files:
		  - CTypedPtrList.h
		  - BarShader.*
		* Many other smaller changes.


	Special thanks to:
		* Le Rat Noir and Inoteb of the BlackRat eMule mod (http://www.blackrat.fr.tc/) for allowing us to make use of their     work on detecting bad clients.
		* Optimazer and the eMule Plus team (http://emuleplus.sourceforge.net/) for reporting a bug in source-exchange packets.
		* thomas001 for reporting a problem with packet headers.
		* Everaldo (http://www.everaldo.com) & "Jimmac" (http://jimmac.musichall.cz/ikony.php3) for new icons
		* Phk for searching for new icons ;)
		* kno and thermoman for their fixes :)
		* TheBlackHand and Hawkster eMule mods
		* uberpenguin for AMPS :)
		* All aMule users, testers & translators
		* eMule & wxWidgets devs
		* Everyone we forgot here ;)


---


## Version 2.0.0rc3 - The 'Target: Stability' version.
2004-04-22

	aquatroll:

		* win32 stuff

	barbapapa;

		* Fixed >2Gb files sorting bug on transfer window.

	Citroklar:

		* Fixed saving preferences on klick OK, not only on shutdown.
		* Configure stuff
		* Cas related stuff

	deltaHF:

		* i18n stuff
		* Minor timer fix ;)

	elfstone:
		* Fixed already downloading files not being marked as such on search results.

	falso:

		* Improving and fixing cas
		* Added capability to create pngs with cas
		* Fixed ed2k fast links handler

	Kry:

		* Complete rewrite to emule 0.42x ed2k network code
		* Rewrite of hashing thread. Also added a timeout to save resources.
		   It times out after 1 min without hashing or receiving new files to hash, or 1 min since last hash, and dies gracefully.
		* Fixed the crash on startup if incoming/temp folder are on FAT32
		* Added Safe Max Connections code to Preferences->Tweaks.
		   This code will help all people with USB modems and crappy routers to not hang them.
		* Identify to lugdunum > 16.45 with our proper extended version tag (2.0.0)
		* Fixed & rewrote stats
			* Added Shareaza & lphant
			* Fixed mldonkey stats (do they have to change their compatible number this often?)
			* Added aMule / eMule / eDonkey proper version handling
			* Dynamic tree of client versions (no more void versions)
			* Fixed the xmule inflated statitics on the stats tree
		* Rewrote client icons handling
			* Use alpha channel to show the extended protocol and secure ident
			* Added Shareaza, xmule, lphant, bad_guy and unknown client icons
		* Fixed chuck selection. Much, much, much, much faster downloads. Back to the 1.2.6 speeds :)
		* Fixed Win32 compilation
		* Fixed lowID warning message on start being void.
		* Proper Win32 and Mac disabling of the vertical preferences
		* Severe bug on wxRadio button on RseInt was preventing ANY radio button on preferences from working.
		* Fixed crash on 'cancel' while downloading server list.
		* Fixed a UpdatePartsInfo missing on KnownFile.cpp
		* Fixes the fake-check custom browser textfield
		* Added wxNB_MULTILINE to preferences notebook.
		* Minor issue on the chunk selection (thanks to AndCycle on eMule forum)
		* Fixed a SEVERE mem access issue on the hash of the file id to check on knownfilelist.
		* Fixed a SEVERE memory bug on sending the shared folders
		* Fixed not sending the incoming and categories folders when sharing folders.
		* Fixed 'Friends' working as 'None' on 'view shared' preferences.
		* No more [0xy.part] on preview of completed files
		* Fixed the FAT32 rehashing of files on startup
		* Fixed filters not being used on right click on main transfer tab -> new status
		* Changed known file list from wxHashMap to std::map
		* Fixed auto-update server list at startup
		   Added posibility of multiple servelist urls too
		* Fix for files publishing, reported by lugdunum to eMule/aMule developers.
		* Proper use of ClearHelloProperties that fixes some crashes related to a var not being init.
		* Added MOD_VERSION to hello type packets (just for CVS versions)
		* Fixed packet processing on EMSocket error.
		* Changed the full part (9.28Mb) lower limit for preview to 256Kb
		* Added 'LI0' to the evil GPL doer checks.
		* Bugfixes on the KnownFile::UpdatePartsInfo code.
		* Added new verbose client info checkbox, to find out which clients are sending bad data.
		* Fix UDP socket for Win32
		* Re-added the timed part file buffer flush()
		* Custom language support added
		* Fixed FAT32 incoming/temp warning messages only shown on one of the folders.
		* Fixed issues on packet unzip and crash on OP_CANCELTRANSFER already sent
		* Added aMule 1.x / 2.x / CVS versioning.
		* Thread-safe log lines adding using a queued loglines list.
		* Completion Thread revamped --> No longer crashes, no longer asserts, and it's much nicer.
		* Fixed safe_delete (again)
		* Fixed some memleaks
		* Changed some CLists to wxLists
		* Cleanup and fixing little bugs ;)

	Madcat:

	        * Disable autobacktrace on win32
		* Removed wxTE_PROCESS_ENTER style from fast ed2k links handler (fixes assert)
		* The following modifications to CamuleDlg::AddLogLine() function:
		  * Now uses system locale for date/time formatting.
		  * No longer asserts.
		  * Now also works on win32.
		* Removed unused m_StateImageList
		* Code cleanup

	one_2_one, hoschy007:

	        * MacOSX stuff

	shakraw:

		* Fixed multiple file download bug in webserver search section
		* Fixed ed2k download link
		* Fixed categories for web interface
		* WebSocket.* & WebServer.*: now uses wxThreads and wxSockets to be cross platform.
		* Better threads' array remove in WebSocket
		* WebServer cleanly stopped before exit
		* Fixed max 2Gb display bug in amuleweb
		* Updated aMule.tmpl: added file %complete support in transfer list
	thepolish:

		* Wrote wxcas based on cas from falso
		* Enable auto-refresh and Fix GPL headers (wxcas)
		* Add system load and uptime (wxcas, Linux only)

	Unleashed:

		* cas: better layout and fixes
		* Fixed a pair of memleaks

	Xaignar:
		* Fixed negative percentages in downloadlist ... again (Disp.8)
		* Fixed the "free(): Invalid pointer" bug (Misc.10)
		* Fixed PowerShare priority level not being saved. (Tran.9)
		* Fixed the problem where it wasn't possible to select auto-priority in the uploadlist after having selected another priority (Tran.8)
		* Cleanup of Search Dialog:
		  * The reset button is now properly enabled/disabled depending on the contenst of the text fields
		  * Fixed a bug where searched would be limited to 2gb if max size was set to a value less than min size
		  * The popup-menu for the notebook now works as expected (SRCH.1)
		  * The popup-menu will now only show when right-clicking within the bounds of the notebook (DISP.12)
		* Fixed the green progressbar on downloads always displaying 100%. (DISP.9)
		* aMule will no longer display warnings about not being able to find server.met when a new server.met is saved and no old copy exists.
		* known.met is now auto-saved (1) when 30 files have been hashed, (2) when 300mb worth of files have been hashed, (3) and when all files have been hashed. This is to reduce the chances of having to rehash all files after a crash.
		* Now uses the user-selected browser for fake-checking and such. (PREF.3)
		* Further update of the Chat Page:
		  * Pages can now be closed like the ones on the Search Page
		  * Double-clicking on a nickname will open a chatsession for that friend
		  * When a nickname is updated in the friendlist, the assosiated tab is updated as well
		* Other stuff


	** Special thanks

		* All the bug-reporters, helpers, translators and users at http://forum.amule.org
		* Batman who commited a mldonkey related fix, thanks :)
		* Jacobo221, Stefanero for their help and support on forum and all the other stuff ;)
		* lugdunummaster for providing support on version tags and new features of lugdunum servers
		.
		 --- As usual thx to eMule & wxWidgets devs and everyone i forgot ;) ---

---

## Version 2.0.0-rc2 - The 'white rabbit' version.
2004-04-11

	aquatroll:

		* Fixed Win32 compilation (again).

	Ariel:

		* Implemented completed parts count on file rehash.
		   Prevents your downloads to completely lost on a wrong .part.met write.

	croakerc:
	        * Added zlib version check
		* *BSD compatibility

	deltaHF:

	        * New icon for aMule in DL/UP window ;)
		* curl-config now >= 7.9.5 (for debian)
		* i18n stuff
		* Removed double catalan entry from prefs
		* Fixed some typos

	falso:

		* Added cas (C aMule Statistics), a remake of aStats but 10 times faster (still lack online sign).
		* amulesign.dat now shows the Total transfered values in bytes.
		* Added Session upload and download to amulesign and uptime too.

	Hetfield:

		* Added new inclusion path if distro in not detected
		* fixed wrong and duplicated inclusion in ClientCredits.*
		* Modified configure scripts, only amule is compiled by default
		* Added cas, ed2k, amulecmd, amulegui, amule webserver, amule webserver gui
		* fixed wrong zlib check in configure

	hoschy, one-2-one, godard, PowerMike, hellimod:

	        * MacOSX stuff

	Jacobo221:

	        * Compiled the RC1 bugs and provided support on forums. It's our man-for-all.

	Kry:

		* Implemented the Complete count on search results and on file publishing.
		   This feature added since aMule 2.0.0-rc1 and eMule 0.42e was not released
		   with the rc1 for network technical reasons (still on testing with lugdunummaster).
		   When publishing a file, we also inform the server if the file is complete or not.
		   Search results show the count of complete sources sent by the server next to the sources
		   found: i.e. 100 (28) meaning 100 sources, 28 of them complete (72 incomplete or old client)
		* Added sending of the extended eMule version using aMule version, with additional rc version
		* Added parsing of the new 0.4x eMule tags on hello packets.
		* Added parsing the Secure Ident packets for new eMule versions. Reduce overhead on download/upload.
		* Added HandShake check on upload request.
		* Rewrote display of client version on transfers page to handle the client soft/version correctly on any client.
		   That means eDonkeyHybrids and eMule does show now the correct version (i.e edonkey 0.50.1 or emule 0.42d)
		   aMule shows now as either "aMule 1.x (based on eMule v0.xx)" (<= 2.0.0-rc1) or aMule "A.B.C-rcX" (>= 2.0.0-rc2)
		* Fixed Mule Info packet only sent to eMule clients. Now is sent to old eMule && eMule-like clients (compatible clients)
		* Added 'Allocate Full Part File" and "Allocate Full Chunk" to preferences. None functional yet.
		* Fixed Client Detail Dialog to show correct client version.
		* Fixed comment mark on Download list being cut on the display.
		* Fixed the crashes on Base Client packets.
		* aMule now loads .par.met.BAK if the .part.met is 0-size (added to Ariel's commit, this prevents losing met files).
		* Made SafeMem files really safe checking for read after end of file.
		* Fixed wrong Modversion data (fixes random crash too)
		* Fixed assert on wrong upload list control data.
		* Fixed several crashes on wxString::GetData usage.
		* Fixed UDP disable button not being saved across sessions
		* Fixed a bug on new version check.
		* Locale goes to System Default on new version now (fixes weird language problems)
		* Fixed wrong OP_REASKFILEPING packets being sent .
		* Reverted GAddress_INET functions to standard inet_addr ones.
		* Completely removed list refresh functions. CPU saved was not worth it.
		* Added CheckDiskSpace checkbox and radio button to the preferences.
		* Added the scale of the connections graph on stats. (only rescaled on restart)
		* Added 'Reset' button for Server Log
		* Fixed: Right click popup on server connected was showing 'connect' now shows 'reconnect'.
		* gscocket shouldn't be compiled on Mac, and so it's not compiled now ;)
		* Fixed Preview of already completed files not working.
		* Fixed files > 2Gb not working on fast ed2k links handler and ed2k app.
		* Fixed file size for files larger then 2Gb displayed incorrectly
		* Changed timeout of curl functions to 10 - fixes hangups when clicking server update without
		   internet conenction.
		* We don't share 0 size files anymore.
		* Fixed the crash on invalid socket using 5 different ways. The last one seems to be the most stable.
		* Fixed several hangups on file completion.
		* Fixed % and progressbar not being updated when changed on GUI Tweaks.
		* Fixed comment packets. This was causing disconection from eMule clients (and crashing aMule clients)
		* Fixed amule dissapearing because sent to systray when --disable-systray was used.
		* Fixed memleak on search packet sent.
		* Fixed memleak on KnownFile deletion
		* Fixed memleak on search results received.
		* Fixed memleak on comment packet received.
		* Speeded up socket event handling.
		* Cleaned server connection. No more 'inet connection might be down' - unless it's down ;)
		* Faster PartFile processing.
		* Fixed endian issue on PartFile loading.
		* Fixed non-needed delete of an array on the notebook destructor.
		* Doesn't allow an incoming packet to get processed if socket is deleting.
		* Fixed double-highlight of servers if disconnected by the server.
		* Speeded up hashing of the files a lot. This should fix the gui hangs at startup.
		* Removed all old preferences code. That makes the app smaller, less memory used, and avoid some
		   unexpected bugs that arised on having 2 preferences implementation. Now New Prefs become Preferences.
		* Fixed SysTray and gtk-files being compiled even when disabled on configure.
		* Fixed several warnings.
		* Fixed assert on Clear All (search)
		* Make aMule compile on wxWidgets 2.5 (and CVS) version.

	Madcat:

	        * win32 LaunchUrl() function
		* Added amule-win32.HOWTO.txt
		* Better win32 version of Hostname() function

	shakraw:

		* WebSocket.* & WebServer.*: now uses wxThreads and
		  wxSockets to be cross platform.
		* Better threads' array remove in WebSocket
		* WebServer cleanly stopped before exit
		* Fixed multiple file download bug in webserver search section
		* Fixed ed2k download link
		* Fixed categories for web interface

	thepolish:

	        * win32 stuff

	Unleashed:

	        * Memleak fix

	Xaignar:

		* Amule no longer writes met files when priority is changed through the
		   auto-priority subsystem. Thus hd-writes are substancially reduced
		   depending on the number of files set to auto-priority.
		* Fixed bug where text fields overlap each other (Disp. 4 & 5)
		* Cleanup of amuleDlg.*
		* aMule no longer displays a message about not being able to open the
		   file "lastversion" the first time it is run
		* Changed the CTypedPtrList filelist in DownloadQueue.* to a std::deque,
		   with a speed-increase as a result
		* Fixed the bug where the background of previously selected items in the
		   friendslist wouldn't be redrawn (Disp. 2)
		* Fixed auto-priority. Priority would be set one tad too high, resulting
		   in the downloadlist failing to assign a name to the priority, thus
		   leaving empty fields. Also fixed displaying of priorty "Auto [Lo]"
		   in sharedfiles-list. (Tran. 3)
		* Fixed the problem where "completed percent" of files that hadn't
		   transfered any bits yet would display a negative percentage (Disp. 8)


        ** Special thanks to niet for his DNS service, bootstrap for his CVS service, stefanero & Citroklar for their
	   great help with a lot of stuff.
	   Thx also to all translators and the users for reporting bugs and testing aMule (feel free to report more) :)
	   As usual thx to eMule & wxWidgets devs and everyone i forgot ;)

	** New translators:

	   Supergirl: Croatian
	   rommel:    Portuguese
	   sNeo:      Italian (Napoletan)

	** Follow the white rabbit and u'll find rc3 soon ;)

---

## Version 2.0.0-rc1 - The 'Mules and Rabbits love carrots' version.
2004-03-26

	Kry:
		* Implemented SecureIdent (SUI) (imported from eMule 0.30x)
		   This mean your credits will be lost on first run
		   There is no way to avoid that. Sorry :) Same happened with eMule.
		* Send sources request for files added from search page first.
		* Rewrote MuleNoteBook from gtk to a cross-platform implementation.
		   The code is already used by xMule too, so I guess they liked it.
		* Fixed most of > 2Gb bug, except the dom's contibution you can scrolling down ;)
		* Made the .part.met load/save 100% compatible with eMule.
		* Fixed the Safe_Delete bug. Seems it arised when we made the app too fast ;)
		* Random usable position of the server split.
		* Added bluecow's fix for zlib compressed packets.
		* Even safer .met saving
		* Added preferences checkbox for new style / old style tabs on preferences
		   (vertical/horizontal)
		* Checked for protocol limits on file size.
		* Now client detail dialog show Secure Ident State
		  (Not Supported/BadGuy/Not Complete/Verified)
		* Added itoa to the MFC layer
		* Added SetLength to CFile (MFC compat layer)
		* Fixed hangup on message sending.
		* Moved Fast ED2K show to GUI tweaks
		* Slugfiller's Secure Hash (imported from eMule 0.30x)
		* Fixed GetTickCount code returning signed value
		* Fixed GetTickCount code not initializing the vars.
		* Moved the FILE* to CFile for furter compatibility of code.
		* Added the first version run detection
		* Removed some Yield() code that only slowed init.
		* Simplified systray menu by only showing what needed.
		   Thanks to jadrian for the feature request.
		* Grayed non-working Preferences options to avoid confusion and to
		   make the developer life easier selecting what to do ;)
		* Fixed CTag new structure (imported from eMule 0.30x)
		* Removed the mostly useless wizzard.
		* Fixed the DoSwap crash on swapping A4AF sources. (hopefully)
		* Fixed the log auto-scrolling up on messages window.
		* Fixed the Upload bug that arised during endian changes.
		* Added the Arabic, Chinese & Finnish compatibility on loading
		* OpenBSD compatibility fixed
		* Mac port 99% done, next version will be Mac compatible
		   Some final bugs to be fixed ;)
		   Fixed:
		      *) .met files loading/saving (except knownfiles.met)
		      *) .dat files loading/saving
		      *) 99% of the preferences bugs.
		      *) Compilation and linking.
		      *) Error popups relates to c_opaque colour.
		* Starting sync with eMule 0.42
		* Speedups on Partfile Process nd DownloadQueue process.
		* New 'server version' colum on server list window.
		* MUCH safer packet handlig - avoids crashes on 99% of wrong tags.
		* Fixed Dirs number on 'view shared'. Made aMule/eMule assert ;)
		* Made download queue list refresh on a nicer way (much less glitches).
		* Fixes an assert for  invalid menu entry on right click queue popup.
		* Mayor speedup on Highlight server (and thus on server connect/disconnect)
		* Prevent removing the server we're connected at, either directly, on in a
		   list of servers to delete, or in removing all servers. Warn the user with a
		   message Box and then leave it non-deleted. Fixes crash.
		* Fixed hangup on message sending
		* New IPFilter code (reload & on/off)
		* Added checkboxes on GUI Tweaks tab for download progress %
		   and Bar drawing.
		* Fixed a severe memleak on the % showing and speeded it up.
		* Save 5 sources on rare files (<20 sources)
		* New SetFileSize code to avoid cpu usage.
		* Removed the List Show/Hide and slider that made too much
		   problems on 1.2.6. Safer version (and better) will be on 2.0.0 final.
		* Speedups on Hash thread.
		* Safer corrupt detection on FAT partitions
		   I'm sorry if it rehashes every file on your system on restart, will be fixed.
		* The file pause because of diskpace shows now on aMule logs
		* Fixed BackUp file to REALLY backup instead of moving.
		* Added code to check 0-size .part.met and load backup if needed.
		* Fixed types.h and wintypes.h for proper Win32/Mac/linux compatibility.
		* Added ECSocket code as common implementation for interaction between
		   different UIs (webserver, amulecmd, etc).
		* Fixed intercomunication for little endian <-> big endian machines on ECSocket.
		* Speedups on Endian Swap code & proper wxWindows way to detect it.
		* Changed CArray to wxArray on most places for safety.
		* Added configure code for detection of the crypto++ includes/libs
		* Fixed buggy curl-config on Mac including -mi386.
		* Removed useless files: TabCtrl.*
		* Fixed several bugs, memleaks, warnings and one mem corruption
		* Code cleanup

	Creteil:
		* Added the client detail dialog item for Securehash
		* Fixed sockets.cpp includes for non-debian systems ;)
		* Added Arabic, Chinese & Finnish to languages in Preferences

	Hetfield:
		* Configure now checks for crypto++ libs
		* Added --with-crypto-prefix option to configure
		* Possibile Fix to ListenSocket::Safe_Delete() seg fault
		* Added ccache support to configure, no variables tricks needed
		* Added --with-ccache-prefix option to configure
		* deleted --enable-libcwd option from configure
		* deleted useless libcwd debug files and code from whole project

	Madcat:
		* Made Fast ED2K Links Handler optional
		        Something like the old Frankk's ED2K Links Handler patch.
		* FakeCheck using donkeyfakes.gambri.net
			Original idea and implementation by deltaHF.
		* Clean(er) fix for splashscreen-creation compiler warning (unused variable
		* Moved project/muuli.wdr to src/muuli.wdr
		* ED2K-Links.HOWTO fix for some aMule/eMule error
		* Added -ggdb -fno-inline to debug compilation flags
		* Automatic category assignment for new downloads
		* Updated AUTHORS file to reflect original eMule authors and give
			credit to original Linux port author (Timo Kujala aka Tiku)
		* Win32 port 99% operative, next version will be Win32 compatible

        Emilio Sandoz:
		* complete re-write of preference handling to make it table-driven
			in both file-I/O and dialog
		* improvements in feedback given during dialog interaction

	pure_ascii:
		* Added highlighting of the connected server in server list
		* Enabled and fixed setting the server version

	shakraw:
		* Some fixes on web interface file type search, and code cleaning
		* Fixed amule crash when closing socket
		* size_t seems to break Mac compilation - anyway uintt6 is enought for
		  messages
		* Modified RseStringEncrypted. Now we encrypt passwd just (and only)
		  when changing them in prefs' dialog. So, now we use always encrypted
		  passwords, noone in clear neither in memory or disk
		* Check if we're able to use TCP ports (lacks what todo if not but we
		  can accept EC. do nothing atm = EC disabled)
		  Added "AMULEDLG SHOW" to EC available commands
		* WebServer now use the more correct _("") for localized strings
		* Created WebInterface.{h,cpp} for the web interface, and
                   cleaned WebServer.{h,cpp} code

	neiro:
		* Helped with OpenBSD port by providing a workbench

	Ganael Laplanche:
		* FreeBSD port fixes

	PowerMike, hellimod:
		* Helped a lot on future Mac port by giving ssh & vnc access

	deltaHF:
	        * New toolbar icons (thx to everaldo.com)
		* Added & enabled chinese, danish and hungarian translation
		* Preferences (added/changed):
		  IP-Filter reload and on/off buttons
		  securehash -> secure ident
		  media info
		  max connections: 25-7500
		  upload queue: 500-1000
		  max new connections / 5 sec: 5-500
		  remove dead servers after: 1 >
		  tcp port: 80 > (for users with bad ISP's .. but remember -> running aMule as root is unsecure !!!)
		  add new files (dl & share) with auto priority: off by default now (if running aMule for the first time)
		* Updated the header of all files
		* Changed wxWindows to wxWidgets
		* "Donated" amule-project.de
	niet:
		* Donated amule-project.net :-)

	bootstrap:
		* CVS support

	Torsten SCHULZ:
		* Added the % showing on progressbars.

	lemonfan:
		* Modified network code for big-endian systems
		* Fixed preferences bug
		* Fixed copy ed2k link to clipboard
		* Fixed CArray for MFC compatibility
		* More rigid compatibility to MFC types
		* Fixed misformatted strings and several warnings in WebServer.cpp

	Xaignar:
		* Code cleanup in amule.* and otherfunctions.* and other files
		* The Cleanup button in the File Details dialog no longer replaces "&" with "&&"
		* Max connections should be correctly set on windows platforms, instead of defaulting to 500
		* Finished the CArray -> wxArray conversion
		* Fixed ECSocket compilation with gcc < 3.3
		* Fixed segfault on close.
		* Some other fixes

	Citroklar:
		* External Connections are now only done when configuration tells us so (thanks to tonar from #amule)
		* crypto++ detection fix

	aquatroll:
	        * Win32 compilation Support & Development.

	hellimod, PowerMike, godard, hoschy007:
		* MacOSX compilation support

	dom:
		* Found the last  > 2GB bug ;)

	Special Thanks To:

		* All the bug-reporters, helpers, translators and users at http://forum.amule.org

		* eMule developers for their support. Long life to *Mule

		* FreshIRC & Freenode irc admins

		* People at #gentoo on freenode for their support, specially ferringb

		* The Testing Team:
		   thepolish, efe, Citroklar, bizzY, KamiKazeNH, and anyone testing aMule.

		* New translators:

		Chinese:   nbfnw
		Arabic:    hathalsal
		Finnish:   eQualizer
		Russian:   Elf
		Italian:   GhePeU, sNeo
		Portuguese (BR): KamiKazeNH
		Korean:    BlueSpring
		Spanish:   JonathanShields
		Danish:    nowlin
		Hungarian: biger [HUN]
		Galician:  thorero
		Hebrew:    denisliber

		* All aMule users!!!

---

## Version 1.2.6
2004-02-16

        Kry:
               * Improved Mac compatibility.
               * Fixed the i18n charset.
               * Try to set the locale even if it seems to fail.

        Creteil:
               * Fixed the default Size to 800x600 for 1st time aMule launched without ~/.eMule config file.

        shakraw:
               * ExternalConn: new communication code using wxSockets.
               * Web interface: improved communication performance.
               * Text interface: now using new wxSockets code.

        pil0t:
               * Fix for the geometry on start.

        pure_ascii:
               * Added sorting to filename list in file details.
               * Added "Takeover" by doubleclick in file details.
               * Fixed preferences window popping up on "Show/Hide UL/DL" in download list.
               * i18n stuff (Systray).

        rubber30:
               * Fixed viewing and sorting by LastSeenComplete and LastReception.

        Emilio Sandoz:
               * Converted stats calculations to 64bit where necessary (for uptime >49days).
               * i18n strings fixed.
               * gcc 2.95 compilation fix.

        deltaHF:
               * i18n stuff.

---

## Version 1.2.5
2004-02-10

	Hetfield:
		* Fixed a memory leak in SysTray. (SysTray.cpp)
		* Fixed a DL/UL ratio problem. (amule.cpp)

	Aleric:
		* Fixed all compiler warnings.
		* Rewrote all header #include's to only include what is necessary.
		* Removed or renamed all functions that clashed with one of the
		  same name from libwx_gtk.  With as result:
		* Fixed --enable-static possibility (needs a lot of static
		  libraries to be installed; and latest XFree86 CVS version of libX11
		  (I had to fix a bug in XFree86 too for this)).
		* Fixed check-boxes in Preferences -> Directories + a little code
		  speed up there.
		* Fixed a duplicated server_list delete
		* Server IP# filter.

	Shakraw:
		* Added missing string in GetDownloadFileInfo() causing SIGSEGV when
		  called.
		* Fixed the amuleweb login problem.
		* Added GetWebList() support.
		* amuleweb's search feature complete. Now it is possible to search,
		  download and web-search on filedonkey
		* Fixed a write error in SETMAXGRAPHUPLOADRATE
		* Added support for statistic text infos for web interface (Statistics link)
		* Fixed two bugged index causing crashes on Webserver.cpp
		* Little improvement for server list request (now responses are much faster)
		* Generally improved External Connections.
		* Fixed search type feature for web interface
		* Fixed amule crashes when quitting from amuleweb during requests

	umale:
		* Fixed debugloglines on ListenSocket.cpp ServerSocket.cpp having too
		  much arguments.
		* SysTray code will not be compiled if disabled
		* Fixed 5 wrong delete -> delete[]
		* Converted po-files

	Emilio Sandoz:
		* Statistics graphs:
		    Param changes reversible;
		    Color change now works;
		    Active connections rescaling now works;
		    Graphs and tree suspended when not visible.
		* Set correct initial radio button in Systray integration dialog
		* Simplified statistics graph averaging
		* Corrected UL loop for timer errors
		* Simplified UL rate averaging
		* Preliminary cleanup of graphing engine; ghosting eliminated
		* Client DL rate computation without CList
		    Fixed 32bit rollover error for rates over 84kB/s
		    Reduced initial spiking
		    Generally improved speed and CPU/RAM usage.
		* Search window column widths remembered between searches & saved in preferences
		* Statistics preferences dialog: changes are now applied on-the-fly (with proper
		  Cancel semantics)
		* Eliminated possibility of root directory being invisibly shared

	Kry:
		* Added some sanity checks to avoid losing *.part.met files on
		  power failure. 0-Size files are never written.
		* Fixed the 'all time transfered' on Shared Files window
		  This one fixed some eMule/aMule incompatibility on part.met files
		* Some aditional functions on CFile for windoze compatibility
		* MFC compatibility enhanced.
		* Added SetFilePath to CKnownFile
		* Changed most 'assert' to wxASSERT
		* Fixed some NULL clientname causing crash on ListenSocket.cpp
		* Fixed the tagcount on .part.met files (KnownFile.cpp)
		* Added missing OP_CHANGE_CLIENT_ID on ListenSocket
		* Updated HomePage to www.amule.org on messages
		* Fixed the server windows splitter. Or sash. Whatever.
		* Imported all the other ListenSocket.cpp code from 0.30e
		* Fixed 'View Shared Files'. No multiple tabs, also.
		* Added theApp.listensocket->StartListening() on startup.
		  Really. Don't ask me why it worked before.
		* Fixed the systray bug where speed bar was always 10 times smaller.
		* Added lots of vars initilization that fixed some crashes.
		* Fixed a crash on ClientList.cpp caused by a void node on list.
		* Fixed 9 memleaks, some of them big ones.
		* Fixed 6 wrong delete -> delete[]
		* Fixed wrong hashsetneeded causing random crash
		* Added GetED2KPartHashCount() & GetED2KPartCount()
		* Fixed a bug on app init, related to Toolbar.
		* Fixed a severe crash & memory corruption on UploadClient.cpp
		* Fixed download rate overhead calculation
		* New HeapSort() and NewSrcPartsInfo() ported from eMule 0.30e
		* wxGTK 2.5 compilation fixes
		* Fixed the 'rehashing of files on restart' problem.
		* Fixed a missing "Error" message on console when partfile loading failed.
		* i18n activated, GNU xgettext compatible.
		* Fixed bug on OP_REQUESTFILENAME packet that made eMule clients to disconnect
		  from us. eMule clients got our version of client and expected to get the
		  new OP_REQUESTFILENAME from eMule 0.30. Thanks to John & BlubbX from eMule
		  team for the report and help tracking down it.
		* Fixed several i18n bugs from xMule times.
		* Fixed the lseek error on console and window popup when canceling a file
		  that is transfering.
		* First implementation of selectable refresh. The refresh is bugged - it
		  deletes the info on screen, except for about 1 sec, every time
		  seconds_defined_on_preferences is reached.
		* Used selectable refresh code for SysTray-hiden cpu lower.
		* New option on right-click on downloadlist: Hide/Show lists.
		* Minimize on startup works now.
		* Minimize to tray works now.
		* Lots of BSD compilation fixed (aMule compiles under BSD again)
		* Fixed the upload disconecting clients at high upload speed
		* Changed another wxList to CList (FriendList)
		* FriendSlot should have no effect on LowId user.
		* Fixed FriendSlot not being persistent and kicking friend after 1 chunk.
		* Fixed lowid users on upload queue by importing VQB's lowid alternate
		* Added language selection support on preferences
		* Fixed the bug that caused never to tell user 'server full'
		* Fixed several server connection issues not detected before.
		* Added a popup on language change warning for restart.
		* Added another popup, this time to point the user on the right direction
		  if the locale for that language cannot be set.
		* Stop publishing on ED2K network shared files we don't have anymore
		* Removed the annoying messages of dropping sources (too much CPU)
		* Sanity check to avoid user pushing buttons before aMule is ready for it.

	thermoman:
		* Made aMule gcc 2.95 compatible

	seneca:
		* Near finished all i18n stuff. We expect aMule 1.2.5 is fully i18n-compatible
		* Added wxT() Macro for Unicode Support (not functional yet)

	Citroklar:
		* Testing, lots of testing. Bug-tracker.
		* Found the versions that introduced the upload bug and made a nice diff.
		  We could look at code for years, without seeing it. Nice guy.
		* Fixed README, amulesig.txt.

	gjn:
		* Fixed bug in creditsystem.

	jmccorm:
		* Fixed "Close This Searchresult" -> "Close This Search Result"
		* Fixed some typos.

	lemonfan:
		* Fixed stopped files being counted on CheckDiskSpace()
		* Progressbar fixes on webserver implementation.
		* Several crashes fixed by adding sanity checks to reqfile

	deltastar (on irc channel):
		* Fixes the > 2Gb files problem caused by a bug on CFile wrapper.

	deltaHF:
	        * i18n stuff

	pure_ascii:
		* fixed recreation of filename list in file details
		* scrolling and selecting filenames works now

	hellimod:
		* BSD and Mac support. We're very near to the Mac aMule.

	niet:
		* Donated www.amule.org!

	Creteil:
		* Change order in the notebook for logs in Servers Window
		* Updated the logo for webserver from eMule logo to aMule one
		* Fixed Switching to Searches Window Bug when removing all servers
		  in Servers Window
		* Changed default server list from 'best' to 'max', then 'max' to 'best' again
		* Fixed the default systray value on preferences.
		* Added debug values on UploadQueue.
		* Changed max Slot Allocation to 30Kb/s
		* Fixed typo in Preferences
		* Implemented notebook in Server Window
		  (merged 'Server Info' & 'aMule Log' windows in a notebook)
		* Fixed bug crashing aMule on Server Window Notebook implementation.
		* Now, if no --geometry width & size used, aMule starts with 800x600 as default
		* Fixed size restoring from .eMule saved size
		* Option 'Search global' in Search Window in the default now.
		* GUI code for new slider in Preferences->Tweaks tab handling the lists refresh
		* Some cosmetic fixes on Preferences and GUI by Madcat's request.
		* Made GUI i18n compliant.
		* Slot alloc calculation is properly rounded now.
		* Added the Language listbox on preferences.

	special thx to:

		* Our translators:

		   german:       emperor, hariolf, crazeee, neolino (M$ user), deltaHF
		   italian:      ilbuio, AnonimoVeneziano
		   spanish:      mad_soft, aquatroll, Kry
		   russian:      Vl@dCoR
		   bulgarian:    tindor
		   dutch:        Supersnail
		   polish:       Ogon
		   lithuanian:   Fatalissimo
		   french:       SlayeruleZ, thepolish
		   catalan:      pukyxd
		   portuguese:   willy, coolzero
		   basque:       piarres
		   galego:       thorero

		* The people at #wxwindows, irc.freenode.net for being so helpful
		  Specially BrianHV, raboof and ajjl.

		* All eMule devs for being so nice and work close with aMule team now.

		* Madcat, from Sharedaemon team (sharedaemon.sf.net) for his support
		  and friendship.

		* All aMule users!!!

---

## Version 1.2.4
2004-01-10

(Previously released, with some errors, as 1.2.3-1)

	Aleric, Kry:
		* Fixed the 'Completing file' bug.

---

## Version 1.2.3
2003-12-31

The "Happy New Year!" version.

	Kry:
		* New ProcessLocalRequest ported from eMule 0.30e.
		* Fixed crash on DownloadQueue caused by a CString being passed
		  through "...".
		* Nice CPU usage drop with new GetSourcesCount code.
		* Some little speed optimizations here and there.
		* Fixed bug on second mule starting.
		  Now amule also spawns two servers for external connection, one
		  local and one TCP (optional).
		* Added gsocket-2.5.* from wxGTK2.5's gsocket files.
		  This files are patched to fix LOWID.
		* Added EC REQ for total upload for a file, by deltaHF's request.
		  It uses CPU, so it can be enabled with --enable-releasegrp
		* Several TextClient improvements / cleanings / cosmetics
		* Fixed a strdup being used instead of nstrdup (with Aleric)
		* Fixed anoying DiskSpace Bug (tm)
		  Now files paused because there's no space left are resumed as soon
		  as we have diskspace again.
		* Got rid of the chmod stuff on fat32 partitions.
		  aMule detect the filesystem the temp/incoming folders are mounted on.
		* Fixed column hiding on all lists
		* New configure option: --with-curl-prefix
		  Also fixed CURL_LIBS and CURL_FLAGS to be passed to compiler/linker
		* Weird I18N bugs fixed (labels, etc)
		* Cleanups and code cleaning on
		  ServerSocket.cpp DownloadQueue.cpp PartFile.cpp
		* Fixed compiler warnings on:
			TextClient.cpp PartFile.cpp

	pure_ascii:
		* More docs/ cleaning.

	Hetfield:
		* Patched Process() function in Partfile class to reduce cpu
		  load.
		* Added new optimization to Tray to stop window updating when minimized.

	Shakraw:
		* Added commands to use with amuleweb to EC.
		* Completed Transfer feature and Started Search.
		* Added SharedFiles, Statistics, Graphs and Prefs features.
		* Cleaned webserver code from amule sources.
		* Imported emule0.30d webserver code.
		* New web template & images from eMule 0.30d.
		* New binaries: amuleweb and amulewebDLG.
			This binaries are used for webserver.
		* Webserver runs now over EC, and has a separate app to serve web.

	umale:
		* Fixed storing pointer on 64-bit archs
		* Fixed resolving of broadcast IPs.
		* Changed trunc() to explicit casting.

	Creteil:
		* Re-imported new code to handle 'CheckDiskspace'.
		* Changed labels in Statistics to stick on stats patch from Emilio
		  Sandoz.
		* Synched some code on :
			DownloadClient.cpp
			ListenSocket.cpp
			UploadClient.cpp
		  with eMule 0.30e.
		* Cosmetics & Indentation.

	deltaHF:
		* Added new function - PowerShare. Release your vacation movies
		  now ;-).

	Aleric:
		* autogen.sh revamp.
		* Global "sys.h" inclusion policy.
		* --enable-libcwd configure option: Use libcwd.
		* Makefile.am (SUBDIRS): Include intl and correct order.
		* configure.in
			(AM_MAINTAINER_MODE): Add.
			(AC_CONFIG_FILES)   : Add intl/Makefile.
			Add --enable-static.
		* configure.in (EXPORT_DYN_FLAGS): Removed.
		* All files (when appropriate): Removed #pragma interface
		  implementation.
		* Koenig lookup fix for g++ 3.4 on mfc.h's CQArray::QuickSort
		* Fix of compiler errors on ExternalConn.cpp
		* dos2unix several files.
		* Added GPL license header where needed.
		* Compile fixes for FreeBSD on systray and gsocket*

	Emilio Sandoz:
		* Patched stats for acurate resizing / scale.
		* Fix for inflated UL/DL rates in Transfer and Statistics windows
		* Debug code for UL/DL rate measurement in UploadQueue.cpp
		  (activate with '#define MEASURE_LOST_CYCLES 1')

	Seneca:
		* I18N:
		  ListenSocket.cpp PartFile.cpp ServerList.cpp
		  ServerSocket.cpp SharedFileList.cpp sockets.cpp
		  WebServer.cpp PartFile.cpp UploadClient.cpp
		  ClientCredits.cpp ClientUDPSocket.cpp.

---

## Version 1.2.2

     Phantom version. Expected to be released on 21/22 dec, delayed and then made
     into 1.2.3 version.

---

## Version 1.2.1
2003-12-14

	Kry:
		* Now amule shows icon on taskbar and main window
		* amulecmd now compiles under win32 using dialogs to get
		  port, hostname and password.
		* Added clientversion on download list.
		* Modified configure script and makefiles for faster
		  compilation and smaller binaries.
		* Fixed nasty download list bug due to memory corruption
		  inside CUpDownClient class vars.
		* Imported new acurate download speed calculation from eMule
		  0.30d.
		* Moved docs to doc/ folder.
		* Imported new GetNextRequestedBlock algorythm from eMule
		  0.30d.
		* Ed2k links with hostname sources on it are processed
		  now, and on a separate thread.
		* Showing filename on CheckDiskSpace debug statement.
		* Imported eMule's 0.30d SortByPriority to complete
		  CheckDiskSpace import.
		* Several addings to mfc.h file (MS MFC compatibility
		  layer).
		* We forgot to show A4AF sources on download list. Fixed now
		  (eMule style, x/y+z (t)).
		* New packet receiving handling should avoid high_dlspeed->
		  high_cpu.  It also makes download more stable and faster.
		* Modified autogen.sh script to notify users that automake <
		  1.7 is NOT supported.
		* Imported CanAddSource(), AddSources(), IsGoodIP() and
		  IsGoodIPPort() from 0.30d (new sources handling).
		* Added plain password support to amulecmd.
		* Updated amulecmd passwords to use MD5.
		* New External Connection stuff to handle amulecmd & other
		  remotes (alpha).
		* Fixed some code causing strange errors when trying to
		  connect to servers.
		* Imported new network UDP features from eMule 0.30d, we
		  process Search results and Found sources correctly now on
		  16.40 behaviour.
		* Fixed lowid on restart introduced by himself on 1.2.0 ;).
		* Code cleaning & optimising.

	pure_ascii:
		* Fixed segfault on call of CEMSocket::DisableDownloadLimit()
		  from client if there is no socket.
		* Fixed bug on mfc.h's CList.
		* Added zlib fixes from eMule 0.30e code.

	Hetfield:
		* Added new server list fetching via libcurl libs and wxThread,
		  thus removing wget usage from amule.
		* Modified configure to check libcurl presence.
		* Changed thread file completion from pthread to wxThread.

	falso:
		* Several i18n stuff. We're more close to get i18n working.

	umale:
		* Patch for x86_64 arch. (GetTickCount)

	spiralvoice:
		* Found wrong ET_COMPATIBLECLIENT on aMule. Now we identify
		  correctly as emule compatible client.
		* Also did MLdonkey patch for recognising amule as new client
		  brand.

	Unleashed:
		* Typo and cosmetic changes on configure script
		* Cleaned and optimised several files.

	Creteil:
		* Imported 'Copy ED2k link to clipboard (Source)' from
		  eMule, this one permit to send an ed2k link with our ip
		  address as source for the link.
		* Imported 'Copy ED2k link to clipboard (Hostname)' from
		  eMule, this one permit to send an ed2k link with our
		  hostname as source for the link.
		* Fixed handling of bad ET_COMPATABLECLIENT for buggy aMules
		  clients (buggy are 1.1.1 - 1.2.0).
		* Lot of code cleaning / indenting.
		* Fixed clientversion on download list implemented by Kry.
		* Added new mini icon for aMule clients in downloadlist,
		  uploadlist & uploadclient.
		* Defined 'deletethis' as 'bool' in ListenSocket.h.
		* Fixed typo on Statistics window.
		* Imported CheckDiskspace() from eMule 0.30c.
		* Imported eMule's 0.30c A4AF (now more handled by Razor).
		* Imported new file rating management from eMule 0.30c.
		* Modified BaseClient.cpp to sync better with eMule 0.30c
		  (added m_fSharedDirectories flag to stick with eMule
		  code).
		* Fixed bug on CPartFile::IsAlreadyRequested().
		* Added new mini icon handling in downloadlist/uploadlist
		  for aMule clients.
		* Fixed bug in uploadlist.

---

## Version 1.2.0
2003-11-26

	Kry:
		* Some memleaks fixed (Thanks to xMule team)
		* Removed no-needed break statement
		* Added '--help' option to amule.
		* Fixed (probably) all m_abyPartStatus related bugs (~CUpdownClient related)
		* Imported ResetFileStatusInfo() (minor import)
		* Fixed the bug that made files >2.4Gb get sorted as if size < 0 bytes
		* Fixed the search types bug.
		* Fixed Small Files bug.
		  Thanks to Citroklar for his research on this one.
		  He tested all versions to find when did the bug enter amule.
		* Added new hashshet handling for sources.
		* Added new timeout handling for sources.
		* Finished porting of NewSrcPartsInfo started by Creteil
		* New standalone app: amulecmd.
		* gsocket.c no longer gets compiled if wx version >=2.5
		* Added --disable-amulecmd to configure
		* Added check on configure for wxbase (needed for amulecmd)

	Hetfield:
		* Added --safe-systray to configure
		* Added --disable-systray to configure
		* Much better configure script output.

	Ganael LAPLANCHE:
		* Kinnda good guy. Fixed BSD compilation and also did BSD packages.

	eagle:
		* Added --geometry option

	pure_ascii:
		* Fixed a bug on ListenSocket.cpp that crashed amule.

	Creteil:
		* Updated ServerSocket.cpp for bOutputMessage we always send even on error ...
		* Fixed all 'return statements' in all Lists
		* Set minimum refresh for stats tree slider to 5 seconds
		* Fixed several CVS crashes due to indentation & porting bugs.
		* Fixed downloadlist expand crash.
		* Connect 'Verbose (additional program feedback)' CheckBox to some debug in log window and logfile
		* Fixed bug in ServerList Window when changing priority
		* Added preferences box for KeepAlive time.
		* Imported code from eMule 0.30
		  GetMaxFilesPerUDPServerPacket() SendGlobGetSourcesUDPPacket()
		  GetSoftFiles() SetSoftFiles()	GetHardFiles() SetHardFiles()
		  SetVersion() DbgGetFileInfo()

---

## Version 1.1.2
2003-11-04

	Kry:
		* Ok, REALLY fixed the 'no sources' bug.
		* Added the KeepConnectionAlive function (This one is
		  recomended by lugdunummaster himself).
		* Some more memleaks fixed.
		* Now aMule compiles under wxGTK2.5

---

## Version 1.1.1b
2003-11-03

	Kry:
		* * Fixed severes memleaks.

---

## Version 1.1.1a
2003-11-03

	Kry:
		* Fixed annoying bug about no sources can be find.

	Creteil:
		* Fixed another assert statement causing crash.

---

## Version 1.1.1
2003-11-01

	Kry:
		* Added zlib support.
		* No more need to launch aMule with params for localized
		  users we force the english language in the prog now
		  (credits go to Eru).
		* Fixed minor network bugs.
		* Added SERVER_NET_DEBUG and NET_DEBUG mesages.
		* Fixed TCP packet not being consumed if not readed.

	Olonho:
		* Fixes to search dialog and download menu.

	Creteil:
		* Added new toolbar icons made by deltaHF.
		* Added new clients icons made by deltaHF.
		* Reverted default minimum upload slots = 3, now slot
		  allocation take effect if max upload >= 10kB/s.
		* Fixes bad code branch escaping in Shared Files Window.
		* Shared Files Window, Priority & Permissions in righ mouse
		  click working like expected now.
		* Mass Code Cleaning (no more compilation of wx/xrc shit we
		  don't use anymore), my old binarie = 2.9Mb the new one
		  = 2.5Mb.

---

## Version 1.1.0 (Kry special edition).
2003-10-21

	Kry:
		* Fixed UDP packet not being consumed when reading sources
		  if file status = stopped.
		* Added lugdunum 16.40 sources Handling (you get more
		  sources now).
		* Added lugdunum 16.40 extended server messages (we receive
		  full message now).
		* Initial import of Messaging sytem core. Credits go to Tiku.

	Creteil:
		* Fixed a bug introduced in 1.0.9 in Preferences Connection
		  Tab.
		* Fixed aMule banned aMule client :-) (aMule seem to be too
		  much aggressive) (Creteil).
		* Relooked all main windows.
		* Initial import of Messaging sytem GUI. Credits go to Tiku.

---

## Version 1.0.9
2003-10-17

 - Fixes :

	* olonho various fixes (added gsocket.c, inited variable, fixed
	  Valgrind error, removed buggy debug print, fixed SIG_PIPE in
	  better way, fixed valgrind warnings).
	* Fixed icons used to reflect status in download list.

 - New Features :

	* New Preferences with old implementation (this mean we dont have
	  already the WebServer and Gui Tweak Tabs).
	* Slot Allocation in Connection Preferences Tab (you can now set the
	  bandwith per client in upload list).

 - Info :

	* I'm working hard on the rewrite of preferences, don't expect many
	  changes during this time ...

---

## Version 1.0.8
2003-10-10

 - Fixes :

	* Fixed bugs in "EMSocket.cpp" causing crash.

 - New Features :

	* Good news !!! Hetfield have contributed to aMule with the new
	  systray integration ...

	  Like emule one :

	  Let you set Download & Upload speed.
	  Shows speed.
	  Let you iconify and hide aMule.
	  Shows your infos like ip, hash, server, GB, etc ...
	  Let you disconnect and reconnect.

 - Need to be Fixed :

	* Localization Languages are broken for the moment (i'm thinking about
	  removing totally this functionnality).

 - Info :

	* I'm working hard on the rewrite of preferences, don't expect many
	  changes during this time ...

---

## Version 1.0.7
2003-10-03

 - Fixes :

	* Fix the annoying message when searching "Client too old ...".
	* Fix compilation a compilation bug introduced in 1.0.6.
	* Move the code to put the toolbar in the gui file (no more designed
	  by hand gui code for this part).

 - Code Cleaning :

	* Changed the Connection Wizard with SpinCtrl in place of the
	  TextCtrl to handle values of line capacities (no more atoi
	  converssion since we use already int return from SpinCtrl).

 - Need to be Fixed :

	* Localization Languages are broken for the moment, don't panic it's
	  just temporary ... (i'm thinking about removing totally this
	  functionnality).

---

## Version 1.0.6
2003-09-24

 - Fixes :

	* Just somes fixes.

 - New Functionnalities :

	* ed2k servers handler : by Emanuel Wontorra

 - Need to be Fixed :

	* Localization Languages are broken for the moment, don't panic it's
	  just temporary ..

---

## Version 1.0.5
2003-09-15

 - Gui changes :

	* Import from eMule 0.27a: "Obtained Parts" bar in the shared files
	  list.

 - Fixes :

	* Synced aMule with xMule latest fixes.
	  It's a Malware non direct contribution :-) ...

 - New Functionnalities :

	* Import from eMule: Request of shared files by directory.
	* Import from eMule 0.27a: Up-/download auto-priority.

 - Code cleanup :

	* Mass code removing for none working sections ...

 - Need to be Fixed :

	* Localization Languages are broken for the moment, don't panic it's
	  just temporary ..

---

## Version 1.0.4
2003-09-14

 - Gui changes :

	* MASS GUI changes (look in Transfer Window), removed the fucking
	  unusable Messages Window and moved the Friend stuff from these to
	  a new alligned left wxListCtrl ... Enjoy !!!
	* Now i report only Client name in Sources column of Transfert
	  Window (use right mouse click to see Details of the client as
	  usual).

 - Fixes :

	* Synced aMule with xMule latest fixes (Fix various minor problems
	  as found by valgrind and electric-fence & Fix a bug with the
	  client credits map: It is not possible to convert the map key...).
	  It's a Malware non direct contribution :-) ...

 - Code cleanup :

	* Mass code removing for none working sections ...

 - Need to be Fixed :

	* Localization Languages are broken for the moment, don't panic it's
	  just temporary ..

---

## Version 1.0.3
2003-09-08

 - Gui changes :

	* Changed 'Edit Category Properties' dialog.

 - Fixes :

	* Fixed comments count in 'File Comments' dialog.
	* Fixed bug introduced in 1.0.2 (can't call comments in File
	  Details).

 - Code cleanup :

	* Removed mmMultiButton from source (no more used).

---

## Version 1.0.2
2003-09-03

 - Gui changes :

	* Changed Show all comments dialog.

 - Fixes :

	* Synced aMule with xMule latest fixes (Imported source exchange v2
	  from eMule, Possible fix for some problems while ending the
	  program).

---

## Version 1.0.1
2003-08-29

 - Gui changes :

	* Changed Client Details & File Details Dialog (auto resizing of all
	  fields).

 - Fixes :

	* Synched aMule with xMule latest fixes.

---

## Version 1.0.0
2003-08-25

!!! Initial Launch of aMule !!!

 - Gui changes :

	* Changed Main Servers Window (changed position of functionnalities,
	  now, to update serverlist from url, click on the serverlist icon,
	  all others field are descriptive by herself).
	* Changed Main Search Windows (removed not connected functions and
	  Direct Download), all GUI stuff of this window come in
	  muuli_wdr.cpp & muuli_wdr.h.
	* Fixed behaviors of buttons in Main Search Window.
	* Added Fast ED2K Links Handler (Direct Download) with same
	  functionnality as the original Direct Download of xMule Search
	  Main Window but followin all main windows (i hate to have to
	  switch to Search Main Window to be able to send a ED2K Link ...


 Nothing more i can remind ;-)

---

malware's contributions:
   * Speed up the initial sharing by making KnowFileList a hash map.
   * Remove the assign to category context menu entry only if it was
     already there.
   * Reimplemented hashing thread.
   * Removed unused locks. As the NetBSD team pointed out they are
     causing problems on their system because it does core dump on
     unlocking a mutex that was not locked.
   * Made the title for systray the same as for the main dialog.
   * Never share a file twice.
   * Fixed endless loop in sending UDP packets.
   * Fixed a possibly exploitable bug as noticed by S. Esser from e-matters.
   * Fixed new downloads assigned to random category.
   * Check size of OP_SERVERSTATUS packet more strictly.
   * Do not display the unit for file size twice in shared file list web page.

Un-Thesis' contributions:
   * Added more support for Solaris, thanks to wimms.
   * Corrected various Linux-specific #ifdefs.
   * Fixed the bug that kept auto-backtrace from occuring in Linux.

NetBSD team's contributions:
   * Fixed bug with the mutex protecting calls to gethostbyname.
   * Try to increase some resource limitation to the permitted maximum.

sepahewe's contributions:
   * Fix images in transfer list web page.
